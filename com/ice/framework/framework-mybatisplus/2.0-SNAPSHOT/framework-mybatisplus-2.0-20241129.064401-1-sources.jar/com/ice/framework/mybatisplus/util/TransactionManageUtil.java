package com.ice.framework.mybatisplus.util;

import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * 后置事物处理
 * 
 * @author wangwei
 * @Date 2024/5/21 16:56
 */
public class TransactionManageUtil {

    /**
     * 事务提交后执行，一般用于事务执行过程不影响核心业务逻辑时，排除在整个事务外 或者事务中存在远程调用，该远程调用可以通过补偿的方式处理异常时调用
     *
     * 调用方式
     * 
     * @Autowired private TransactionCommitHandler transactionCommitHandler;
     *
     *
     *            在事务方法中 transactionCommitHandler.handle(()->{ 操作数据库或者远程调用 })
     * @param action
     *            执行业务
     */
    public static void handleAfterCommit(Runnable action) {
        if (TransactionSynchronizationManager.isActualTransactionActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    // 具体的异步操作
                    action.run();
                }
            });
        } else {
            action.run();
        }
    }

}

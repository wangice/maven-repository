package com.ice.framework.mybatisplus.injector;

import java.util.List;

import org.apache.ibatis.session.Configuration;

import com.baomidou.mybatisplus.core.injector.AbstractMethod;
import com.baomidou.mybatisplus.core.injector.DefaultSqlInjector;
import com.baomidou.mybatisplus.core.metadata.TableInfo;
import com.baomidou.mybatisplus.extension.injector.methods.InsertBatchSomeColumn;

/**
 * @author wangwei
 * @Date 2021/12/30 16:10
 */
public class EasySqlInjector extends DefaultSqlInjector {

    /**
     * 在默认的操作中添加InsertBatchSomeColumn方法，
     * 
     * @Author wangwei
     * @Date 2021/12/30
     */
    @Override
    public List<AbstractMethod> getMethodList(Configuration configuration, Class<?> mapperClass, TableInfo tableInfo) {
        List<AbstractMethod> methodList = super.getMethodList(configuration, mapperClass, tableInfo);
        methodList.add(new InsertBatchSomeColumn());
        return methodList;
    }
}

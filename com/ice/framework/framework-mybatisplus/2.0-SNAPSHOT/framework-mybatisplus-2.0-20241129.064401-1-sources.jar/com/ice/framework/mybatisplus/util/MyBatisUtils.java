package com.ice.framework.mybatisplus.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import com.ice.framework.common.base.RPage;
import com.ice.framework.common.entity.SortingField;
import com.ice.framework.common.util.ObjectTransformUtil;

import cn.hutool.core.collection.CollectionUtil;

/**
 * MyBatisUtils 转化工具
 * 
 * @author wangwei
 * @Date 2022/2/17 10:29
 */
public class MyBatisUtils<T, R> {

    /**
     * 将Mybatis-plus返回的分页结果转成我方系统的分页结果
     * 
     * @param page
     * @param <T>
     * @return
     */
    public static <T> RPage<T> transmit(IPage<T> page) {
        if (page == null) {
            return null;
        }
        RPage<T> resultPage = new RPage<>();
        resultPage.setCurrent(page.getCurrent());
        resultPage.setRecords(page.getRecords());
        resultPage.setTotal(page.getTotal());
        resultPage.setSize(page.getSize());
        resultPage.setPages(page.getPages());
        return resultPage;
    }

    /**
     * 将Mybatis-plus返回的分页结果转成我方系统的分页结果
     * 
     * @param page
     * @param <T>
     * @return
     */
    public static <T, S> RPage<S> transmit(IPage<T> page, Class<S> targetClass) {
        if (page == null) {
            return null;
        }
        RPage<S> resultPage = new RPage<>();
        resultPage.setCurrent(page.getCurrent());
        resultPage.setTotal(page.getTotal());
        resultPage.setSize(page.getSize());
        resultPage.setPages(page.getPages());
        List<S> list = ObjectTransformUtil.transferList(page.getRecords(), targetClass);
        resultPage.setRecords(list);
        return resultPage;
    }

    /**
     * 将分页结果将成其他类型的分页结果
     * 
     * @param page
     * @param targetClass
     * @param <T>
     * @param <S>
     * @return
     */
    public static <T, S> RPage<S> transmit(RPage<T> page, Class<S> targetClass) {
        if (page == null) {
            return null;
        }
        return transmitList(page, (objList) -> ObjectTransformUtil.transferList(objList, targetClass));
    }

    /**
     * 将分页结果将成其他类型的分页结果
     * 
     * @param page
     * @param tsFunction
     * @param <T>
     * @param <S>
     * @return
     */
    public static <T, S> RPage<S> transmit(RPage<T> page, Function<T, S> tsFunction) {
        if (page == null) {
            return null;
        }
        RPage<S> resultPage = new RPage<>();
        resultPage.setCurrent(page.getCurrent());
        resultPage.setTotal(page.getTotal());
        resultPage.setSize(page.getSize());
        resultPage.setPages(page.getPages());
        if (CollectionUtils.isNotEmpty(page.getRecords())) {
            List<S> list = new ArrayList<>();
            for (T t : page.getRecords()) {
                S s = tsFunction.apply(t);
                list.add(s);
            }
            resultPage.setRecords(list);
        }
        return resultPage;
    }

    /**
     * 将分页结果将成其他类型的分页结果
     * 
     * @param page
     * @param tsFunction
     * @param <T>
     * @param <S>
     * @return
     */
    public static <T, S> RPage<S> transmitList(RPage<T> page, Function<List<T>, List<S>> tsFunction) {
        if (page == null) {
            return null;
        }
        RPage<S> resultPage = new RPage<>();
        resultPage.setCurrent(page.getCurrent());
        resultPage.setTotal(page.getTotal());
        resultPage.setSize(page.getSize());
        resultPage.setPages(page.getPages());
        if (CollectionUtils.isNotEmpty(page.getRecords())) {
            resultPage.setRecords(tsFunction.apply(page.getRecords()));
        }
        return resultPage;
    }

    /**
     * 将RPage转化为Page
     * 
     * @param pageParam
     * @param <T>
     * @return
     */
    public static <T> Page<T> buildPage(RPage pageParam) {
        return buildPage(pageParam, null);
    }

    /**
     * 将RPage转化为Page
     * 
     * @param pageParam
     *            分页
     * @param sortingFields
     *            排序字段
     * @param <T>
     * @return
     */
    public static <T> Page<T> buildPage(RPage pageParam, Collection<SortingField> sortingFields) {
        // 页码 + 数量
        Page<T> page = new Page<>(pageParam.getCurrent(), pageParam.getSize());
        // 排序字段
        if (!CollectionUtil.isEmpty(sortingFields)) {
            page.addOrder(sortingFields.stream()
                .map(sortingField -> SortingField.ORDER_ASC.equals(sortingField.getOrder())
                    ? OrderItem.asc(sortingField.getField()) : OrderItem.desc(sortingField.getField()))
                .collect(Collectors.toList()));
        }
        return page;
    }

    /**
     * 返回一个空结果
     * 
     * @param <T>
     * @return
     */
    public static <T> RPage<T> emptyPage() {
        RPage<T> resultPage = new RPage<>();
        resultPage.setCurrent(1);
        resultPage.setRecords(null);
        resultPage.setTotal(0);
        resultPage.setSize(0);
        resultPage.setCurrent(1);
        resultPage.setPages(0l);
        return resultPage;
    }
}

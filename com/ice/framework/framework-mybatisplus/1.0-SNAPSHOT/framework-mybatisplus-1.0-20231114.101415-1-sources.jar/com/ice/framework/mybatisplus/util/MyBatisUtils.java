package com.ice.framework.mybatisplus.util;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ice.framework.common.base.RPage;
import com.ice.framework.common.entity.SortingField;
import com.ice.framework.common.util.ObjectTransformUtil;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author wangwei
 * @Date 2022/2/17 10:29
 */
public class MyBatisUtils<T,R> {

    /**
     * 将Mybatis-plus返回的分页结果转成我方系统的分页结果
     * @param page
     * @param <T>
     * @return
     */
    public static <T> RPage<T> transmit(IPage<T> page) {
        if (page == null) {
            return null;
        }
        RPage<T> resultPage = new RPage<>();
        resultPage.setCurrent(page.getCurrent());
        resultPage.setRecords(page.getRecords());
        resultPage.setTotal(page.getTotal());
        resultPage.setSize(page.getSize());

        return resultPage;
    }

    public static <T,R> RPage<R> transmit(IPage<T> page, Class clz) {
        if (page == null) {
            return null;
        }
        RPage<R> resultPage = new RPage<>();
        resultPage.setCurrent(page.getCurrent());
        List list = ObjectTransformUtil.transferList(page.getRecords(), clz);
        resultPage.setRecords(list);
        resultPage.setTotal(page.getTotal());
        resultPage.setSize(page.getSize());
        return resultPage;
    }

    public static <T> Page<T> buildPage(RPage pageParam) {
        return buildPage(pageParam, null);
    }

    public static <T> Page<T> buildPage(RPage pageParam, Collection<SortingField> sortingFields) {
        // 页码 + 数量
        Page<T> page = new Page<>(pageParam.getCurrent(), pageParam.getSize());
        // 排序字段
        if (!CollectionUtil.isEmpty(sortingFields)) {
            page.addOrder(sortingFields.stream().map(sortingField -> SortingField.ORDER_ASC.equals(sortingField.getOrder()) ?
                    OrderItem.asc(sortingField.getField()) : OrderItem.desc(sortingField.getField()))
                    .collect(Collectors.toList()));
        }
        return page;
    }
}

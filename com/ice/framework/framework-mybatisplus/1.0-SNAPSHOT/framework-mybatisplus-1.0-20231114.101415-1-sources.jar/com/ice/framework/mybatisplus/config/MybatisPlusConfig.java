package com.ice.framework.mybatisplus.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import com.ice.framework.mybatisplus.injector.EasySqlInjector;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MapperScan 无法使用占位符的方式，该配置需要进行修改，或者在每个dao中添加 @Mapper
 * @author wangwei
 * @Date 2021/12/29 17:29
 */
@Configuration
@MapperScan(basePackages = {"com.ice.**.mapper","com.ice.**.dao"})
public class MybatisPlusConfig {

    /**
     * 分页插件
     * @Author wangwei
     * @Date 2021/12/30
     */
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        PaginationInnerInterceptor paginationInnerInterceptor = new PaginationInnerInterceptor(DbType.MYSQL);
        paginationInnerInterceptor.setMaxLimit(5000L);
        interceptor.addInnerInterceptor(paginationInnerInterceptor);
        return interceptor;
    }

    /**
     * 支持批量插入，原生的批量插入是循环插入
     * @Author wangwei
     * @Date 2021/12/30
     */
    @Bean
    public EasySqlInjector easySqlInjector() {
        return new EasySqlInjector();
    }

}

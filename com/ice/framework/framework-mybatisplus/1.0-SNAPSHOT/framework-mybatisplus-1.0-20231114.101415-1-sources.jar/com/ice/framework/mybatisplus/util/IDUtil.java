package com.ice.framework.mybatisplus.util;

import com.baomidou.mybatisplus.core.toolkit.IdWorker;

/**
 * ID 生成工具
 * @author wangwei
 * @Date 2021/12/30 10:23
 */
public class IDUtil {

    /**
     * 返回long类型
     *
     * @return
     */
    public static Long generateID() {
        return IdWorker.getId();
    }

    /**
     * 返回String类型
     * @return
     */
    public static String generateIDSTR() {
        return IdWorker.getIdStr();
    }

    /**
     * 返回字符串类型
     *
     * @return
     */
    public static String generateSTRID(String flag) {
        return flag + IdWorker.getIdStr();
    }
}

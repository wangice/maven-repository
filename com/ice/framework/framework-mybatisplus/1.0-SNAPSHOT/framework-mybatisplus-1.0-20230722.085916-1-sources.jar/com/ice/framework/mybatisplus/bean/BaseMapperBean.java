package com.ice.framework.mybatisplus.bean;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wangwei
 * @Date 2021/12/30 10:19
 */
@Data
public class BaseMapperBean implements Serializable {

    private static final long serialVersionUID = -570678341075027102L;

    /** 创建人ID */
    private String createId;

    /** 创建时间 */
    private Date createTime;

    /** 更新人ID */
    private String updateId;

    /** 更新时间 */
    private String updateTime;

    /** 是否删除 0：未删除，1：已删除*/
    @TableLogic
    private Boolean deletedInd;
}

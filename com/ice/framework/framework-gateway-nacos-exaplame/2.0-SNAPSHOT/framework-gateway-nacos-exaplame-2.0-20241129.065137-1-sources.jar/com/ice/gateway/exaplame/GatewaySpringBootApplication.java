package com.ice.gateway.exaplame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 扫码包一定需要扫码到framework-gateway的实体bean
 * 
 * @author wangwei
 * @Date 2024/7/18 16:45
 */
@SpringBootApplication(scanBasePackages = {"com.ice"})
public class GatewaySpringBootApplication {
    public static void main(String[] args) {
        SpringApplication.run(GatewaySpringBootApplication.class);
    }
}

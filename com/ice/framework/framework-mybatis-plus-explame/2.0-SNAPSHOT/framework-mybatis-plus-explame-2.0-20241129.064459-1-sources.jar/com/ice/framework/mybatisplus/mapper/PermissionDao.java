package com.ice.framework.mybatisplus.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.ice.framework.mybatisplus.entity.PermissionEntity;

/**
 * <p>
 * 权限表 Mapper 接口
 * </p>
 *
 * @author ice
 * @since 2024-07-02 16:07:711
 */
@Mapper
public interface PermissionDao extends EasyBaseMapper<PermissionEntity> {

}

package com.ice.framework.mybatisplus.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import com.ice.framework.mybatisplus.bean.BaseMapperBean;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 权限表
 * </p>
 *
 * @author ice
 * @since 2024-07-02 16:07:711
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("t_permission")
public class PermissionEntity extends BaseMapperBean {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 租户标识
     */
    @TableField("tenant_code")
    private String tenantCode;

    /**
     * 权限系统编码
     */
    @TableField("authority_system_code")
    private String authoritySystemCode;

    /**
     * 编码
     */
    @TableField("permission_code")
    private String permissionCode;

    /**
     * 名称
     */
    @TableField("permission_name")
    private String permissionName;

    /**
     * 父节点编码
     */
    @TableField("tree_parent_code")
    private String treeParentCode;

    /**
     * 权限树路径编码（包含当前节点）
     */
    @TableField("tree_code_full_path")
    private String treeCodeFullPath;

    /**
     * 权限名称树路径（包含当前节点）
     */
    @TableField("tree_name_full_path")
    private String treeNameFullPath;

    /**
     * 同层节点排序号
     */
    @TableField("tree_node_sort")
    private Integer treeNodeSort;

    /**
     * 权限类型（1：页面，2：按钮，3：数据权限）
     */
    @TableField("permission_type")
    private Byte permissionType;

    /**
     * 描述
     */
    @TableField("`description`")
    private String description;

    /**
     * 是否启用(0:禁用，1：启用)
     */
    @TableField("enabled")
    private Byte enabled;

    /**
     * 权限类型（仅功能权限时：1：页面，2：按钮）
     */
    @TableField("page_type")
    private Byte pageType;
}

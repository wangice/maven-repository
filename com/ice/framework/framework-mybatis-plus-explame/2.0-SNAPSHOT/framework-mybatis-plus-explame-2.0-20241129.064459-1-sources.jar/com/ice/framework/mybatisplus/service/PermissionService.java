package com.ice.framework.mybatisplus.service;

import com.baomidou.mybatisplus.extension.service.IService;

import com.ice.framework.mybatisplus.entity.PermissionEntity;

/**
 * <p>
 * 权限表 服务类
 * </p>
 *
 * @author ice
 * @since 2024-07-02 16:07:711
 */
public interface PermissionService extends IService<PermissionEntity> {

}

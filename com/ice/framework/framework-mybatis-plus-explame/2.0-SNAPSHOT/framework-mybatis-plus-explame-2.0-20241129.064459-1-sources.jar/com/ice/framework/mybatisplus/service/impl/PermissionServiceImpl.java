package com.ice.framework.mybatisplus.service.impl;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.ice.framework.mybatisplus.entity.PermissionEntity;
import com.ice.framework.mybatisplus.mapper.PermissionDao;
import com.ice.framework.mybatisplus.service.PermissionService;

/**
 * <p>
 * 权限表 服务实现类
 * </p>
 *
 * @author ice
 * @since 2024-07-02 16:07:711
 */
@Service
public class PermissionServiceImpl extends ServiceImpl<PermissionDao, PermissionEntity> implements PermissionService {

}

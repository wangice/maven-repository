package com.ice.framework.mybatisplus.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ice.framework.common.annotation.AutoResult;
import com.ice.framework.mybatisplus.entity.PermissionEntity;
import com.ice.framework.mybatisplus.service.PermissionService;

import jakarta.annotation.Resource;

/**
 * <p>
 * 权限表 前端控制器
 * </p>
 *
 * @author ice
 * @since 2024-07-02 16:07:711
 */
@AutoResult
@RestController
@RequestMapping("/mybatisplus/permission")
public class PermissionController {

    @Resource
    private PermissionService permissionService;

    @GetMapping("getPermissions")
    public List<PermissionEntity> getPermissions() {
        return permissionService.list();
    }
}

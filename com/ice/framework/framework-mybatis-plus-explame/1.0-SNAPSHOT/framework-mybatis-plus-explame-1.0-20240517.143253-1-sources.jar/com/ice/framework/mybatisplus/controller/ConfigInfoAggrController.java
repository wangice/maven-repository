package com.ice.framework.mybatisplus.controller;


import com.ice.framework.common.annotation.AutoResult;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 增加租户字段 前端控制器
 * </p>
 *
 * @author ice
 * @since 2022-02-14 11:02:938
 */
@AutoResult
@RestController
@RequestMapping("/mybatisplus/config-info-aggr-entity")
public class ConfigInfoAggrController {
}


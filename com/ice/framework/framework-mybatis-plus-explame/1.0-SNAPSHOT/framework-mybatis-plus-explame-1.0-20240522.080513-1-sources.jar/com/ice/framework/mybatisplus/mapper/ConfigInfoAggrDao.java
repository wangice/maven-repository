package com.ice.framework.mybatisplus.mapper;

import com.ice.framework.mybatisplus.entity.ConfigInfoAggrEntity;
import com.ice.framework.mybatisplus.mapper.EasyBaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 增加租户字段 Mapper 接口
 * </p>
 *
 * @author ice
 * @since 2022-02-14 11:02:938
 */
@Mapper
public interface ConfigInfoAggrDao extends EasyBaseMapper<ConfigInfoAggrEntity> {

}

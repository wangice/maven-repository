package com.ice.framework.mybatisplus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author wangwei
 * @Date 2021/12/30 14:52
 */
@SpringBootApplication(scanBasePackages = {"com.ice.framework"})
public class MybatisPlusApplication {

    public static void main(String[] args) {
        SpringApplication.run(MybatisPlusApplication.class);
    }
}

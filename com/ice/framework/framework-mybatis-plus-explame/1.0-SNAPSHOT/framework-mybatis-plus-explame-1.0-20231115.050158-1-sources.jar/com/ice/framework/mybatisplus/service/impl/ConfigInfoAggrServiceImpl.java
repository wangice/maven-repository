package com.ice.framework.mybatisplus.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ice.framework.mybatisplus.entity.ConfigInfoAggrEntity;
import com.ice.framework.mybatisplus.mapper.ConfigInfoAggrDao;
import com.ice.framework.mybatisplus.service.ConfigInfoAggrService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 增加租户字段 服务实现类
 * </p>
 *
 * @author ice
 * @since 2022-02-14 11:02:938
 */
@Service
public class ConfigInfoAggrServiceImpl extends ServiceImpl<ConfigInfoAggrDao, ConfigInfoAggrEntity> implements ConfigInfoAggrService {

}

package com.ice.framework.mybatisplus.service;

import com.ice.framework.mybatisplus.entity.ConfigInfoAggrEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 增加租户字段 服务类
 * </p>
 *
 * @author ice
 * @since 2022-02-14 11:02:938
 */
public interface ConfigInfoAggrService extends IService<ConfigInfoAggrEntity> {

}

package com.ice.generator;

import java.util.Collections;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.GlobalConfig;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.baomidou.mybatisplus.generator.config.PackageConfig;
import com.baomidou.mybatisplus.generator.config.StrategyConfig;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.fill.Column;
import com.baomidou.mybatisplus.generator.fill.Property;
import com.baomidou.mybatisplus.generator.keywords.MySqlKeyWordsHandler;

import com.ice.framework.mybatisplus.bean.BaseMapperBean;
import com.ice.framework.mybatisplus.mapper.EasyBaseMapper;

/**
 * @author wangwei
 * @Date 2024/7/2 14:53
 */
public class FastAutoGeneratorClass {

    public static void globalConfig(GlobalConfig.Builder builder) {
        // TODO: 修改outputDir 输出地址
        builder.outputDir(
            "E:\\ICE_Java_Work\\ice-framework-parent\\framework-explame\\framework-mybatis-plus-explame\\src\\main\\java") // 设置输出目录
            .author("ice") // 设置作者名
            .disableOpenDir() // 禁止自动打开输出目录
            .commentDate("YYYY-MM-dd HH:MM:SS")// 设置注释日期格式
            .build();
    }

    public static void packageConfig(PackageConfig.Builder builder) {
        // TODO: 1. 修改parent的内容
        // TODO：2. 修改moduleName内容
        // TODO: 3. 修改pathInfo地址
        // 生成包路径配置
        builder.parent("com.ice.framework") // 设置父包名
            .moduleName("mybatisplus") // 设置父包模块名,同时是Controller的跟路径
            .entity("entity").service("service").serviceImpl("service.impl").mapper("mapper").controller("controller")
            .pathInfo(Collections.singletonMap(OutputFile.xml,
                "E:\\ICE_Java_Work\\ice-framework-parent\\framework-explame\\framework-mybatis-plus-explame\\src\\main\\resources\\mapper"))
            .build();
    }

    public static void strategyConfig(StrategyConfig.Builder builder) {
        // TODO: 修改addInclude
        builder.enableCapitalMode() // 开启大写命名
            .enableSkipView() // 开启跳过视图
            .disableSqlFilter() // 禁用 SQL 过滤
            .addInclude("t_permission") // 生成的表，运行为多个
            .addTablePrefix("t_", "c_") // 增加过滤表前缀
            .addFieldSuffix("_flag"); // 增加过滤字段后缀

        // 生产 Entity（此处已经继承了BaseMapperBean类）
        builder.entityBuilder().superClass(BaseMapperBean.class) // 设置父类
            .enableLombok() // 开启 Lombok 模型
            .enableChainModel() // 开启链式模型
            .enableTableFieldAnnotation() // 开启生成实体时生成字段注解
            .disableSerialVersionUID() // 禁用生成 serialVersionUID
            .enableRemoveIsPrefix() // 开启 Boolean 类型字段移除 is 前缀
            // .enableFileOverride() // 覆盖已生成文件
            .naming(NamingStrategy.underline_to_camel) // 数据库表映射到实体的命名策略 默认下划线转驼峰命名: NamingStrategy.underline_to_camel
            .columnNaming(NamingStrategy.underline_to_camel) // 数据库表字段映射到实体的命名策略
            .addSuperEntityColumns("created_id", "created_time", "updated_id", "updated_time") // 添加父类公共字段
            .addTableFills(new Column("create_time", FieldFill.INSERT))
            .addTableFills(new Property("updateTime", FieldFill.INSERT_UPDATE)) // 添加表字段填充
            .idType(IdType.AUTO) // 全局主键类型
            .formatFileName("%sEntity"); // 格式化文件名称

        // 生成 Controller
        builder.controllerBuilder().enableHyphenStyle().enableRestStyle().formatFileName("%sController");

        // 生成Service
        builder.serviceBuilder().formatServiceFileName("%sService").formatServiceImplFileName("%sServiceImpl");
        //
        builder.mapperBuilder().superClass(EasyBaseMapper.class).enableBaseResultMap().enableBaseColumnList()
            .formatMapperFileName("%sDao").formatXmlFileName("%sMapper").build();
    }

    public static void main(String[] args) {

        // TODO：修改数据库地址信息
        DataSourceConfig.Builder dataSourceConfigBuilder = new DataSourceConfig.Builder(
            "jdbc:mysql://127.0.0.1:3306/ice_center_orgauth?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&allowMultiQueries=true&noAccessToProcedureBodies=true&useSSL=false&serverTimezone=Asia/Shanghai",
            "root", "123456").schema("mybatis-plus").keyWordsHandler(new MySqlKeyWordsHandler());

        FastAutoGenerator.create(dataSourceConfigBuilder).globalConfig(FastAutoGeneratorClass::globalConfig)
            .packageConfig(FastAutoGeneratorClass::packageConfig).strategyConfig(FastAutoGeneratorClass::strategyConfig)
            .execute();
    }
}

package com.ice.generator;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.converts.MySqlTypeConvert;
import com.baomidou.mybatisplus.generator.config.querys.MySqlQuery;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.fill.Column;
import com.baomidou.mybatisplus.generator.fill.Property;
import com.baomidou.mybatisplus.generator.keywords.MySqlKeyWordsHandler;
import com.ice.framework.mybatisplus.bean.BaseMapperBean;
import com.ice.framework.mybatisplus.mapper.EasyBaseMapper;
import org.junit.jupiter.api.Test;

import java.util.Collections;

/**
 * @author wangwei
 * @Date 2021/12/30 10:26
 */
public class GeneratorClass {
    public static void main(String[] args) {
        // TODO：修改数据库地址信息
        DataSourceConfig dataSourceConfig = new DataSourceConfig.Builder("jdbc:mysql://127.0.0.1:3306/nacos_config?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&allowMultiQueries=true&noAccessToProcedureBodies=true&useSSL=false&serverTimezone=Asia/Shanghai", "root", "123456")
                .dbQuery(new MySqlQuery())
                .schema("mybatis-plus")
                .typeConvert(new MySqlTypeConvert())
                .keyWordsHandler(new MySqlKeyWordsHandler())
                .build();

        // TODO: 修改outputDir 输出地址
        GlobalConfig globalConfig = new GlobalConfig.Builder()
                .outputDir("D:\\ICE_Java_Work\\ice-framework-parent\\framework-explame\\framework-mybatis-plus-explame\\src\\main\\java")
                .author("ice")
                .disableOpenDir()
                .commentDate("YYYY-MM-dd HH:MM:SS")
                .build();


        // TODO: 1. 修改parent的内容
        // TODO：2. 修改moduleName内容
        // TODO: 3. 修改pathInfo地址
        // 生成包路径配置
        PackageConfig packageConfig = new PackageConfig.Builder()
                .parent("com.ice.framework")
                .moduleName("mybatisplus")  // 设置为模块名称,同时是Controller的跟路径
                .entity("entity")
                .service("service")
                .serviceImpl("service.impl")
                .mapper("mapper")
                .controller("controller")
                .other("other")
                .pathInfo(Collections.singletonMap(OutputFile.mapperXml, "D:\\ICE_Java_Work\\ice-framework-parent\\framework-explame\\framework-mybatis-plus-explame\\src\\main\\resources\\mapper"))
                .build();

        // TODO: 修改addInclude
        // 设置 表
        StrategyConfig.Builder builder = new StrategyConfig.Builder()
                .enableCapitalMode()
                .enableSkipView()
                .disableSqlFilter()
                .addInclude("config_info_aggr")  // 生成的表，运行为多个
                .addTablePrefix("t_", "c_")
                .addFieldSuffix("_flag");

        // 生产 Entity（此处已经继承了BaseMapperBean类）
        builder.entityBuilder()
                .superClass(BaseMapperBean.class)
                .enableLombok()
                .enableChainModel()
                .enableTableFieldAnnotation()
                .naming(NamingStrategy.underline_to_camel)
                .columnNaming(NamingStrategy.underline_to_camel)
                .addSuperEntityColumns("id", "created_id", "created_time", "updated_id", "updated_time")
                .addTableFills(new Column("create_time", FieldFill.INSERT))
                .addTableFills(new Property("updateTime", FieldFill.INSERT_UPDATE))
                .idType(IdType.AUTO)
                .formatFileName("%sEntity");

        // 生成 Controller
        builder.controllerBuilder()
                .enableHyphenStyle()
                .enableRestStyle()
                .formatFileName("%sController");

        // 生成Service
        builder.serviceBuilder()
                .superServiceClass(IService.class)
                .superServiceImplClass(ServiceImpl.class)
                .formatServiceFileName("%sService")
                .formatServiceImplFileName("%sServiceImpl");
        //
        builder.mapperBuilder()
                .superClass(EasyBaseMapper.class)
                .enableMapperAnnotation()
                .enableBaseResultMap()
                .enableBaseColumnList()
                .formatMapperFileName("%sDao")
                .formatXmlFileName("%sMapper");

        AutoGenerator autoGenerator = new AutoGenerator(dataSourceConfig);
        autoGenerator.global(globalConfig);
        autoGenerator.packageInfo(packageConfig);
        autoGenerator.strategy(builder.build());
        autoGenerator.execute();

    }
}

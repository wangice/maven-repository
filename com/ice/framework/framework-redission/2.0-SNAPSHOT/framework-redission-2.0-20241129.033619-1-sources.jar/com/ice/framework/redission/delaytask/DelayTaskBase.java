package com.ice.framework.redission.delaytask;

import java.util.concurrent.TimeUnit;

import lombok.Data;

/**
 * @author wangwei
 * @Date 2022/6/17 15:51
 */
@Data
public class DelayTaskBase {

    // 重试次数
    private Integer retryNum;
    // 最大重试次数
    private Integer retryMaxNum;
    // 延迟时间
    private long delayTime;
    // 延迟单位
    private TimeUnit timeUnit;
    // 延迟队列名称
    private String queueName;
}

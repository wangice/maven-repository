package com.ice.framework.redission.configure;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import com.ice.framework.redission.repeat.RedissonLockExecutor;

/**
 * Redisson锁自动配置器
 *
 * @author zengzhihong
 */
@Configuration
@ConditionalOnClass(Redisson.class)
class RedissonLockAutoConfiguration {
    @Bean
    @Order(100)
    public RedissonLockExecutor redissonLockExecutor(RedissonClient redissonClient) {
        return new RedissonLockExecutor(redissonClient);
    }
}
package com.ice.framework.redission.repeat;

import java.util.concurrent.TimeUnit;

import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;

import com.ice.framework.common.lock.LockExecutor;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author wangwei
 * @Date 2024/6/19 09:52
 */
@Slf4j
@RequiredArgsConstructor
public class RedissonLockExecutor implements LockExecutor<RLock> {

    private final RedissonClient redissonClient;

    @Override
    public boolean renewal() {
        return true;
    }

    @Override
    public RLock tryLock(String lockKey, String lockValue, long expire, long acquireTimeout) throws Exception {
        final RLock lockInstance = redissonClient.getLock(lockKey);
        final boolean locked = lockInstance.tryLock(acquireTimeout, expire, TimeUnit.MILLISECONDS);
        return obtainLockInstance(locked, lockInstance);
    }

    @Override
    public RLock tryLock(String lockKey, String lockValue, long expire) throws Exception {
        final RLock lockInstance = redissonClient.getLock(lockKey);
        boolean locked = lockInstance.tryLock(expire, TimeUnit.MILLISECONDS);
        return locked ? lockInstance : null;
    }

    @Override
    public boolean releaseLock(String lockString, String lockValue, RLock lockInstance) throws Exception {
        if (lockInstance.isHeldByCurrentThread()) {
            lockInstance.unlockAsync().get();
            return true;
        }
        return false;
    }
}

package com.ice.framework.redission.delaytask;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * @author wangwei
 * @Date 2022/6/20 10:33
 */
@Data
@Configuration
public class DelayedQueueConfig {

    @Value("${delay.task.flag:false}")
    private Boolean delayTaskFlag;

    @Value("${delay.task.retry.max:3}")
    private Integer retryMaxNum;
}

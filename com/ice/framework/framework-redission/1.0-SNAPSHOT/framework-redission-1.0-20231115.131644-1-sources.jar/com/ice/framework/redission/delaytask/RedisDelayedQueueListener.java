package com.ice.framework.redission.delaytask;

/**
 * 队列事件监听接口，需要实现这个方法
 * @author wangwei
 * @Date 2022/6/17 16:21
 */
public interface RedisDelayedQueueListener<T extends DelayTaskBase> {

    /**
     * 设置队列名称
     */
    String getQueueName();

    /**
     * 执行方法
     * @Author wangwei
     * @Date 2022/6/17
     */
    boolean invoke(T t);

    /**
     * 重试最大次数失败
     * @param t
     */
    void retryFail(T t);
}

package com.ice.es.explame.esmapper;

import org.dromara.easyes.core.kernel.BaseEsMapper;

import com.ice.es.explame.model.UserDocument;

/**
 * @author wangwei
 * @Date 2024/7/18 16:52
 */
public interface UserDocumentMapper extends BaseEsMapper<UserDocument> {}

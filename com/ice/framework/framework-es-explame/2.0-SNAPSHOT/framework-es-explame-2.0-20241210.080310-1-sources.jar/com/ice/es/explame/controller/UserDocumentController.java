package com.ice.es.explame.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ice.es.explame.dto.UserDocumentDto;
import com.ice.es.explame.service.UserDocumentService;
import com.ice.es.explame.vo.UserDocumentVo;

import com.ice.framework.common.annotation.AutoResult;

/**
 * @author wangwei
 * @Date 2024/7/18 16:55
 */
@AutoResult
@RestController
public class UserDocumentController {
    @Autowired
    private UserDocumentService userDocumentService;

    @GetMapping("/createIndex")
    public void createIndex() {
        userDocumentService.createIndex();
    }

    @PostMapping("/insert")
    public Integer insert(@RequestBody UserDocumentDto userDocumentDto) {
        return userDocumentService.insert(userDocumentDto);
    }

    @PostMapping("/search")
    public List<UserDocumentVo> search(@RequestBody UserDocumentDto userDocumentDto) {
        return userDocumentService.search(userDocumentDto);
    }
}

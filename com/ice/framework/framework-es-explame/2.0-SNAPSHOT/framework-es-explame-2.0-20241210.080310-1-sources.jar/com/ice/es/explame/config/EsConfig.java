package com.ice.es.explame.config;

import org.dromara.easyes.starter.register.EsMapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author wangwei
 * @Date 2024/7/18 16:48
 */
@Configuration
@EsMapperScan("com.ice.es.explame.esmapper")
public class EsConfig {}

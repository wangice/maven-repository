package com.ice.es.explame.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author wangwei
 * @Date 2024/7/18 17:00
 */
@Data
public class UserDocumentDto {
    private String id;

    @Schema(description = "用户名称")
    private String userName;

    @Schema(description = "用户编码")
    private String userCode;

    @Schema(description = "email")
    private String email;
}

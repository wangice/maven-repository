package com.ice.es.explame.service;

import java.util.List;

import com.ice.es.explame.dto.UserDocumentDto;
import com.ice.es.explame.vo.UserDocumentVo;

/**
 * @author wangwei
 * @Date 2024/7/18 16:55
 */
public interface UserDocumentService {
    void createIndex();

    Integer insert(UserDocumentDto userDocumentDto);

    List<UserDocumentVo> search(UserDocumentDto userDocumentDto);
}

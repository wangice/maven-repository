package com.ice.es.explame.model;

import org.dromara.easyes.annotation.IndexId;
import org.dromara.easyes.annotation.IndexName;
import org.dromara.easyes.annotation.rely.IdType;

import lombok.Data;

/**
 * @author wangwei
 * @Date 2024/7/18 16:49
 */
@Data
@IndexName
public class UserDocument {
    @IndexId(type = IdType.CUSTOMIZE)
    private String id;

    private String userName;

    private String userCode;

    private String email;
}

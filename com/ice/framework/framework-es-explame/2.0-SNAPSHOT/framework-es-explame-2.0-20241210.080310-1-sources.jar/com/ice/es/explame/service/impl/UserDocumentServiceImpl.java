package com.ice.es.explame.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ice.es.explame.dto.UserDocumentDto;
import com.ice.es.explame.esmapper.UserDocumentMapper;
import com.ice.es.explame.model.UserDocument;
import com.ice.es.explame.service.UserDocumentService;
import com.ice.es.explame.vo.UserDocumentVo;

import com.ice.framework.common.util.ObjectTransformUtil;
import com.ice.framework.es.query.LambdaEsQueryWrapperX;

import lombok.RequiredArgsConstructor;

/**
 * @author wangwei
 * @Date 2024/7/18 16:56
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class UserDocumentServiceImpl implements UserDocumentService {

    private final UserDocumentMapper userDocumentMapper;

    @Override
    public void createIndex() {
        userDocumentMapper.createIndex();
    }

    @Override
    public Integer insert(UserDocumentDto userDocumentDto) {
        UserDocument userDocument = ObjectTransformUtil.transfer(userDocumentDto, UserDocument.class);
        return userDocumentMapper.insert(userDocument);
    }

    @Override
    public List<UserDocumentVo> search(UserDocumentDto userDocumentDto) {
        List<UserDocument> userDocuments = userDocumentMapper.selectList(new LambdaEsQueryWrapperX<UserDocument>()
            .matchIfPresent(UserDocument::getUserCode, userDocumentDto.getUserCode())
            .eqIfPresent(UserDocument::getUserName, userDocumentDto.getUserName()));
        return ObjectTransformUtil.transferList(userDocuments, UserDocumentVo.class);
    }
}

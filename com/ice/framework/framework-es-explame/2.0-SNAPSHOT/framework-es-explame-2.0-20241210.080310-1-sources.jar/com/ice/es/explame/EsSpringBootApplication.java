package com.ice.es.explame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author wangwei
 * @Date 2024/7/18 16:45
 */
@SpringBootApplication
public class EsSpringBootApplication {
    public static void main(String[] args) {
        SpringApplication.run(EsSpringBootApplication.class);
    }
}

package com.ice.framwork.rocketmq.listener;

import com.yomahub.tlog.core.rpc.TLogLabelBean;
import com.yomahub.tlog.core.rpc.TLogRPCHandler;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.core.RocketMQListener;

import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * 继承AbstractRocketMqListener并实现方法
 * @author wangwei
 * @Date 2023/8/17 11:15
 */
public abstract class AbstractRocketMqListener implements RocketMQListener<MessageExt> {

    private final TLogRPCHandler tLogRPCHandler = new TLogRPCHandler();


    protected abstract void doConsumer(String t);

    @Override
    public void onMessage(MessageExt message) {
        Map<String, String> properties = message.getProperties();
        String tlogTraceId = properties.get("tlogTraceId");
        String tlogSpanId = properties.get("tlogSpanId");
        TLogLabelBean tLogLabelBean = new TLogLabelBean();
        tLogLabelBean.setTraceId(tlogTraceId);
        tLogLabelBean.setSpanId(tlogSpanId);
        tLogRPCHandler.processProviderSide(tLogLabelBean);
        try {
            String bodyStr = new String(message.getBody(), StandardCharsets.UTF_8);
            this.doConsumer(bodyStr);
        } finally {
            tLogRPCHandler.cleanThreadLocal();
        }
    }
}

package com.ice.framework.common.exception;

import com.ice.framework.common.constant.ErrorCode;

import java.text.MessageFormat;

/**
 * @author wangwei
 * @Date 2022/10/27 10:32
 */
public class CommonException extends RuntimeException {
    private String code;
    private String message;

    public CommonException() {
        this.code = ErrorCode.SERVER_NOT_AVAILABLE.getCode();
        this.message = ErrorCode.SERVER_NOT_AVAILABLE.getMessage();
    }

    public CommonException(String message) {
        super(message);
        this.code = ErrorCode.SERVER_NOT_AVAILABLE.getCode();
        this.message = ErrorCode.SERVER_NOT_AVAILABLE.getMessage();
        this.message = message;
    }

    public CommonException(String message, Object... values) {
        this(MessageFormat.format(message, values));
    }

    public CommonException(String code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

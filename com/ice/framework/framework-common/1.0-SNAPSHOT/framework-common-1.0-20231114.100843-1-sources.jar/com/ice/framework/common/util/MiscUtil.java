package com.ice.framework.common.util;

import cn.hutool.core.exceptions.ExceptionUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * @author wangwei
 * @Date 2022/3/30 17:11
 */
@Slf4j
public class MiscUtil {

    public static final String COMMA = ",";

    public static final String SEMICOLON = ";";

    /**
     * 将字符串生成唯一longHash编码
     * @Author wangwei
     * @Date 2022/3/30
     */
    public static Long longHash(String str) {
        long h = 98764321261L;
        int l = str.length();
        char[] chars = str.toCharArray();

        for (int i = 0; i < l; i++) {
            h = 31 * h + chars[i];
        }
        return h;
    }

    /**
     * 休眠不抛异常
     * @param time
     */
    public static void sleep(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            log.warn("休眠异常：{}", ExceptionUtil.stacktraceToString(e));
        }
    }
}

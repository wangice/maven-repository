package com.ice.framework.common.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author wangwei
 * @Date 2022/12/2 12:15
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ParallelResult<T> {
    private String key;

    private T data;

}

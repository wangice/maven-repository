package com.ice.framework.common.base;

/**
 * @author wangwei
 * @Date 2023/11/8 16:18
 */
public interface BaseEnum {

    String getCode();
}

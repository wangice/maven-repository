package com.ice.framework.common.annotation;

import java.lang.annotation.*;

/**
 * @author wangwei
 * @Date 2021/12/22 17:09
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface AutoResult {
    boolean value() default true;
}
package com.ice.framework.common.exception;

import com.ice.framework.common.constant.ErrorCode;

/**
 * @author wangwei
 * @Date 2021/12/20 15:22
 */
public class IdempotentException extends BusinessException {

    public IdempotentException() {
        super(ErrorCode.IDEMPOTENT_CHECK.getCode(), ErrorCode.IDEMPOTENT_CHECK.getMessage());
    }

    public IdempotentException(String message) {
        super(ErrorCode.IDEMPOTENT_CHECK.getCode(), message);
    }

    public IdempotentException(String message, Object... values) {
        super(ErrorCode.IDEMPOTENT_CHECK.getCode(), message, values);
    }
}

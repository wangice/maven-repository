package com.ice.framework.common.constant;

/**
 * @author wangwei
 * @Date 2021/12/30 17:22
 */
public interface IResultCode {
    String getCode();

    String getMessage();
}

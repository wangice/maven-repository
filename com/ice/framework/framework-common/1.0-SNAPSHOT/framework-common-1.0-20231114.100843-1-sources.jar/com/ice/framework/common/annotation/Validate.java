package com.ice.framework.common.annotation;

import java.lang.annotation.*;

/**
 * @author wangwei
 * @Date 2023/11/9 10:22
 */
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Validate {
    String value() default "";

    String desc() default "";
}
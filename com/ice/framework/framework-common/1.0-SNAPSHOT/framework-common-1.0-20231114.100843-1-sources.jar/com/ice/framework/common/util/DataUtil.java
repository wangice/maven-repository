package com.ice.framework.common.util;

import java.util.Collection;
import java.util.Map;

/**
 * @author wangwei
 * @Date 2021/12/20 14:58
 */
public class DataUtil {

    public static boolean isBaseType(Class<?> clazz) {
        if (clazz.isPrimitive()) {
            return true;
        } else {
            return clazz.getName().startsWith("java.lang.");
        }
    }

    public static boolean isEmpty(Object object) {
        if (object == null) {
            return true;
        } else if (object instanceof String) {
            return "".equals(object.toString());
        } else if (object instanceof Collection) {
            return ((Collection)object).isEmpty();
        } else if (object instanceof Object[]) {
            return ((Object[])((Object[])object)).length == 0;
        } else if (object instanceof Map) {
            return ((Map)object).isEmpty();
        } else{
            return false;
        }
    }

    public static boolean isNotEmpty(Object value) {
        return !isEmpty(value);
    }
}

package com.ice.framework.common.exception;

import com.ice.framework.common.constant.ErrorCode;

import java.text.MessageFormat;

/**
 * @author wangwei
 * @Date 2021/12/22 18:14
 */
public class ConnectionException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private String code;
    private String message;

    public ConnectionException() {
        this.code = ErrorCode.SERVER_NOT_AVAILABLE.getCode();
        this.message = ErrorCode.SERVER_NOT_AVAILABLE.getMessage();
    }

    public ConnectionException(String message) {
        super(message);
        this.code = ErrorCode.SERVER_NOT_AVAILABLE.getCode();
        this.message = ErrorCode.SERVER_NOT_AVAILABLE.getMessage();
        this.message = message;
    }

    public ConnectionException(String message, Object... values) {
        this(MessageFormat.format(message, values));
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

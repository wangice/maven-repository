package com.ice.framework.common.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;

import java.util.List;

/**
 * 对象之间转换工具类
 */
public class ObjectTransformUtil {
    
    /**
     * 将给定对象转化为目标对象
     *
     * @param obj         需要转化的对象
     * @param targetClazz 目标对象
     * @return 目标对象
     * @Author wangwei
     * @Date 2021/4/2
     */
    public static <S, T> T transfer(S obj, Class<T> targetClazz) {
        return JSON.parseObject(JSON.toJSONString(obj), targetClazz);
    }

    /**
     * 使用指定的日期格式化规则来转化对象
     *
     * @param obj         需要转化的对象
     * @param targetClazz
     * @param dataFormat
     * @param <S>
     * @param <T>
     * @return
     * @Author wangwei
     * @Date 2021/4/2
     */
    public static <S, T> T transferWithDataFormat(S obj, Class<T> targetClazz, String dataFormat) {
        return JSON.parseObject(JSON.toJSONStringWithDateFormat(obj, dataFormat, SerializerFeature.WriteDateUseDateFormat), targetClazz);
    }

    /**
     * 将集合转化为目标对象
     *
     * @param list        需要转化的对象
     * @param targetClazz 目标对象
     * @return 目标对象
     * @Author wangwei
     * @Date 2021/4/2
     */
    public static <S, T> List<T> transferList(List<S> list, Class<T> targetClazz) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        return JSON.parseArray(JSON.toJSONString(list), targetClazz);
    }

}

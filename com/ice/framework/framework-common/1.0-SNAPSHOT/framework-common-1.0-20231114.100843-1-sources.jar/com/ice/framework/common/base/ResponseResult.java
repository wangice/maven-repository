package com.ice.framework.common.base;

import com.ice.framework.common.constant.ErrorCode;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wangwei
 * @Date 2021/12/20 15:15
 */
@Data
public class ResponseResult<T> implements Serializable {
    private static final long serialVersionUID = -7512811372147847486L;

    private String requestId = null;
    private String errorCode;
    private String errorMsg;
    private T data;

    public ResponseResult() {
        this.errorCode = ErrorCode.SUCCESS.getCode();
        this.errorMsg = ErrorCode.SUCCESS.getMessage();
    }

    public ResponseResult(T data) {
        this.errorCode = ErrorCode.SUCCESS.getCode();
        this.errorMsg = ErrorCode.SUCCESS.getMessage();
        this.data = data;
    }

    public ResponseResult(String errorCode, String errorMsg) {
        this.errorCode = ErrorCode.SUCCESS.getCode();
        this.errorMsg = ErrorCode.SUCCESS.getMessage();
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public ResponseResult(String errorCode, String errorMsg, T data) {
        this.errorCode = ErrorCode.SUCCESS.getCode();
        this.errorMsg = ErrorCode.SUCCESS.getMessage();
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
        this.data = data;
    }

    public boolean getSuccess(){
        return ErrorCode.SUCCESS.getCode().equals(this.errorCode);
    }
}

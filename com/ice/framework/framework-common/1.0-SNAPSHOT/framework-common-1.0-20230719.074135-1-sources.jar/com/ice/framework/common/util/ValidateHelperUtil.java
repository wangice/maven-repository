package com.ice.framework.common.util;

import cn.hutool.core.util.ReflectUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ice.framework.common.constant.ErrorCode;
import com.ice.framework.common.exception.BusinessException;

import java.util.List;

/**
 * 这种情况是不使用Hibernate注解等框架的方式
 * 使用方式： ValidateHelper.validateNull(user, new String[]{"name"});  名称不能为空，为空则会抛异常
 *
 * @author wangwei
 * @Date 2022/1/4 15:49
 */
public class ValidateHelperUtil {
    /**
     * 通用非空参数校验
     * @return 返回校验信息
     */
    public static void validateNull(Object bean, String[] propertyNames) {
        StringBuffer errorMessage = new StringBuffer();

        if (bean == null) {
            throw new BusinessException(ErrorCode.PARAMETER_ERROR.getCode(), "校验的对象不允许为空!");
        }

        //不需要校验参数
        if (propertyNames == null || propertyNames.length == 0) {
            return;
        }

        for (String name : propertyNames) {
            Object value = ReflectUtil.getFieldValue(bean, name);

            if (Assert.isEmpty(value)) {
                errorMessage.append("[").append(name).append("]不能为空;");
            }
        }

        if (errorMessage.length() > 0) {
            throw new BusinessException(ErrorCode.PARAMETER_ERROR.getCode(), errorMessage.toString());
        }
    }

    /**
     * 通用非空参数校验
     * @return 返回校验信息
     */
    public static void validateNull(Object bean, String[] propertyNames, String titles[]) {
        StringBuffer errorMessage = new StringBuffer();

        if (bean == null) {
            throw new BusinessException(ErrorCode.PARAMETER_ERROR.getCode(), "校验的对象不允许为空!");
        }

        //不需要校验参数
        if (propertyNames == null || propertyNames.length == 0) {
            return;
        }

        if (titles.length != propertyNames.length) {
            throw new BusinessException(ErrorCode.PARAMETER_ERROR.getCode(), "校验的参数属性与描述长度必须一致!");
        }

        for (int i = 0; i < propertyNames.length; i++) {
            Object value = ReflectUtil.getFieldValue(bean, propertyNames[i]);

            if (Assert.isEmpty(value)) {
                errorMessage.append("[").append(titles[i]).append("]不能为空;");
            }
        }

        if (errorMessage.length() > 0) {
            throw new BusinessException(ErrorCode.PARAMETER_ERROR.getCode(), errorMessage.toString());
        }
    }

    /**
     * 通用非空参数校验
     * @return 返回校验信息
     */
    public static void validateNull(JSONObject bean, String[] propertyNames) {
        StringBuffer errorMessage = new StringBuffer();

        if (bean == null) {
            throw new BusinessException(ErrorCode.PARAMETER_ERROR.getCode(), "校验的对象不允许为空!");
        }

        //不需要校验参数
        if (propertyNames == null || propertyNames.length == 0) {
            return;
        }

        for (String name : propertyNames) {
            Object value = bean.get(name);

            if (Assert.isEmpty(value)) {
                errorMessage.append("[").append(name).append("]不能为空;");
            }
        }

        if (errorMessage.length() > 0) {
            throw new BusinessException(ErrorCode.PARAMETER_ERROR.getCode(), errorMessage.toString());
        }
    }

    /**
     * 校验列表
     *
     * @author liaohongjian
     * @since 2017年8月14日
     * @param beanList
     * @param properties
     */
    public static void validateNullList(List<?> beanList, String[] properties) {
        if (Assert.isEmpty(beanList)) {
            throw new BusinessException(ErrorCode.PARAMETER_ERROR.getCode(), "请求参列表象不能为空.");
        }

        for (Object bean : beanList) {
            validateNull(bean, properties);
        }
    }

    /**
     * 校验列表
     *
     * @author liaohongjian
     * @since 2017年8月14日
     * @param properties
     */
    public static void validateNullList(JSONArray jsonArray, String[] properties) {
        if (Assert.isEmpty(jsonArray)) {
            throw new BusinessException(ErrorCode.PARAMETER_ERROR.getCode(), "请求参列表象不能为空.");
        }

        for (int i = 0; i < jsonArray.size(); i++) {
            validateNull(jsonArray.getJSONObject(i), properties);
        }
    }
}

package com.ice.framework.common.lock;

/**
 * 分布式锁处理器
 * 
 * @author wangwei
 * @Date 2024/6/14 15:44
 */
public interface LockExecutor<T> {
    /**
     * 续期，目前只有redisson支持，且expire参数为-1才会续期
     *
     * @return 是否续期
     */
    default boolean renewal() {
        return false;
    }

    /**
     * 尝试获取锁
     * 
     * @param lockString
     *            锁标识
     * @param lockValue
     *            锁值
     * @param expire
     *            过期时间
     * @param timeout
     *            获取锁超时时间
     * @return
     */
    T tryLock(String lockString, String lockValue, long expire, long timeout) throws Exception;

    T tryLock(String lockString, String lockValue, long expire) throws Exception;

    /**
     * 解锁
     *
     * 为何解锁需要校验lockValue 客户端A加锁，一段时间之后客户端A解锁，在执行releaseLock之前，锁突然过期了。 此时客户端B尝试加锁成功，然后客户端A再执行releaseLock方法，则将客户端B的锁给解除了。
     *
     * @param lockString
     *            锁标识
     * @param lockValue
     *            锁值
     * @param lockInstance
     *            锁实例
     * @return 是否释放成功
     */
    boolean releaseLock(String lockString, String lockValue, T lockInstance) throws Exception;

    default T obtainLockInstance(boolean locked, T lockInstance) {
        return locked ? lockInstance : null;
    }
}

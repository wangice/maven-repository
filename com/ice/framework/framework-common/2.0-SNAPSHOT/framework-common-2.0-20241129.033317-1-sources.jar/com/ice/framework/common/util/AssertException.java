package com.ice.framework.common.util;

import com.ice.framework.common.constant.IResultCode;
import com.ice.framework.common.exception.BusinessException;

/**
 * 断言抛出异常
 * 
 * @author wangwei
 * @Date 2022/1/4 14:51
 */
public class AssertException {

    /**
     * 是否true 断言
     */
    public static void isTrue(boolean expression, IResultCode resultCode) {
        if (!expression) {
            throw new BusinessException(resultCode);
        }
    }

    /**
     * 是否true 断言
     */
    public static void isTrue(boolean expression, String code, String msg) {
        if (!expression) {
            throw new BusinessException(code, msg);
        }
    }

    public static void isTrue(boolean expression, String msg) {
        if (!expression) {
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * 是否true 断言
     */
    public static void isTrue(boolean expression, IResultCode resultCode, String msg) {
        isTrue(expression, resultCode.getCode(), msg);
    }

    /**
     * 为空断言
     */
    public static void isNull(Object object, IResultCode resultCode) {
        if (object != null) {
            throw new BusinessException(resultCode);
        }
    }

    /**
     * 为空断言
     */
    public static void isNull(Object object, String code, String msg) {
        if (object != null) {
            throw new BusinessException(code, msg);
        }
    }

    /**
     * 为空断言
     */
    public static void isNull(Object object, IResultCode resultCode, String msg) {
        isNull(object, resultCode.getCode(), msg);
    }

    /**
     * 不为空断言
     */
    public static void notNull(Object object, IResultCode resultCode) {
        if (object == null) {
            throw new BusinessException(resultCode);
        }
    }

    /**
     * 不为空断言
     */
    public static void notNull(Object object, String code, String msg) {
        if (object == null) {
            throw new BusinessException(code, msg);
        }
    }

    /**
     * 不为空断言
     */
    public static void notNull(Object object, IResultCode resultCode, String msg) {
        notNull(object, resultCode.getCode(), msg);
    }

    /**
     * 不为空断言 根据对象类型判断对象是否为空
     *
     * @param object
     * @param resultCode
     */
    public static void isNotEmpty(Object object, IResultCode resultCode) {
        if (Assert.isEmpty(object)) {
            throw new BusinessException(resultCode);
        }
    }

    /**
     * 不为空断言 根据对象类型判断对象是否为空
     *
     * @param object
     * @param code
     * @param msg
     */
    public static void isNotEmpty(Object object, String code, String msg) {
        if (Assert.isEmpty(object)) {
            throw new BusinessException(code, msg);
        }
    }

    /**
     * 不为空断言 根据对象类型判断对象是否为空
     *
     * @param object
     * @param resultCode
     * @param msg
     */
    public static void isNotEmpty(Object object, IResultCode resultCode, String msg) {
        isNotEmpty(object, resultCode.getCode(), msg);
    }

    /**
     * 不为空断言 根据对象类型判断对象是否为空
     *
     * @param object
     * @param code
     * @param msg
     */
    public static void isNotEmpty(Object object, String msg) {
        if (Assert.isEmpty(object)) {
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * 为空断言
     * 
     * @Author wangwei
     * @Date 2023/4/6
     */
    public static void isEmpty(Object object, String msg) {
        if (Assert.isNotEmpty(object)) {
            throw new IllegalArgumentException(msg);
        }
    }
}

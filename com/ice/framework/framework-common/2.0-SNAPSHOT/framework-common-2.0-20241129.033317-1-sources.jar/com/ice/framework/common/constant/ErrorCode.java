package com.ice.framework.common.constant;

/**
 * @author wangwei
 * @Date 2021/12/20 15:14
 */
public enum ErrorCode implements IResultCode {
    SUCCESS("0", "成功"), COMMON_ERROR("9", "通用异常"), PARAM_ERROR("10", "参数错误"), ERROR("11", "系统繁忙，请稍后重试"),
    TOKEN_CHECKFALSE("12", "Token无效或已过期,需重新获取"), PARAMETER_ERROR("13", "请求参数校验错误，请检查入参是否正确"),
    SERVER_NOT_AVAILABLE("14", "服务器网络异常，请稍后重试"), SERVER_NOT_FOUND("15", "服务不存在"), DATA_NOT_FOUND("16", "数据不存在"),
    DATA_FOUND_DUPLICATE("17", "找到多条数据"), DATA_SAVE_DUPLICATE("18", "重复提交数据"), RESOURCE_NOT_FOUND("19", "资源不存在"),
    RESOURCE_UPLOAD_ERROR("20", "文件上传失败"), CONCURRENT_UPDATE("21", "并发更新异常,请稍后重试"), SIGN_ERROR("22", "请求签名错误"),
    IDEMPOTENT_CHECK("23", "请求频繁请稍候重试！"), SQL_EXCEPTION("24", "SQL访问异常！"), DATA_NOT_MATCH("25", "数据发生变化，请刷新后重试！"),
    DATA_STATUS_CHANGED("26", "数据发生变化，请刷新后重试！"), LOCK_FAILED("27", "获取分布式锁失败");

    private String code;
    private String message;

    private ErrorCode(String message) {
        this.message = message;
    }

    private ErrorCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public String getCode() {
        return this.code == null ? this.name().substring(1) : this.code;
    }

    @Override
    public String getMessage() {
        return this.message;
    }

    public boolean equals(String errorCode) {
        return this.code.equals(errorCode);
    }
}

package com.ice.framework.common.context;

import java.util.UUID;

/**
 * 系统公共常量
 * 
 * @author wangwei
 * @Date 2024/5/11 11:15
 */
public class RequestContext {
    /** 保存请求标识 */
    public static final String REQUEST_ID = "_REQUEST_ID_";

    /** 保存请求的日志信息 */
    public static final String REQUEST_LOG_INFO = "_REQUEST_LOG_INFO_";

    /** 保存请求的开始时间 */
    public static final String REQUEST_STARTTIME = "_REQUEST_STARTTIME_";

    /** 保存请求上文的用户信息 */
    public static final String REQUEST_USERINFO = "_REQUEST_USER_INFO_";

    /** 请求头传递 用户名称 */
    public static final String AUTHORIZATION_USERNAME = "USERNAME";

    /** 请求头传递 用户代码 */
    public static final String AUTHORIZATION_USERCODE = "USERCODE";

    /** 请求头传递 用户ID */
    public static final String AUTHORIZATION_USERID = "USERID";

    /** 请求头传递 用户TOKEN */
    public static final String AUTHORIZATION_TOKEN = "Authorization";

    /**
     * 获取当前线程的请求ID
     */
    public static String getRequestId() {
        RequestContextData context = RequestContextThreadLocal.getContext();

        String requestId = null;
        if (context != null) {
            requestId = context.getRequestId();
        }

        if (requestId == null) {
            requestId = UUID.randomUUID().toString().replaceAll("-", "");
        }

        RequestContextThreadLocal.setRequestId(requestId);

        return requestId;
    }

    /**
     * 获取当前线程的用户信息
     */
    public static CustomerUser getCurrentUser() {
        RequestContextData context = RequestContextThreadLocal.getContext();
        return context == null ? null : context.getUser();
    }
}

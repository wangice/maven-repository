package com.ice.framework.common.exception;

import java.text.MessageFormat;

import com.ice.framework.common.constant.IResultCode;

import lombok.Data;

/**
 * @author wangwei
 * @Date 2021/12/20 15:20
 */
@Data
public class BusinessException extends RuntimeException {
    private String code;
    private String message;

    public BusinessException() {
        this.code = "11";
    }

    public BusinessException(String message) {
        super(message);
        this.code = "11";
        this.message = message;
    }

    public BusinessException(String errorCode, String message) {
        super(message);
        this.code = "11";
        this.code = errorCode;
        this.message = message;
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
        this.code = "11";
        this.message = message;
    }

    public BusinessException(String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.code = "11";
        this.code = errorCode;
        this.message = message;
    }

    public BusinessException(String errorCode, String message, Object... values) {
        this(errorCode, MessageFormat.format(message, values));
    }

    public BusinessException(IResultCode errorEnum) {
        this(errorEnum.getCode(), errorEnum.getMessage());
    }

    public BusinessException(IResultCode errorEnum, Throwable cause) {
        this(errorEnum.getCode(), errorEnum.getMessage(), cause);
    }

    public BusinessException(IResultCode errorEnum, Object... values) {
        this(errorEnum.getCode(), errorEnum.getMessage(), values);
    }
}

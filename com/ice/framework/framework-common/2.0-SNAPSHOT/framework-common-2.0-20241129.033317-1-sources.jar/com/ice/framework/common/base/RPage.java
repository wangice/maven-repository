package com.ice.framework.common.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;

import org.apache.commons.collections4.CollectionUtils;

import com.ice.framework.common.util.ObjectTransformUtil;

/**
 * @author zhigang.peng
 * @date 2019-11-13
 */
public class RPage<T> implements Serializable {

    private static final long serialVersionUID = 8545996863226528798L;

    /**
     * 查询条件
     */
    private T parameter;

    /**
     * 数据结果
     */
    private List<T> records;

    /**
     * 总数据条数
     */
    private long total;

    /**
     * 每页条数
     */
    private long size;

    /**
     * 当前页码
     */
    private long current;

    /**
     * 总页数
     */
    private long pages;

    public RPage() {
        this.records = Collections.emptyList();
        this.total = 0L;
        this.size = 10L;
        this.current = 1L;
    }

    public RPage(long current, long size) {
        this(current, size, 0L);
    }

    public RPage(long current, long size, long total) {
        this.records = Collections.emptyList();
        this.total = total;
        this.size = size;
        this.current = current;
    }

    public RPage(T parameter, long current, long size) {
        this.parameter = parameter;
        this.size = size;
        this.current = current;
    }

    public T getParameter() {
        return parameter;
    }

    public void setParameter(T parameter) {
        this.parameter = parameter;
    }

    public List<T> getRecords() {
        return records;
    }

    public void setRecords(List<T> records) {
        this.records = records;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public long getCurrent() {
        return current;
    }

    public void setCurrent(long current) {
        this.current = current;
    }

    public long getPages() {
        return pages;
    }

    public void setPages(long pages) {
        this.pages = pages;
    }

    /**
     * 将分页结果将成其他类型的分页结果
     * 
     * @param page
     * @param targetClass
     * @param <T>
     * @param <S>
     * @return
     */
    public static <T, S> RPage<S> transmit(RPage<T> page, Class<S> targetClass) {
        return transmitList(page, (objList) -> ObjectTransformUtil.transferList(objList, targetClass));
    }

    /**
     * 将分页结果将成其他类型的分页结果
     * 
     * @param page
     * @param tsFunction
     * @param <T>
     * @param <S>
     * @return
     */
    public static <T, S> RPage<S> transmit(RPage<T> page, Function<T, S> tsFunction) {
        if (page == null) {
            return null;
        }
        RPage<S> resultPage = new RPage<>();
        resultPage.setCurrent(page.getCurrent());
        resultPage.setTotal(page.getTotal());
        resultPage.setSize(page.getSize());
        resultPage.setPages(page.getPages());
        if (CollectionUtils.isNotEmpty(page.getRecords())) {
            List<S> list = new ArrayList<>();
            for (T t : page.getRecords()) {
                S s = tsFunction.apply(t);
                list.add(s);
            }
            resultPage.setRecords(list);
        }
        return resultPage;
    }

    /**
     * 将分页结果将成其他类型的分页结果
     * 
     * @param page
     * @param tsFunction
     * @param <T>
     * @param <S>
     * @return
     */
    public static <T, S> RPage<S> transmitList(RPage<T> page, Function<List<T>, List<S>> tsFunction) {
        if (page == null) {
            return null;
        }
        RPage<S> resultPage = new RPage<>();
        resultPage.setCurrent(page.getCurrent());
        resultPage.setTotal(page.getTotal());
        resultPage.setSize(page.getSize());
        resultPage.setPages(page.getPages());
        if (CollectionUtils.isNotEmpty(page.getRecords())) {
            resultPage.setRecords(tsFunction.apply(page.getRecords()));
        }
        return resultPage;
    }

    /**
     * 返回一个空结果
     * 
     * @param <T>
     * @return
     */
    public static <T> RPage<T> emptyPage() {
        RPage<T> resultPage = new RPage<>();
        resultPage.setCurrent(1);
        resultPage.setRecords(null);
        resultPage.setTotal(0);
        resultPage.setSize(0);
        resultPage.setCurrent(1);
        resultPage.setPages(0l);
        return resultPage;
    }
}

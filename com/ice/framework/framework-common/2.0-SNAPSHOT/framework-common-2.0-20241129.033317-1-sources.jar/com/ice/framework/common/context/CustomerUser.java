package com.ice.framework.common.context;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * 自定义用户
 * 
 * @author wangwei
 * @Date 2024/5/11 11:10
 */
@Accessors(chain = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CustomerUser implements Serializable {

    private static final long serialVersionUID = 1577431607185375796L;

    private String userCode;

    private String userName;
}

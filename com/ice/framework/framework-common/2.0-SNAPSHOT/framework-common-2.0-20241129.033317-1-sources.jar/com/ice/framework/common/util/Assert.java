package com.ice.framework.common.util;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 断言工具类
 * 
 * @author wangwei
 * @Date 2022/1/4 14:24
 */
public class Assert {

    public static Boolean isEmpty(Object obj) {
        if (obj == null) {
            return true;
        }
        if (obj instanceof String) {
            return isEmptyContainNull(obj.toString());
        }
        if (obj instanceof Collection) {
            return ((Collection)obj).isEmpty();
        }
        if (obj instanceof Object[]) {
            return ((Object[])obj).length == 0;
        }
        if (obj instanceof Map) {
            return ((Map)obj).isEmpty();
        }
        return false;
    }

    public static Boolean isNotEmpty(Object obj) {
        return !isEmpty(obj);
    }

    /**
     * list集合是否不为空且集合元素也不存在空值
     *
     * @param objs
     * @return
     */
    public static final boolean isNoneEmpty(List<Object> objs) {
        return !isAnyEmpty(objs);
    }

    /**
     * list集合是否为空，或集合元素存在一个空值
     *
     * @param objs
     * @return
     */
    public static final boolean isAnyEmpty(List<Object> objs) {
        if (isEmpty(objs)) {
            return true;
        }
        return isAnyEmpty(objs.toArray());
    }

    /**
     * 判断目标对象列表的元素全部不为空值(即: 没有任何一个为空值)
     * 
     * <pre>
     * 空值包括: null、空字符串(即: "")、若干空格组成的字符串(如: "  ")
     * </pre>
     *
     * @param objs
     * @return
     */
    public static final boolean isNoneEmpty(Object... objs) {
        if (objs == null || objs.length == 0) {
            return false;
        }
        for (Object obj : objs) {
            if (isEmpty(obj)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 判断目标对象列表的元素是否存在空值
     * 
     * <pre>
     * 空值包括: null、空字符串(即: "")、若干空格组成的字符串(如: "  ")
     * </pre>
     *
     * @param objs
     * @return
     */
    public static final boolean isAnyEmpty(Object... objs) {
        if (objs == null || objs.length == 0) {
            return true;
        }
        for (Object obj : objs) {
            if (isEmpty(obj)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断目标对象列表的元素是否全部为空值
     * 
     * <pre>
     * 空值包括: null、空字符串(即: "")、若干空格组成的字符串(如: "  ")
     * </pre>
     *
     * @param objs
     * @return
     */
    public static final boolean isAllEmpty(Object... objs) {
        if (objs == null || objs.length == 0) {
            return true;
        }
        for (Object obj : objs) {
            if (!isEmpty(obj)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 是否为空、空串、null true是 false不是
     *
     * @param input
     * @return
     */
    public static final boolean isEmptyContainNull(String input) {
        return input == null || input.trim().isEmpty() || input.trim().equalsIgnoreCase("null");
    }

}

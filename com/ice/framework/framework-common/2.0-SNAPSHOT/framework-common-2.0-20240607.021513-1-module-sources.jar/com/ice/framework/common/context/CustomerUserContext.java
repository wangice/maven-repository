package com.ice.framework.common.context;

/**
 * 当前请求上下文对象。
 *
 * 通过当前线程的对象，保存用户上下文。
 * @author wangwei
 * @Date 2024/5/11 11:12
 */
public class CustomerUserContext {

    /**
     * 获取当前线程用户
     */
    public static CustomerUser get() {
        return RequestContext.getCurrentUser();
    }

    /**
     * 获取当前线程的用户信息，业务系统可继承User对象进行拓展，
     *
     * 并重写 {@code} UserInfoProvider#check} 方法，返回自定义用户信息。
     *
     */
    @SuppressWarnings("unchecked")
    public static <T> T get(Class<? extends CustomerUser> userClazz) {
        return (T) get();
    }

    /**
     * 获取当前用户信息
     */
    public static String getCurrentUserCode() {
        CustomerUser user = get();
        return user == null ? null : user.getUserCode();
    }

    /**
     * 获取当前用户名称
     */
    public static String getCurrentUserName() {
        CustomerUser user = get();
        return user == null ? null : user.getUserName();
    }
}

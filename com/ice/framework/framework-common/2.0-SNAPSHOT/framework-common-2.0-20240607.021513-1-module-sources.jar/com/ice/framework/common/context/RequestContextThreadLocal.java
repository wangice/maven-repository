package com.ice.framework.common.context;

/**
 * @author wangwei
 * @Date 2021/12/22 17:56
 */
public class RequestContextThreadLocal {
    private static final ThreadLocal<RequestContextData> threadLocal = new ThreadLocal();

    public RequestContextThreadLocal() {
    }

    public static void setRequestId(String requestId) {
        RequestContextData context = getContext();
        if (context == null) {
            context = new RequestContextData();
        }

        context.setRequestId(requestId);
        threadLocal.set(context);
    }


    public static void setCustomerUser(CustomerUser obj) {
        getContext().setUser(obj);
    }

    public static RequestContextData getContext() {
        RequestContextData context = threadLocal.get();
        if (context == null) {
            context = new RequestContextData();
            threadLocal.set(context);
        }
        return context;
    }

    public static void remove() {
        threadLocal.remove();
    }
}

package com.ice.framework.common.context;

import lombok.Data;

import java.io.Serializable;

/**
 * @author wangwei
 * @Date 2021/12/22 17:56
 */
@Data
public class RequestContextData implements Serializable {

    private static final long serialVersionUID = 5939299435768132656L;

    private String requestId;

    private CustomerUser user;


}

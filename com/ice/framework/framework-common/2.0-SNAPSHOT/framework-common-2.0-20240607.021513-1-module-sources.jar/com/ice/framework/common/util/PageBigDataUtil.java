package com.ice.framework.common.util;

import com.ice.framework.common.base.RPage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StopWatch;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 *
 * @author wangwei
 * @Date 2024/5/10 14:12
 */
@Slf4j
public class PageBigDataUtil {

    /**
     * @param queryParam 查询条件
     * @param function 分页查询
     * @return
     */
    public static <T> List<T> pageBigData(T queryParam, Function<RPage<T>, RPage<T>> function) {
        return PageBigDataUtil.pageBigData(queryParam, function, 500);
    }

    /**
     * @param queryParam 查询条件
     * @param function 分页查询
     * @size size 限制条数
     * @return
     */
    public static <T> List<T> pageBigData(T queryParam, Function<RPage<T>, RPage<T>> function, int size) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        List<T> results = new ArrayList<>();
        int current = 1;
        for (; ; ) {
            RPage<T> pageParam = new RPage<>();
            pageParam.setSize(size);
            pageParam.setCurrent(current);
            pageParam.setParameter(queryParam);
            RPage<T> result = function.apply(pageParam);
            log.info("--------导入开始，本批次共：{} 轮，当前第{}轮", result.getPages(), current);
            if (MiscUtil.isEmpty(result) || MiscUtil.isEmpty(result.getRecords())) {
                break;
            }
            results.addAll(result.getRecords());
            if ((long) size * current >= result.getTotal()) {
                break;
            }
            current++;
        }
        stopWatch.stop();
        log.info("批次任务已结束，分页批次任务：{}，获取总记录数：{}，总耗时：{}秒", current, results.size(), stopWatch.getTotalTimeSeconds());
        return results;
    }

    /**
     *
     * @param queryParam 查询条件
     * @param function 分页查询
     * @param consumer 批次消费
     * @param <T>
     */
    public static <T> void handleBigData(T queryParam, Function<RPage<T>, RPage<T>> function, Consumer<List<T>> consumer) {
        PageBigDataUtil.handleBigData(queryParam, function, consumer, 500);
    }

    /**
     *
     * @param queryParam 查询条件
     * @param function 分页查询
     * @param consumer 批次消费
     * @param size 限制条数
     * @param <T>
     */
    public static <T> void handleBigData(T queryParam, Function<RPage<T>, RPage<T>> function, Consumer<List<T>> consumer, int size) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        int current = 1;
        for (; ; ) {
            RPage<T> pageParam = new RPage<>();
            pageParam.setSize(size);
            pageParam.setCurrent(current);
            pageParam.setParameter(queryParam);
            RPage<T> result = function.apply(pageParam);
            if (MiscUtil.isEmpty(result)) {
                break;
            }
            // 业务处理
            consumer.accept(result.getRecords());
            log.info("--------导入开始，本批次共：{} 轮，当前第{}轮", result.getPages(), current);
            if ((long) size * current >= result.getTotal()) {
                break;
            }
            current++;
        }
        stopWatch.stop();
        log.info("批次任务已结束，总耗时：{}秒", stopWatch.getTotalTimeSeconds());
    }
}

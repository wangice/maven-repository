package com.ice.framework.gateway.dev;

import org.springframework.cloud.gateway.config.GatewayLoadBalancerProperties;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.ReactiveLoadBalancerClientFilter;
import org.springframework.cloud.loadbalancer.support.LoadBalancerClientFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

/**
 * gateway负载均衡时，添加filter
 *
 * @author wangwei
 * @Date 2024/7/4 11:19
 */
@Profile("dev")
@Component
public class DevReactiveLoadBalancerClientFilter extends ReactiveLoadBalancerClientFilter {

    public DevReactiveLoadBalancerClientFilter(LoadBalancerClientFactory clientFactory,
        GatewayLoadBalancerProperties properties) {
        super(clientFactory, properties);
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        try {
            DevWebFluxContext.set(exchange);
            return super.filter(exchange, chain);
        } finally {
            DevWebFluxContext.clean();
        }
    }
}

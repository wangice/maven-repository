package com.ice.framework.openfeign.config;

import com.ice.framework.openfeign.decoder.ResponseResultDecoder;
import feign.codec.Decoder;
import feign.optionals.OptionalDecoder;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 解码器配置
 * 需要全局配置， 需要实例化对象
 * 部分feign时：
 *         @FeignClient(value = "xxx",configuration = FeignClientDecodeConfiguration.class)
 *         public interface XxxClient {}
 * 解码对象必须是已 ResponseResult返回的数据为准
 * @author wangwei
 * @Date 2022/10/27 12:34
 */
public class FeignClientDecodeConfiguration {

    @Bean
    public Decoder feignDecoder(ObjectProvider<HttpMessageConverters> messageConverters) {
        return new OptionalDecoder((new ResponseEntityDecoder(new ResponseResultDecoder(new SpringDecoder(messageConverters)))));
    }
}

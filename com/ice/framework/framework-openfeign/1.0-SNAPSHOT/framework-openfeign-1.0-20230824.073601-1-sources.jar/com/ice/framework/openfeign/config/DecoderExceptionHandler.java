package com.ice.framework.openfeign.config;

import com.ice.framework.common.base.ResponseResult;
import com.ice.framework.common.constant.ErrorCode;
import com.ice.framework.common.exception.CommonException;
import feign.codec.DecodeException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.*;

/**
 * 加载的顺序一定要高于 framework-web,因为ResponseExceptionHandler捕获了Exception异常
 * @author wangwei
 * @Date 2022/10/27 12:42
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(annotations = {RestController.class})
public class DecoderExceptionHandler {

    @ResponseBody
    @ExceptionHandler(DecodeException.class)
    public ResponseResult<Object> exceptionHandler(Exception e) {
        if (e.getCause() instanceof CommonException) {
            CommonException commonException = (CommonException) e.getCause();
            ResponseResult responseResult = new ResponseResult(commonException.getCode(), commonException.getMessage());
            return responseResult;
        }
        return new ResponseResult(ErrorCode.COMMON_ERROR.getCode(), e.getMessage());
    }
}

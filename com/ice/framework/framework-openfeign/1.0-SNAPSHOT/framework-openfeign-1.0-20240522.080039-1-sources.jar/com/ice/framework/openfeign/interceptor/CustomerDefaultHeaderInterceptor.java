package com.ice.framework.openfeign.interceptor;

import com.ice.framework.common.context.CustomerUser;
import com.ice.framework.common.context.CustomerUserContext;
import com.ice.framework.common.context.RequestContext;
import com.ice.framework.common.util.MiscUtil;
import feign.RequestInterceptor;
import feign.RequestTemplate;

/**
 * 自定义Header拦截器
 * @author wangwei
 * @Date 2024/5/11 14:26
 */
public class CustomerDefaultHeaderInterceptor implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate template) {
        CustomerUser customerUser = CustomerUserContext.get();
        if (customerUser != null) {
            template.header(RequestContext.AUTHORIZATION_USERCODE, customerUser.getUserCode());
            template.header(RequestContext.AUTHORIZATION_USERNAME, customerUser.getUserName());
        }
        String requestId = RequestContext.getRequestId();
        if (MiscUtil.isNotEmpty(requestId)) {
            template.header(RequestContext.REQUEST_ID, requestId);
        }
    }
}

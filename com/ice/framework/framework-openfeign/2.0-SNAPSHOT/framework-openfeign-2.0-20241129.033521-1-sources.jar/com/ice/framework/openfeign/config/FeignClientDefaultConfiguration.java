package com.ice.framework.openfeign.config;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.HttpMessageConverterCustomizer;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.context.annotation.Bean;

import com.ice.framework.openfeign.decoder.ResponseResultDecoder;
import com.ice.framework.openfeign.interceptor.CustomerDefaultHeaderInterceptor;

import feign.codec.Decoder;
import feign.optionals.OptionalDecoder;

/**
 * @author wangwei
 * @Date 2022/10/27 12:34
 */
public class FeignClientDefaultConfiguration {

    /**
     * 解码器配置 需要全局配置， @EnableFeignClients(defaultConfiguration={FeignClientDecodeConfiguration.class}) 部分feign时：
     * 
     * @FeignClient(value = "xxx",configuration = FeignClientDecodeConfiguration.class) public interface XxxClient {}
     *                    解码对象必须是已 ResponseResult返回的数据为准
     * @param messageConverters
     * @param customizers
     * @return
     */
    @Bean
    public Decoder feignDecoder(ObjectProvider<HttpMessageConverters> messageConverters,
        ObjectProvider<HttpMessageConverterCustomizer> customizers) {
        return new OptionalDecoder(
            (new ResponseEntityDecoder(new ResponseResultDecoder(new SpringDecoder(messageConverters, customizers)))));
    }

    /**
     * Header 拦截器，当存在登录用户时，则将用户信息传递
     * 
     * @return
     */
    @Bean
    public CustomerDefaultHeaderInterceptor customerDefaultHeaderInterceptor() {
        return new CustomerDefaultHeaderInterceptor();
    }
}

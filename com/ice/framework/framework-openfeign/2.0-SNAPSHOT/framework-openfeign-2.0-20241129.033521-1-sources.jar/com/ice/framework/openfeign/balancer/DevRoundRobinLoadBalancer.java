package com.ice.framework.openfeign.balancer;

import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.DefaultResponse;
import org.springframework.cloud.client.loadbalancer.EmptyResponse;
import org.springframework.cloud.client.loadbalancer.Request;
import org.springframework.cloud.client.loadbalancer.RequestDataContext;
import org.springframework.cloud.client.loadbalancer.Response;
import org.springframework.cloud.commons.util.InetUtils;
import org.springframework.cloud.loadbalancer.core.NoopServiceInstanceListSupplier;
import org.springframework.cloud.loadbalancer.core.ReactorServiceInstanceLoadBalancer;
import org.springframework.cloud.loadbalancer.core.SelectedInstanceCallback;
import org.springframework.cloud.loadbalancer.core.ServiceInstanceListSupplier;
import org.springframework.cloud.loadbalancer.support.LoadBalancerClientFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import reactor.core.publisher.Mono;

/**
 * dev 环境下，允许路由到本地服务，不存在则访问dev环境中的服务
 * 
 * @author wangwei
 * @Date 2024/7/4 17:33
 */
@Profile("dev")
@Component
public class DevRoundRobinLoadBalancer implements ReactorServiceInstanceLoadBalancer {

    Environment environment;

    LoadBalancerClientFactory loadBalancerClientFactory;

    final AtomicInteger position;

    public String hostAddress;

    public DevRoundRobinLoadBalancer(Environment environment, LoadBalancerClientFactory loadBalancerClientFactory,
        InetUtils inetUtils) {
        this.environment = environment;
        this.loadBalancerClientFactory = loadBalancerClientFactory;
        this.position = new AtomicInteger(new Random().nextInt(1000));
        hostAddress = inetUtils.findFirstNonLoopbackAddress().getHostAddress();
    }

    @Override
    public Mono<Response<ServiceInstance>> choose(Request request) {
        String name = ((RequestDataContext)request.getContext()).getClientRequest().getUrl().getHost();

        ObjectProvider<ServiceInstanceListSupplier> serviceInstanceListSupplierProvider =
            loadBalancerClientFactory.getLazyProvider(name, ServiceInstanceListSupplier.class);

        ServiceInstanceListSupplier supplier =
            serviceInstanceListSupplierProvider.getIfAvailable(NoopServiceInstanceListSupplier::new);
        return supplier.get(request).next()
            .map(serviceInstances -> processInstanceResponse(supplier, serviceInstances));
    }

    private Response<ServiceInstance> processInstanceResponse(ServiceInstanceListSupplier supplier,
        List<ServiceInstance> serviceInstances) {
        Response<ServiceInstance> serviceInstanceResponse = getInstanceResponse(serviceInstances);
        if (supplier instanceof SelectedInstanceCallback && serviceInstanceResponse.hasServer()) {
            ((SelectedInstanceCallback)supplier).selectedServiceInstance(serviceInstanceResponse.getServer());
        }
        return serviceInstanceResponse;
    }

    private Response<ServiceInstance> getInstanceResponse(List<ServiceInstance> instances) {
        if (instances.isEmpty()) {
            return new EmptyResponse();
        }
        int pos = Math.abs(this.position.incrementAndGet());

        for (ServiceInstance instance : instances) {
            if (Objects.equals(hostAddress, instance.getHost())) {
                return new DefaultResponse(instance);
            }
        }

        ServiceInstance instance = instances.get(pos % instances.size());

        return new DefaultResponse(instance);
    }
}

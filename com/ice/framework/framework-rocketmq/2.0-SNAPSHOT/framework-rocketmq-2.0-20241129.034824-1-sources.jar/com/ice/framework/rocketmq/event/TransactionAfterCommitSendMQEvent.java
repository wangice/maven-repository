package com.ice.framework.rocketmq.event;

import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.context.ApplicationEvent;

/**
 * 事务提交后发生mq事件
 * 
 * @author wangwei
 * @Date 2024/9/18 17:47
 */
public class TransactionAfterCommitSendMQEvent extends ApplicationEvent {

    private static final long serialVersionUID = 5885956821347953071L;
    /**
     * 队列名称
     */
    private final String topic;

    /**
     * tag 名称
     */
    private final String tag;

    /**
     * 消息体
     */

    private final Object message;

    private final RocketMQTemplate rocketMQTemplate;

    public TransactionAfterCommitSendMQEvent(Object source, String topic, String tag, Object message,
        RocketMQTemplate rocketMQTemplate) {
        super(source);
        this.topic = topic;
        this.tag = tag;
        this.message = message;
        this.rocketMQTemplate = rocketMQTemplate;
    }

    public TransactionAfterCommitSendMQEvent(Object source, String topic, Object message,
        RocketMQTemplate rocketMQTemplate) {
        super(source);
        this.topic = topic;
        this.tag = null;
        this.message = message;
        this.rocketMQTemplate = rocketMQTemplate;
    }

    public String getTopic() {
        return topic;
    }

    public String getTag() {
        return tag;
    }

    public Object getMessage() {
        return message;
    }

    public RocketMQTemplate getRocketMQTemplate() {
        return rocketMQTemplate;
    }
}

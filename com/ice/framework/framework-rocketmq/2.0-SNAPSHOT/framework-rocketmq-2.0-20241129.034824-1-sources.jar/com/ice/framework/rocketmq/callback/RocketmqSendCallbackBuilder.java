package com.ice.framework.rocketmq.callback;

/**
 * @author wangwei
 * @Date 2024/9/18 17:51
 */
public class RocketmqSendCallbackBuilder {
    public static RocketmqSendCallback commonCallback() {
        return new RocketmqSendCallback();
    }
}

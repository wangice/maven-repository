package com.ice.framework.rocketmq.listener;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import com.ice.framework.rocketmq.callback.RocketmqSendCallback;
import com.ice.framework.rocketmq.callback.RocketmqSendCallbackBuilder;
import com.ice.framework.rocketmq.event.TransactionAfterCommitSendMQEvent;

/**
 * 在事物中发送 TransactionAfterCommitSendMQEvent消息后，此时会在事物提交后异步发送消息
 * 
 * @author wangwei
 * @Date 2024/9/18 17:49
 */
@Component
public class TransactionCommitSendMQListener {

    private static final Logger log = LoggerFactory.getLogger(TransactionCommitSendMQListener.class);

    private static final RocketmqSendCallback rocketmqSendCallback = RocketmqSendCallbackBuilder.commonCallback();

    /**
     * 事务提交后发生mq事件 且 没有事务也能当作普通时间监听器触发
     * 
     * @param event
     */
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
    public void send(TransactionAfterCommitSendMQEvent event) {
        log.info("事务提交后，发送mq信息!{}", event);
        String destination = event.getTopic();
        if (Objects.nonNull(event.getTag())) {
            destination = event.getTopic() + ":" + event.getTag();
        }
        // 发送mq消息
        event.getRocketMQTemplate().asyncSend(destination, event.getMessage(), rocketmqSendCallback);
    }
}

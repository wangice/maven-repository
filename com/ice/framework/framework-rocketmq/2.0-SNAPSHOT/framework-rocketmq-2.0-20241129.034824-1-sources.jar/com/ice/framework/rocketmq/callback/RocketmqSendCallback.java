package com.ice.framework.rocketmq.callback;

import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author wangwei
 * @Date 2024/9/18 17:50
 */
public class RocketmqSendCallback implements SendCallback {

    private static final Logger log = LoggerFactory.getLogger(RocketmqSendCallback.class);

    @Override
    public void onSuccess(SendResult sendResult) {
        log.info("async onSuccess SendResult={}", sendResult);
    }

    @Override
    public void onException(Throwable throwable) {
        log.error("async onException Throwable", throwable);
    }
}

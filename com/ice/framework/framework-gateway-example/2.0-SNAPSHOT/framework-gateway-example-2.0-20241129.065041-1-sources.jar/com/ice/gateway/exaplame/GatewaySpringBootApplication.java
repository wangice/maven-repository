package com.ice.gateway.exaplame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author wangwei
 * @Date 2024/7/18 16:45
 */
@SpringBootApplication(scanBasePackages = "com.ice")
public class GatewaySpringBootApplication {
    public static void main(String[] args) {
        SpringApplication.run(GatewaySpringBootApplication.class);
    }
}

package com.ice.gateway.exaplame.config;

import com.ice.gateway.exaplame.security.AuthConfigAdapter;
import com.ice.gateway.exaplame.security.DefaultAuthConfigAdapter;
import com.ice.gateway.exaplame.security.GatewayFilterConfig;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;

/**
 * @author wangwei
 * @Date 2024/11/28 09:44
 */
@Configuration
public class SecurityConfig {

    @Bean
    @ConditionalOnMissingBean
    public AuthConfigAdapter authConfigAdapter() {
        return new DefaultAuthConfigAdapter();
    }

    @Bean
    public GatewayFilterConfig getGatewayFilterConfig() {
        return new GatewayFilterConfig();
    }
}

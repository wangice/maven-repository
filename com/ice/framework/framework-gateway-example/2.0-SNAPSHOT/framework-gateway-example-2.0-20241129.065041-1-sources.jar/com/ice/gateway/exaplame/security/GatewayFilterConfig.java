package com.ice.gateway.exaplame.security;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import cn.hutool.core.exceptions.ExceptionUtil;
import com.alibaba.fastjson2.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.CollectionUtils;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * 请求拦截
 *
 * @author wangwei
 * @Date 2024/11/26 14:54
 */
public class GatewayFilterConfig implements GlobalFilter, Ordered {
    private static final Logger log = LoggerFactory.getLogger(GatewayFilterConfig.class);
    @Autowired
    private AuthConfigAdapter authConfigAdapter;
    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        String path = request.getURI().getPath();

        path = path.substring(path.indexOf("/", 1));
        AntPathMatcher pathMatcher = new AntPathMatcher();
        try {
            // 匹配放行
            Set<String> excludePathPatterns = authConfigAdapter.excludePathPatterns();
            if (!CollectionUtils.isEmpty(excludePathPatterns)) {
                for (String excludePathPattern : excludePathPatterns) {
                    if (pathMatcher.match(excludePathPattern, path)) {
                        return chain.filter(exchange);
                    }
                }
            }
            //

            List<String> tokens = request.getHeaders().get("Authorization");
            if (CollectionUtils.isEmpty(tokens)) {
                return noTokenMono(exchange);
            }
            String token = tokens.getFirst();
            // 从缓存中获取用户数据
            JSONObject user = (JSONObject)redisTemplate.opsForValue().get(token);
            if (Objects.isNull(user)) {
                return invalidTokenMono(exchange);
            }
            // 获取到用户详情
            Object userDetail = user.get("userDetail");
            // 设置头部，重新封装
            ServerHttpRequest httpRequest = exchange.getRequest().mutate().header("userDetail",
                JSONObject.toJSONString(userDetail)).build();
            ServerWebExchange build = exchange.mutate().request(httpRequest).build();
            return chain.filter(build);
        } catch (Exception e) {
            log.error(ExceptionUtil.getRootCauseMessage(e));
            return invalidTokenMono(exchange);
        }

    }

    // 等级越小，执行越靠前
    @Override
    public int getOrder() {
        return 0;
    }

    private Mono<Void> invalidTokenMono(ServerWebExchange exchange) {
        JSONObject json = new JSONObject();
        json.put("errorCode", HttpStatus.UNAUTHORIZED.value());
        json.put("errorMsg", "无效的token");
        return buildReturnMono(json, exchange);
    }

    private Mono<Void> noTokenMono(ServerWebExchange exchange) {
        JSONObject json = new JSONObject();
        json.put("errorCode", HttpStatus.UNAUTHORIZED.value());
        json.put("errorMsg", "没有token");
        return buildReturnMono(json, exchange);
    }

    /**
     * 构建返回数据
     *
     * @param json
     * @param exchange
     * @return
     */
    private Mono<Void> buildReturnMono(JSONObject json, ServerWebExchange exchange) {
        ServerHttpResponse response = exchange.getResponse();
        byte[] bits = json.toJSONString().getBytes(StandardCharsets.UTF_8);
        DataBuffer buffer = response.bufferFactory().wrap(bits);
        response.setStatusCode(HttpStatus.UNAUTHORIZED);
        //指定编码，否则在浏览器中会中文乱码
        response.getHeaders().add("Content-Type", "text/plain;charset=UTF-8");
        return response.writeWith(Mono.just(buffer));
    }
}

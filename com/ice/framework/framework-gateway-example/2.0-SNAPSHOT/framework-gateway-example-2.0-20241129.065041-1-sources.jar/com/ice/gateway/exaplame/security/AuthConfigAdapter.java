package com.ice.gateway.exaplame.security;

import java.util.List;
import java.util.Set;

/**
 * 实现该接口之后，修改需要授权登陆的路径，不需要授权登陆的路径
 *
 * @author wangwei
 * @Date 2024/11/26 15:56
 */
public interface AuthConfigAdapter {

    /**
     * 登录地址
     */
    public static String LOGIN = "/login";

    /**
     * 退出登录地址
     */
    public static String LOGOUT = "/logout";

    public static String API_DOC = "/v3/api-docs";

    /**
     * 需要授权登陆的路径
     *
     * @return 需要授权登陆的路径列表
     */
    List<String> pathPatterns();

    /**
     * 不需要授权登陆的路径
     *
     * @param paths
     * @return 不需要授权登陆的路径列表
     */
    Set<String> excludePathPatterns(String... paths);
}

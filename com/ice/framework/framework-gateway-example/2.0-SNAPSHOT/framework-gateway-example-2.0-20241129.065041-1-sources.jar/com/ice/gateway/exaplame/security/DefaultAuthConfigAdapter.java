package com.ice.gateway.exaplame.security;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * @author wangwei
 * @Date 2024/11/26 17:36
 */
public class DefaultAuthConfigAdapter implements AuthConfigAdapter {

    static Set<String> pathSet;

    static {
        pathSet = new CopyOnWriteArraySet<>();
        pathSet.add(LOGIN);
        pathSet.add(LOGOUT);
        pathSet.add(API_DOC);
    }

    @Override
    public List<String> pathPatterns() {
        return Collections.singletonList("/*");
    }

    @Override
    public Set<String> excludePathPatterns(String... paths) {
        if (paths.length == 0) {
            return pathSet;
        }
        pathSet.addAll(Arrays.asList(paths));
        return pathSet;
    }
}

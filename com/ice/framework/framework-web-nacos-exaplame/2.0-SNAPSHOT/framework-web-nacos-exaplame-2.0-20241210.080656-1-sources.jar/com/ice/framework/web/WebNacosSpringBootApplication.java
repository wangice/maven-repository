package com.ice.framework.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author wangwei
 * @Date 2024/8/27 11:16
 */
@SpringBootApplication(scanBasePackages = {"com.ice.framework"})
public class WebNacosSpringBootApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebNacosSpringBootApplication.class);
    }
}

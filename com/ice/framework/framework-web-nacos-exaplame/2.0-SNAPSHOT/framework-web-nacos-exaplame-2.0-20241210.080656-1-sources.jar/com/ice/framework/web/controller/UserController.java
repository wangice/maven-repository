package com.ice.framework.web.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ice.framework.common.annotation.AutoResult;
import com.ice.framework.web.lock.DistributedLock;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author wangwei
 * @Date 2024/8/27 11:35
 */
@Tag(name = "重复校验")
@AutoResult
@RestController
@RequestMapping("/idempotent")
public class UserController {
    /**
     * 在1s内多次调用会抛异常
     *
     * @Author wangwei
     * @Date 2021/12/21
     */
    @Operation(summary = "测试幂等")
    @DistributedLock(header = {"Authorization"}, keys = {"#userInfo.name"})
    @GetMapping("getDisUser")
    public String getDisUser() {
        return "hello" + " " + "ice";
    }
}

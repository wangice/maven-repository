package com.ice.framework.es.update;

import java.util.Objects;

import org.dromara.easyes.common.params.SFunction;
import org.dromara.easyes.core.conditions.update.LambdaEsUpdateWrapper;

/**
 * 拓展 LambdaEsUpdateWrapper 类，主要增加如下功能：
 *
 * 1. 设置值时，增加 xxxIfPresent 方法，用于判断值不存在的时候，不要拼接到条件中。
 *
 * @author wangwei
 * @Date 2024/7/19 11:29
 */
public class LambdaEsUpdateWrapperX<T> extends LambdaEsUpdateWrapper<T> {

    public LambdaEsUpdateWrapperX<T> setIfPresent(SFunction<T, ?> column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsUpdateWrapperX<T>)super.set(column, val);
        }
        return this;
    }

    public LambdaEsUpdateWrapperX<T> setIfPresent(String column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsUpdateWrapperX<T>)super.set(column, val);
        }
        return this;
    }
}

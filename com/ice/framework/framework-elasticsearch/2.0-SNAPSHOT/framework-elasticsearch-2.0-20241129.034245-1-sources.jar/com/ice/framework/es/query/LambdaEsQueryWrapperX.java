package com.ice.framework.es.query;

import java.util.Collection;
import java.util.Objects;

import org.dromara.easyes.common.params.SFunction;
import org.dromara.easyes.core.conditions.select.LambdaEsQueryWrapper;
import org.springframework.util.CollectionUtils;

/**
 * 拓展 LambdaEsQueryWrapper 类，主要增加如下功能：
 *
 * 1. 拼接条件的方法，增加 xxxIfPresent 方法，用于判断值不存在的时候，不要拼接到条件中。
 * 
 * @author wangwei
 * @Date 2024/7/18 16:00
 */
public class LambdaEsQueryWrapperX<T> extends LambdaEsQueryWrapper<T> {

    public LambdaEsQueryWrapperX<T> eqIfPresent(SFunction<T, ?> column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.eq(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> eqIfPresent(String column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.eq(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> gtIfPresent(SFunction<T, ?> column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.gt(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> gtIfPresent(String column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.gt(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> geIfPresent(SFunction<T, ?> column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.ge(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> geIfPresent(String column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.ge(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> ltIfPresent(SFunction<T, ?> column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.lt(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> ltIfPresent(String column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.lt(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> leIfPresent(SFunction<T, ?> column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.le(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> leIfPresent(String column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.le(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> likeIfPresent(SFunction<T, ?> column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.like(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> likeIfPresent(String column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.like(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> likeLeftIfPresent(SFunction<T, ?> column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.likeLeft(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> likeLeftIfPresent(String column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.likeLeft(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> likeRightIfPresent(SFunction<T, ?> column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.likeRight(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> likeRightIfPresent(String column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.likeRight(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> matchIfPresent(SFunction<T, ?> column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.match(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> matchIfPresent(String column, Object val) {
        if (Objects.nonNull(val)) {
            return (LambdaEsQueryWrapperX<T>)super.match(column, val);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> inIfPresent(SFunction<T, ?> column, Collection<?> values) {
        if (!CollectionUtils.isEmpty(values)) {
            return (LambdaEsQueryWrapperX<T>)super.in(column, values);
        }
        return this;
    }

    public LambdaEsQueryWrapperX<T> inIfPresent(String column, Collection<?> values) {
        if (!CollectionUtils.isEmpty(values)) {
            return (LambdaEsQueryWrapperX<T>)super.in(column, values);
        }
        return this;
    }

}

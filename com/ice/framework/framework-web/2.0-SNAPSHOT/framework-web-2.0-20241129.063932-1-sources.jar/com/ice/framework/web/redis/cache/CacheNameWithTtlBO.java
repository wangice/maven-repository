package com.ice.framework.web.redis.cache;

/**
 * 通过 cacheName 配置 和 时间告诉缓存多久清楚一遍
 * 
 * @author wangwei
 * @Date 2024/9/18 16:42
 */
public class CacheNameWithTtlBO {
    private String cacheName;

    private Integer ttl;

    public CacheNameWithTtlBO(String cacheName, Integer ttl) {
        this.cacheName = cacheName;
        this.ttl = ttl;
    }

    public String getCacheName() {
        return cacheName;
    }

    public void setCacheName(String cacheName) {
        this.cacheName = cacheName;
    }

    public Integer getTtl() {
        return ttl;
    }

    public void setTtl(Integer ttl) {
        this.ttl = ttl;
    }

    @Override
    public String toString() {
        return "CacheNameWithTtlBO{" + "cacheName='" + cacheName + '\'' + ", ttl=" + ttl + '}';
    }
}

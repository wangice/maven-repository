package com.ice.framework.web.lock;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.ice.framework.common.lock.LockExecutor;
import com.ice.framework.web.lock.info.LockProperties;

/**
 * 重复提交
 * 
 * @author wangwei
 * @Date 2024/7/9 14:29
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Idempotent {
    /**
     * 用于多个方法锁同一把锁 可以理解为锁资源名称 为空则会使用 包名+类名+方法名
     *
     * @return 名称
     */
    String name() default "";

    /**
     * 过期时间
     * 
     * <pre>
     *     过期时间一定是要长于业务的执行时间. 未设置则为默认时间30秒 默认值：{@link LockProperties#expire}
     * </pre>
     */
    long expire() default -1;

    /**
     * 指定头信息中的KEY值，校验时将获取对应的header值。默认不校验
     *
     * @return
     *
     * @author wangwei
     * @date 2021年2月22日 下午8:50:25
     */
    String[] header() default {};

    /**
     * support SPEL expresion 锁的key = name + keys
     *
     * @return KEY
     */
    String[] keys() default "";

    /**
     * @return lock 执行器
     */
    Class<? extends LockExecutor> executor() default LockExecutor.class;
}

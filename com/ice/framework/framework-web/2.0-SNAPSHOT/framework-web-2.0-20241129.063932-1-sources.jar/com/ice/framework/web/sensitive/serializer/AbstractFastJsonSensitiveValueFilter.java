package com.ice.framework.web.sensitive.serializer;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;

import org.springframework.util.ObjectUtils;
import org.springframework.web.method.HandlerMethod;

import com.ice.framework.web.sensitive.SensitiveStrategy;
import com.ice.framework.web.sensitive.SensitiveWrapper;
import com.ice.framework.web.sensitive.annotation.IgnoreSensitive;
import com.ice.framework.web.sensitive.annotation.Sensitive;
import com.ice.framework.web.sensitive.resolver.HandlerMethodResolver;

import cn.hutool.core.annotation.AnnotationUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.extra.spring.SpringUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * @author wangwei
 * @Date 2024/6/24 17:18
 */
@Slf4j
public abstract class AbstractFastJsonSensitiveValueFilter {

    protected Object process(Object object, String fieldName, Object fieldValue) {
        if (ObjectUtils.isEmpty(fieldValue) || !String.class.isAssignableFrom(fieldValue.getClass())) {
            logger.debug("Skip sensitive, because value is empty or not String type.");
            return fieldValue;
        }

        HandlerMethodResolver methodResolver = SpringUtil.getBean(HandlerMethodResolver.class);
        HandlerMethod handlerMethod = methodResolver.resolve();
        if (Objects.isNull(handlerMethod)) {
            logger.debug("Skip sensitive, because HandlerMethod is null.");
            return fieldValue;
        }

        Class<?> beanType = handlerMethod.getBeanType();
        IgnoreSensitive annotation = AnnotationUtil.getAnnotation(beanType, IgnoreSensitive.class);
        if (Objects.isNull(annotation)) {
            annotation = handlerMethod.getMethodAnnotation(IgnoreSensitive.class);
        }
        Optional<IgnoreSensitive> ignSensitiveOpt = Optional.ofNullable(annotation);
        Optional<String[]> ignFieldNamesOpt = ignSensitiveOpt.map(IgnoreSensitive::value);
        if ((ignSensitiveOpt.isPresent() && !ignFieldNamesOpt.filter(ArrayUtil::isNotEmpty).isPresent())
            || ignFieldNamesOpt.filter(names -> Arrays.asList(names).contains(fieldName)).isPresent()) {
            logger.debug("Skip sensitive for {}, because @IgnoreSensitive is null or not contains it.", fieldName);
            return fieldValue;
        }

        Class<?> objectClass = object.getClass();
        Field field = ReflectUtil.getField(objectClass, fieldName);
        Sensitive sensitive = field.getAnnotation(Sensitive.class);
        if (Objects.isNull(sensitive)) {
            logger.debug("Skip sensitive for {}, because @Sensitive is null.", fieldName);
            return fieldValue;
        }

        SensitiveStrategy strategy = sensitive.strategy();
        String finalValue = strategy.apply(new SensitiveWrapper(object, fieldName, (String)fieldValue));
        logger.debug("Sensitive for [{}={}] with {} strategy in {}.", fieldName, finalValue, strategy.name(),
            objectClass.getSimpleName());
        return finalValue;
    }
}

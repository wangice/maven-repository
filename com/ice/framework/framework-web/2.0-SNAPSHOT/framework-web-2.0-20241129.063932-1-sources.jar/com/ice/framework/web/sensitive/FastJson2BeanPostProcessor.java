package com.ice.framework.web.sensitive;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.alibaba.fastjson2.filter.Filter;
import com.alibaba.fastjson2.support.config.FastJsonConfig;
import com.alibaba.fastjson2.support.spring6.http.converter.FastJsonHttpMessageConverter;

import com.ice.framework.web.sensitive.serializer.FastJson2SensitiveValueFilter;

import cn.hutool.core.util.ArrayUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * @author wangwei
 * @Date 2024/6/24 17:27
 */
@Slf4j
public class FastJson2BeanPostProcessor implements BeanPostProcessor {
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if (bean instanceof FastJsonHttpMessageConverter) {
            FastJsonHttpMessageConverter fastJsonConverter = (FastJsonHttpMessageConverter)bean;
            FastJsonConfig fastJsonConfig = fastJsonConverter.getFastJsonConfig();
            Filter[] oldWriterFilters = fastJsonConfig.getWriterFilters();

            FastJson2SensitiveValueFilter[] injectWriterFilters = {new FastJson2SensitiveValueFilter()};
            Filter[] newWriterFilters = ArrayUtil.addAll(oldWriterFilters, injectWriterFilters);
            fastJsonConfig.setWriterFilters(newWriterFilters);

            logger.info("Injected [{}] WriterFilter to [{}]", FastJson2SensitiveValueFilter.class.getName(),
                FastJsonHttpMessageConverter.class.getName());

            return fastJsonConverter;
        }
        return bean;
    }
}

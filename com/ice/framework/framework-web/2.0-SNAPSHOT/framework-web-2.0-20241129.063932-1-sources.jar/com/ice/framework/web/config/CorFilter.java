package com.ice.framework.web.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

/**
 * 设置跨域
 * 
 * @author wangwei
 * @Date 2021/12/31 09:37
 */
@Configuration
public class CorFilter {

    /**
     * 跨域放行的路径，默认为/api/**
     */
    @Value("${web.cor.path:/api/**}")
    private String corPath;

    /**
     * 添加CORS配置信息
     * 
     * @return
     */
    private CorsConfiguration buildConfig() {
        CorsConfiguration corsConfiguration = new CorsConfiguration();
        corsConfiguration.setAllowCredentials(true); // 是否发送Cookie
        corsConfiguration.setAllowedOriginPatterns(Arrays.asList("*")); // 放行哪些则正表达式的原始域
        corsConfiguration.setAllowedHeaders(Arrays.asList("*")); // 放行哪些头部信息
        corsConfiguration.setAllowedMethods(Arrays.asList("*")); // 放行哪些请求方法
        return corsConfiguration;
    }

    /**
     * 添加映射路径
     * 
     * @return
     */
    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration(corPath, this.buildConfig());
        return new CorsFilter(source);
    }
}

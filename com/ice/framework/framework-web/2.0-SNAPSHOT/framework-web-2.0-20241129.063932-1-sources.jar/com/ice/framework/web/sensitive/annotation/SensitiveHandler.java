package com.ice.framework.web.sensitive.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.ice.framework.web.sensitive.CustomizeSensitiveHandler;

/**
 * @author wangwei
 * @Date 2024/6/24 14:23
 */
@Inherited
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.ANNOTATION_TYPE})
public @interface SensitiveHandler {

    /**
     * Sensitive customizes handler
     *
     * @return {@link CustomizeSensitiveHandler}
     */
    Class<? extends CustomizeSensitiveHandler> value();
}

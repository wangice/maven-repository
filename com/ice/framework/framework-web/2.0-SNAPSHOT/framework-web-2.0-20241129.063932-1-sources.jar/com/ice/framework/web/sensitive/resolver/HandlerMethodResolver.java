package com.ice.framework.web.sensitive.resolver;

import org.springframework.web.method.HandlerMethod;

public interface HandlerMethodResolver {

    /**
     * Get HandlerMethod
     *
     * @return {@link HandlerMethod}
     */
    HandlerMethod resolve();
}

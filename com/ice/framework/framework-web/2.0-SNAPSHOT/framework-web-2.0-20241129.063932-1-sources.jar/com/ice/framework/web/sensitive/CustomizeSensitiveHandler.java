package com.ice.framework.web.sensitive;

/**
 * @author wangwei
 * @Date 2024/6/24 14:23
 */
public interface CustomizeSensitiveHandler {
    /**
     * Customize the filed value
     *
     * @param sensitiveWrapper
     *            sensitive require message
     * @return after customize field value
     */
    String customize(SensitiveWrapper sensitiveWrapper);
}

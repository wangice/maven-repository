package com.ice.framework.web.redis.cache;

import java.util.List;

/**
 * @author wangwei
 * @Date 2024/9/18 16:42
 */
public interface CacheTtlAdapter {
    /**
     * 根据缓存的cacheName和ttl将缓存进行过期
     * 
     * @return 需要独立设置过期时间的缓存列表
     */
    List<CacheNameWithTtlBO> listCacheNameWithTtl();
}

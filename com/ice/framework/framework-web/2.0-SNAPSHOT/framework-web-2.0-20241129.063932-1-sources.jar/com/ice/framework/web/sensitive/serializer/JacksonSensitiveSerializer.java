package com.ice.framework.web.sensitive.serializer;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;

import org.springframework.util.ObjectUtils;
import org.springframework.web.method.HandlerMethod;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import com.ice.framework.web.sensitive.SensitiveStrategy;
import com.ice.framework.web.sensitive.SensitiveWrapper;
import com.ice.framework.web.sensitive.annotation.IgnoreSensitive;
import com.ice.framework.web.sensitive.annotation.Sensitive;
import com.ice.framework.web.sensitive.resolver.HandlerMethodResolver;

import cn.hutool.core.annotation.AnnotationUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.extra.spring.SpringUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * @author wangwei
 * @Date 2024/6/24 11:19
 */
@Slf4j
public class JacksonSensitiveSerializer extends JsonSerializer<String> {

    @Override
    public Class<String> handledType() {
        return String.class;
    }

    @Override
    public void serialize(String fieldValue, JsonGenerator jsonGenerator, SerializerProvider serializerProvider)
        throws IOException {
        if (Objects.isNull(fieldValue)) {
            logger.debug("Skip sensitive, because value is null.");
            jsonGenerator.writeNull();
            return;
        }
        // 序列化中无法获取HttpRequest的相关信息，只能通过全局的方式获取
        HandlerMethodResolver handlerMethodResolver = SpringUtil.getBean(HandlerMethodResolver.class);
        HandlerMethod handlerMethod = handlerMethodResolver.resolve();
        if (ObjectUtils.isEmpty(handlerMethod)) {
            logger.debug("Skip sensitive, because HandlerMethod is null.");
            jsonGenerator.writeString(fieldValue);
            return;
        }

        String fieldName = jsonGenerator.getOutputContext().getCurrentName();
        Class<?> beanType = handlerMethod.getBeanType();
        IgnoreSensitive annotation = AnnotationUtil.getAnnotation(beanType, IgnoreSensitive.class);
        if (Objects.isNull(annotation)) {
            annotation = handlerMethod.getMethodAnnotation(IgnoreSensitive.class);
        }
        Optional<IgnoreSensitive> ignSensitiveOpt = Optional.ofNullable(annotation);
        Optional<String[]> ignFieldNamesOpt = ignSensitiveOpt.map(IgnoreSensitive::value);
        if ((ignSensitiveOpt.isPresent() && !ignFieldNamesOpt.filter(ArrayUtil::isNotEmpty).isPresent())
            || ignFieldNamesOpt.filter(names -> Arrays.asList(names).contains(fieldName)).isPresent()) {
            logger.debug("Skip sensitive for {}, because @IgnoreSensitive is null or not contains it.", fieldName);
            jsonGenerator.writeString(fieldValue);
            return;
        }

        Object object = jsonGenerator.currentValue();
        Class<?> objectClass = object.getClass();
        Field field = ReflectUtil.getField(objectClass, fieldName);
        Sensitive sensitive = field.getAnnotation(Sensitive.class);
        if (Objects.isNull(sensitive)) {
            logger.debug("Skip sensitive for {}, because @Sensitive is null.", fieldName);
            jsonGenerator.writeString(fieldValue);
            return;
        }
        SensitiveStrategy strategy = sensitive.strategy();
        String finalValue = strategy.apply(new SensitiveWrapper(object, fieldName, fieldValue));
        logger.debug("Sensitive for [{}={}] with {} strategy in {}.", fieldName, finalValue, strategy.name(),
            objectClass.getSimpleName());
        jsonGenerator.writeString(finalValue);
    }
}

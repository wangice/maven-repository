package com.ice.framework.web.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * 开启代理暴露 在 userService实现中需要调用本方法的代理对象，则使用如下方式 UserService userService = (UserService)AopContext.currentProxy();
 * userservice.executeUpdateUser();
 *
 * 需要注意在调用非代理的方法时，opContext.currentProxy() 可能返回null
 * 
 * @author wangwei
 * @Date 2024/9/14 10:16
 */
@EnableAspectJAutoProxy(exposeProxy = true)
@Configuration
public class AopConfig {

}

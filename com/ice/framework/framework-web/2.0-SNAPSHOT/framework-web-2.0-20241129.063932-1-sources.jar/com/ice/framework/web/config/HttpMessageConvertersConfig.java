package com.ice.framework.web.config;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.ResourceHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
import org.springframework.http.converter.xml.SourceHttpMessageConverter;

import com.alibaba.fastjson2.JSONWriter;
import com.alibaba.fastjson2.support.config.FastJsonConfig;
import com.alibaba.fastjson2.support.spring6.http.converter.FastJsonHttpMessageConverter;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;

import com.ice.framework.common.entity.NumberSerializer;

/**
 * 自定义全局转换器。
 *
 * <br/>
 * 由于springMVC与RestTemplate各自定义了自己的转换器，需要同时处理 且需要对原转换器做以下替换： （1）替换String转换器，将字符集设置为UTF-8 （2）根据http.json.convert
 * 判断是否使用jackson还是fastjson, 默认使用jackson （3）由于没有使用到JSON转XML的转换器，去掉了json2Xml转换器（该转换器在JSON之前被匹配）。
 * 
 * @author
 * @Date 2021/12/31 17:01
 */
@Configuration
public class HttpMessageConvertersConfig {

    private static final String DATE_FORMAT = "yyyy-MM-dd";

    private static final String ENCODING = "utf-8";

    // 可配置日期转化格式
    @Value("${spring.dateformat:yyyy-MM-dd HH:mm:ss}")
    private String dateformat;

    @Value("${http.json.convert: jackson}")
    private String httpJsonConvert;

    @Bean
    public HttpMessageConverters HttpMessageConverters() {

        List<HttpMessageConverter<?>> list = new ArrayList<>();

        list.add(new ByteArrayHttpMessageConverter());

        list.add(stringHttpMessageConverter());

        list.add(new ResourceHttpMessageConverter(false));

        list.add(new SourceHttpMessageConverter<>());

        list.add(new AllEncompassingFormHttpMessageConverter());

        if (httpJsonConvert.equals("fastjson")) {
            list.add(fastJsonHttpMessageConverter());
        } else {
            // 默认添加jackson序列化
            list.add(mappingJackson2HttpMessageConverter());
        }

        HttpMessageConverters converters = new HttpMessageConverters(false, list);

        return converters;
    }

    /**
     * StringHttpMessageConverter 设置字符（系统默认为ISO）
     *
     * @return
     *
     * @author wangwei
     *
     * @since 2018年7月5日
     */
    private StringHttpMessageConverter stringHttpMessageConverter() {
        StringHttpMessageConverter stringConverter = new StringHttpMessageConverter();
        // 设置编码
        stringConverter.setDefaultCharset(Charset.forName(ENCODING));
        stringConverter.setWriteAcceptCharset(false);

        return stringConverter;
    }

    /**
     * jackson 转化器
     * 
     * @return
     */
    public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        // 时间对象自定义格式化
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        // 添加lockDateTime时间格式的转化
        javaTimeModule.addDeserializer(LocalDateTime.class, new JsonDeserializer<LocalDateTime>() {
            @Override
            public LocalDateTime deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
                throws IOException {
                long timestamp = Long.parseLong(jsonParser.getText());
                Instant instant = Instant.ofEpochMilli(timestamp);
                return LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
            }
        });
        javaTimeModule.addSerializer(LocalDateTime.class, new JsonSerializer<LocalDateTime>() {
            @Override
            public void serialize(LocalDateTime localDateTime, JsonGenerator jsonGenerator,
                SerializerProvider serializerProvider) throws IOException {
                jsonGenerator.writeNumber(localDateTime.toInstant(ZoneOffset.ofHours(8)).toEpochMilli());
            }
        });
        // 添加lockDate序列化
        javaTimeModule.addSerializer(LocalDate.class,
            new LocalDateSerializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        javaTimeModule.addDeserializer(LocalDate.class,
            new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        // 添加localTime序列化
        javaTimeModule.addSerializer(LocalTime.class, new LocalTimeSerializer(DateTimeFormatter.ofPattern("HH:mm:ss")));
        javaTimeModule.addDeserializer(LocalTime.class,
            new LocalTimeDeserializer(DateTimeFormatter.ofPattern("HH:mm:ss")));
        // Long转换为String传输
        javaTimeModule.addSerializer(Long.class, NumberSerializer.instance);
        javaTimeModule.addSerializer(Long.TYPE, NumberSerializer.instance);
        mapper.registerModule(javaTimeModule);

        converter.setObjectMapper(mapper);
        return converter;
    }

    /**
     * 使用FastJSON转换器（默认使用 MappingJackson2HttpMessageConverter） 参考文档：
     * https://gitee.com/wenshao/fastjson2/blob/main/docs/features_cn.md
     * https://gitee.com/wenshao/fastjson2/blob/main/docs/spring_support_cn.md
     * 
     * @return
     *
     * @author wangwei
     *
     * @since 2018年7月5日
     */
    private FastJsonHttpMessageConverter fastJsonHttpMessageConverter() {
        FastJsonHttpMessageConverter fastConverter = new FastJsonHttpMessageConverter();
        fastConverter.setFastJsonConfig(initFastJsonConfig(dateformat));
        fastConverter.setSupportedMediaTypes(Collections.singletonList(MediaType.APPLICATION_JSON));
        fastConverter.setDefaultCharset(StandardCharsets.UTF_8);
        return fastConverter;
    }

    public static FastJsonConfig initFastJsonConfig(String dateformat) {
        if (dateformat == null) {
            dateformat = DATE_FORMAT;
        }
        FastJsonConfig fastJsonConfig = new FastJsonConfig();
        fastJsonConfig.setWriterFeatures(JSONWriter.Feature.PrettyFormat, JSONWriter.Feature.WriteLongAsString,
            JSONWriter.Feature.WriteBigDecimalAsPlain);
        // 全局指定了日期格式
        fastJsonConfig.setDateFormat(dateformat);
        return fastJsonConfig;
    }

}

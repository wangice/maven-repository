package com.ice.framework.web.sensitive;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SensitiveWrapper {

    /**
     * Current object.
     */
    private Object object;

    /**
     * Current field name.
     */
    private String fieldName;

    /**
     * Current field value.
     */
    private String fieldValue;
}

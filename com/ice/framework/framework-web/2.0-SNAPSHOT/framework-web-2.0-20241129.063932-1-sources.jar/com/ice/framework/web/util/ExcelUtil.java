package com.ice.framework.web.util;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.function.BiFunction;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.ReadSheet;
import com.alibaba.excel.write.builder.ExcelWriterBuilder;
import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;

import com.ice.framework.common.exception.BusinessException;
import com.ice.framework.web.excel.listener.ReadExcelListener;
import com.ice.framework.web.excel.processor.IReadExcelProcessor;
import com.ice.framework.web.helper.RequestHelper;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.net.URLEncodeUtil;
import cn.hutool.core.util.StrUtil;
import jakarta.servlet.http.HttpServletResponse;
import lombok.CustomLog;
import lombok.Data;
import lombok.SneakyThrows;

/**
 *
 * 在读取excel实体类上需加@Accessors(chain = false)否则会读取不到数据，因为Easy Excel底层使用了cglib 目前cglib 无法支持 @accessors(chain = true)
 * 参考资料：https://github.com/alibaba/easyexcel/issues/3235
 *
 * @author wangwei
 * @Date 2024/8/19 14:50
 */
@CustomLog
public class ExcelUtil {
    /**
     * 定义excel中一个sheet最大的行数 50万行数据, MAX_PAGE_SIZE 的整数倍
     */
    public static final long SHEET_MAX_ROWS = 500000;

    public static final Integer MAX_PAGE_SIZE = 2000;
    /** 默认第一页 */
    public static final Integer DEFAULT_PAGE_NUM = 1;

    private static String suffix = ".xlsx";

    /**
     * 获取转义后的文件名
     */
    public static String createFileName(String name) throws UnsupportedEncodingException {
        String rawFileName = name + DateUtil.format(new Date(), "_yyyyMMdd_HHmmss") + suffix;
        String encodedFileName = URLEncoder.encode(rawFileName, "UTF-8").replaceAll("\\+", "%20");
        return encodedFileName;
    }

    /**
     * 返回行中 列的值及对应的位置
     */
    public static Map<String, Integer> cellPosition(Row row) {
        Map<String, Integer> map = new HashMap<>();
        Iterator<Cell> headerCells = row.iterator();
        while (headerCells.hasNext()) {
            Cell cell = headerCells.next();
            map.put(cell.getStringCellValue(), cell.getColumnIndex());
        }
        return map;
    }

    /**
     * 读取Excel
     * 
     * @param input
     * @param sheet
     * @param headRowNumber
     * @param hand
     * @param <T>
     * @return
     */
    public static <T> List<T> read(InputStream input, int sheet, int headRowNumber, Class<T> hand) {
        ExcelReaderBuilder excelReaderBuilder = getExcelReaderBuilder(IoUtil.toBuffered(input), hand, null);
        return excelReaderBuilder.sheet(sheet).headRowNumber(headRowNumber).doReadSync();
    }

    /**
     * 读取Excel
     * 
     * @param input
     * @param hand
     * @param <T>
     * @return
     */
    public static <T> List<T> read(InputStream input, Class<T> hand) {
        return read(input, 0, 1, hand);
    }

    /**
     * 读取Excel的指定sheet数据
     * 
     * @param file
     * @param sheet
     *            从0开始
     * @param hand
     * @param <T>
     * @return
     */
    public static <T> List<T> read(MultipartFile file, int sheet, Class<T> hand) {
        return read(file, sheet, 1, hand);
    }

    /**
     * 读取Excel的指定sheet，指定头所在的行
     * 
     * @param file
     *            excel文件
     * @param sheet
     *            sheet序号(从0开始)
     * @param headRowNumber
     *            默认1
     * @param hand
     * @param <T>
     * @return
     */
    public static <T> List<T> read(MultipartFile file, int sheet, int headRowNumber, Class<T> hand) {
        ExcelReaderBuilder excelReaderBuilder = getExcelReaderBuilder(file, hand, null);
        excelReaderBuilder.sheet(sheet).headRowNumber(headRowNumber).doRead();
        return excelReaderBuilder.autoCloseStream(Boolean.FALSE) // 不要自动关闭，交给 Servlet 自己处理
            .doReadAllSync();
    }

    /**
     * 同步返回所有数据，注意此方法会把读取到的数据缓存到内存中
     * 
     * @param file
     * @param hand
     * @param <T>
     * @return
     */
    public static <T> List<T> read(MultipartFile file, Class<T> hand) {
        return read(file, 0, 1, hand);
    }

    /**
     * 读取并处理数据
     * 
     * @param file
     * @param head
     * @param readExcelProcessor
     * @param <T>
     */
    public static <T> void read(MultipartFile file, Class<T> head, IReadExcelProcessor<T> readExcelProcessor) {
        // ReadExcelListener 不能被spring管理，要每次读取excel都要new,然后里面用到spring可以构造方法传进去
        ReadExcelListener<T> readExcelListener = new ReadExcelListener<>(readExcelProcessor);
        ExcelReaderBuilder excelReaderBuilder = getExcelReaderBuilder(file, head, readExcelListener);
        excelReaderBuilder.autoCloseStream(Boolean.FALSE).doReadAll();
    }

    /**
     * 读取Excel的指定sheet，指定头所在的行
     * 
     * @param file
     * @param sheet
     * @param headRowNumber
     * @param hand
     * @param listener
     * @param <T>
     * @return
     */
    public static <T> void read(MultipartFile file, Class<T> hand, ReadListener<T> listener) {
        ExcelReaderBuilder excelReaderBuilder = getExcelReaderBuilder(file, hand, listener);
        excelReaderBuilder.autoCloseStream(Boolean.FALSE) // 不要自动关闭，交给 Servlet 自己处理
            .doReadAll();
    }

    /**
     * 不创建对象的读
     *
     * @param input
     * @param headRowNumber
     * @param readExcelProcessor
     * @return
     */
    public static <T> void noModelRead(InputStream input, Integer headRowNumber,
        IReadExcelProcessor<T> readExcelProcessor) {
        noModelRead(input, null, headRowNumber, readExcelProcessor);
    }

    /**
     * 不创建对象的读取指定sheet页
     *
     * @param input
     * @param headRowNumber
     *            表头所在行
     * @param readExcelProcessor
     * @return
     */
    public static <T> void noModelReadSheet(InputStream input, Integer sheetNo, Integer headRowNumber,
        IReadExcelProcessor<T> readExcelProcessor) {
        ExcelReader excelReader = EasyExcel.read(input).build();
        ReadSheet readSheet = EasyExcel.readSheet(sheetNo).headRowNumber(headRowNumber)
            .registerReadListener(new ReadExcelListener<>(readExcelProcessor)).build();
        excelReader.read(readSheet);
    }

    /**
     * 不创建对象的读
     *
     * @param input
     * @param head
     * @param headRowNumber
     *            默认不传为1
     * @param readExcelProcessor
     * @return
     */
    public static <T> void noModelRead(InputStream input, List<List<String>> head, Integer headRowNumber,
        IReadExcelProcessor<T> readExcelProcessor) {
        // ReadExcelListener 不能被spring管理，要每次读取excel都要new,然后里面用到spring可以构造方法传进去
        ReadExcelListener<T> readExcelListener = new ReadExcelListener<>(readExcelProcessor);
        ExcelReaderBuilder excelReaderBuilder = getExcelReaderBuilder(input, head, readExcelListener);
        if (headRowNumber != null) {
            excelReaderBuilder.headRowNumber(headRowNumber);
        }
        excelReaderBuilder.autoCloseStream(Boolean.FALSE).doReadAll();
    }

    /**
     * 将列表以Excel写出到response
     *
     * @param response
     *            response
     * @param filename
     *            需要带扩展名 例如：测试.xlsx
     * @param sheetName
     *            工作簿名称
     * @param head
     *            表头类
     * @param data
     *            数据
     * @param writeHandler
     *            自定义write handler
     * @param <T>
     */
    @SneakyThrows
    public static <T> void writeWeb(String filename, String sheetName, Class<T> head, List<T> data,
        WriteHandler... writeHandler) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ExcelWriterBuilder builder = EasyExcel.write(outputStream, head).autoCloseStream(Boolean.FALSE);
        setWriteHandler(builder, writeHandler);
        builder.sheet(sheetName).doWrite(data);
        setResponse(RequestHelper.getResponse(), filename, outputStream.toByteArray());
    }

    public static <T> void writeWeb(String filename, String sheetName, List<List<String>> heads, List<T> data,
        WriteHandler... writeHandler) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ExcelWriterBuilder builder = EasyExcel.write(outputStream).head(heads).autoCloseStream(Boolean.FALSE);
        setWriteHandler(builder, writeHandler);
        builder.sheet(sheetName).doWrite(data);
        setResponse(RequestHelper.getResponse(), filename, outputStream.toByteArray());
    }

    /**
     * 不创建对象动态的写出到response
     *
     * @param response
     *            response
     * @param filename
     *            需要带扩展名 例如：测试.xlsx
     * @param sheetName
     *            工作簿名称
     * @param head
     *            动态表头
     * @param data
     *            数据
     * @param writeHandler
     *            自定义write handler
     * @param <T>
     */
    @SneakyThrows
    public static <T> void noModelWriteWeb(String filename, String sheetName, List<List<String>> head, List<T> data,
        WriteHandler... writeHandler) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ExcelWriterBuilder builder = EasyExcel.write(outputStream).head(head).autoCloseStream(Boolean.FALSE);
        setWriteHandler(builder, writeHandler);
        builder.sheet(sheetName).doWrite(data);
        setResponse(RequestHelper.getResponse(), filename, outputStream.toByteArray());
    }

    /**
     * 不创建对象动态的写出到文件
     * 
     * @param pathName
     *            需要带扩展名 例如：测试.xlsx
     * @param sheetName
     *            工作簿名称
     * @param head
     *            动态表头
     * @param data
     *            数据
     * @param writeHandler
     *            自定义write handler
     * @param <T>
     */
    @SneakyThrows
    public static <T> void noModelWriteFile(String pathName, String sheetName, List<List<String>> head, List<T> data,
        WriteHandler... writeHandler) {
        ExcelWriterBuilder builder = EasyExcel.write(pathName).head(head);
        setWriteHandler(builder, writeHandler);
        builder.sheet(sheetName).doWrite(data);
    }

    /**
     * 分页导出（超过SHEET_MAX_ROWS，进行分sheet导出）
     * 
     * @param filename
     * @param sheetName
     * @param dataClass
     * @param biFunction
     * @param executorService
     */
    public static void export(String filename, String sheetName, Class dataClass,
        BiFunction<Integer, Integer, ImportExcelDataBO> biFunction, ExecutorService executorService) {
        ImportExcelDataBO excelDataBO = biFunction.apply(DEFAULT_PAGE_NUM, MAX_PAGE_SIZE);
        long total = excelDataBO.getTotal();
        if (total == 0) {
            throw new BusinessException("无数据导出");
        }
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        // MAX_PAGE_SIZE条
        if (total > MAX_PAGE_SIZE) {
            // 总共可以分多少页
            int pages = (int)Math.ceil((double)total / MAX_PAGE_SIZE);
            // 从第一页开始
            int page = 1;
            ExcelWriter excelWriter = null;
            try {
                // 初始化 ExcelWriter
                excelWriter = EasyExcel.write(getOutputStream(RequestHelper.getResponse(), filename), dataClass)
                    .autoCloseStream(Boolean.FALSE).build();
                // 大于 PageDTO.MAX_PAGE_SIZE行，进行分页查询
                // 计算有多少个sheet
                int sheetNum = countSlicesNum(SHEET_MAX_ROWS, total);
                for (int i = 0; i < sheetNum; i++) {
                    // 第i个sheet最多有多少行数据
                    long eachSheetRows = Math.min(total - i * SHEET_MAX_ROWS, SHEET_MAX_ROWS);
                    // 计算每个sheet的最大行数，要分多少次分页查询
                    int slicesNum = countSlicesNum(MAX_PAGE_SIZE.longValue(), eachSheetRows);
                    // 收集好获取到当前sheet的所有准备写入的用户数据
                    List<Object> sheetDataList = new ArrayList<>();
                    List<CompletableFuture<ImportExcelDataBO>> futureList = new ArrayList<>();
                    for (int j = 0; j < slicesNum; j++) {
                        if (page > pages) {
                            break;
                        }
                        int finalPage = page;
                        CompletableFuture<ImportExcelDataBO> future = CompletableFuture.supplyAsync(() -> {
                            RequestContextHolder.setRequestAttributes(requestAttributes);
                            return biFunction.apply(finalPage, MAX_PAGE_SIZE);
                        }, executorService);
                        page++;
                        futureList.add(future);
                    }
                    for (CompletableFuture<ImportExcelDataBO> future : futureList) {
                        sheetDataList.addAll(future.get().data);
                    }
                    // 导出excel
                    int sheetNo = i + 1;
                    WriteSheet writeSheet = EasyExcel.writerSheet(filename + sheetNo).head(dataClass).build();
                    excelWriter.write(sheetDataList, writeSheet);
                }
            } catch (Exception e) {
                logger.error("导出excel失败", e);
            } finally {
                if (excelWriter != null) {
                    excelWriter.finish();
                }
            }
        } else {
            // 小于等于 MAX_PAGE_SIZE行 直接导出
            ExcelUtil.writeWeb(filename, sheetName, dataClass, excelDataBO.data);
        }
    }

    /**
     * 分片个数，计算总数total分为每片为eachNum的片数
     *
     * @param eachNum
     *            每片的个数
     * @param total
     *            被分片的总数
     * @return 分片个数
     */
    private static int countSlicesNum(Long eachNum, Long total) {
        boolean isZero = Objects.isNull(eachNum) || eachNum == 0 || Objects.isNull(total) || total == 0;
        if (isZero) {
            return 0;
        }
        // 分片数
        int pageSize = new BigDecimal(total).divide(new BigDecimal(eachNum), 1).intValue();
        // 余数
        int mod = new BigDecimal(total).divideAndRemainder(new BigDecimal(eachNum))[1].intValue();
        if (mod > 0) {
            pageSize = pageSize + 1;
        }
        return pageSize;
    }

    private static void setWriteHandler(ExcelWriterBuilder builder, WriteHandler[] writeHandler) {
        builder.registerWriteHandler(new LongestMatchColumnWidthStyleStrategy());
        if (writeHandler != null && writeHandler.length > 0) {
            for (WriteHandler handler : writeHandler) {
                builder.registerWriteHandler(handler);
            }
        }
    }

    @SneakyThrows
    private static void setResponse(HttpServletResponse response, String filename, byte[] content) {
        setResponse(response, filename);
        response.setContentLength(content.length);
        response.getOutputStream().write(content);
        response.getOutputStream().flush();
    }

    @SneakyThrows
    private static OutputStream getOutputStream(HttpServletResponse response, String filename) {
        setResponse(response, filename);
        return response.getOutputStream();
    }

    public static void setResponse(HttpServletResponse response, String filename) {
        // 请求头 Content-Disposition 指示浏览器如何处理接收到的响应体 attachment: 将响应体作为附件下载并指定文件名， 内容写法 符合RFC 5987规范标准
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncodeUtil.encode(filename));
        response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");
        response.setHeader("Access-Control-Allow-Methods", "*");
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Expose-Headers", "filename");
        if (StrUtil.endWithIgnoreCase(filename, ".xls")) {
            // 早期版本的Excel文件格式的MIME类型, 1997年发布的Excel 97中被引入, 扩展名是.xls
            response.setContentType("application/vnd.ms-excel");
        } else {
            // 较新的Excel文件格式的MIME类型，2007中被引入，使用XML和ZIP压缩来存储数据, 这种格式的扩展名是.xlsx
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }
        response.setCharacterEncoding("UTF-8");
    }

    /**
     * 获取构建类
     *
     * @param excel
     *            excel文件
     * @param readListener
     *            excel监听类
     * @return ExcelReaderBuilder
     */
    @SneakyThrows
    private static <T> ExcelReaderBuilder getExcelReaderBuilder(MultipartFile excel, Class<T> head,
        ReadListener<T> readListener) {
        String filename = excel.getOriginalFilename();
        if (StrUtil.isBlank(filename)) {
            throw new BusinessException("请上传文件");
        }
        if ((!StrUtil.endWithIgnoreCase(filename, ".xls") && !StrUtil.endWithIgnoreCase(filename, ".xlsx"))) {
            throw new BusinessException("请上传以\".xls\"或者\".xlsx\"为文件扩展名结尾的Excel文件");
        }
        return getExcelReaderBuilder(IoUtil.toBuffered(excel.getInputStream()), head, readListener);
    }

    private static <T> ExcelReaderBuilder getExcelReaderBuilder(InputStream input, Class<T> head,
        ReadListener<T> readListener) {
        return EasyExcel.read(input, head, readListener);
    }

    private static <T> ExcelReaderBuilder getExcelReaderBuilder(InputStream input, List<List<String>> head,
        ReadListener<T> readListener) {
        ExcelReaderBuilder builder = EasyExcel.read(input, readListener);
        if (head != null) {
            builder.head(head);
        }
        return builder;
    }

    /**
     * 导出
     */
    @Data
    public static class ImportExcelDataBO {
        private long total;
        private List data;
    }
}

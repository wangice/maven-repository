package com.ice.framework.web.validator;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.ice.framework.common.base.BaseEnum;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

/**
 * @author wangwei
 * @Date 2023/11/8 16:20
 */
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = SelfEnumValidator.class)
public @interface EnumValid {

    String message() default "{ EnumValidator's value is invalid }";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    Class<? extends BaseEnum> enumClass();

}

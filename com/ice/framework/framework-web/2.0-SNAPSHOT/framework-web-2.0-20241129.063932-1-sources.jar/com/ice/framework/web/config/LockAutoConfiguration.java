package com.ice.framework.web.config;

import java.util.List;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.StringRedisTemplate;

import com.ice.framework.common.lock.LockExecutor;
import com.ice.framework.web.lock.LockTemplate;
import com.ice.framework.web.lock.executor.RedisTemplateLockExecutor;
import com.ice.framework.web.lock.info.LockProperties;
import com.ice.framework.web.lock.key.DefaultIdempotentKeyBuilder;
import com.ice.framework.web.lock.key.DefaultLockKeyBuilder;
import com.ice.framework.web.lock.spel.SpelMethodBasedExpressionEvaluator;

/**
 * 分布式锁
 * 
 * @author wangwei
 * @Date 2024/6/14 15:55
 */
@ConditionalOnProperty(name = {"spring.data.redis.enable"}, havingValue = "true", matchIfMissing = false)
@Configuration
public class LockAutoConfiguration {
    @Bean
    public LockProperties lock4jProperties() {
        return new LockProperties();
    }

    @SuppressWarnings("rawtypes")
    @Bean
    @ConditionalOnMissingBean
    public LockTemplate lockTemplate(List<LockExecutor> executors, LockProperties properties) {
        LockTemplate lockTemplate = new LockTemplate();
        lockTemplate.setProperties(properties);
        lockTemplate.setExecutors(executors);
        return lockTemplate;
    }

    @Bean
    @ConditionalOnMissingBean
    public DefaultLockKeyBuilder defaultLockKeyBuilder(SpelMethodBasedExpressionEvaluator expressionEvaluator) {
        return new DefaultLockKeyBuilder(expressionEvaluator);
    }

    @Bean
    @ConditionalOnMissingBean
    public LockExecutor redisExecutor(StringRedisTemplate stringRedisTemplate, LockProperties properties) {
        return new RedisTemplateLockExecutor(stringRedisTemplate, properties);
    }

    @Bean
    public SpelMethodBasedExpressionEvaluator expressionEvaluator() {
        return new SpelMethodBasedExpressionEvaluator();
    }

    @Bean
    @ConditionalOnMissingBean
    public DefaultIdempotentKeyBuilder
        defaultIdempotentKeyBuilder(SpelMethodBasedExpressionEvaluator expressionEvaluator) {
        return new DefaultIdempotentKeyBuilder(expressionEvaluator);
    }
}

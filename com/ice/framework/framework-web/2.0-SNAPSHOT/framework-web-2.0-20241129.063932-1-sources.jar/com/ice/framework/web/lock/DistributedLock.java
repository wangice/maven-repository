package com.ice.framework.web.lock;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.ice.framework.common.lock.LockExecutor;
import com.ice.framework.web.lock.info.LockProperties;

/**
 * 分布式锁
 * 
 * @author wangwei
 * @Date 2024/6/14 15:39
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface DistributedLock {
    /**
     * 用于多个方法锁同一把锁 可以理解为锁资源名称 为空则会使用 包名+类名+方法名
     *
     * @return 名称
     */
    String name() default "";

    /**
     * 过期时间
     * 
     * <pre>
     *     过期时间一定是要长于业务的执行时间. 未设置则为默认时间30秒 默认值：{@link LockProperties#expire}
     * </pre>
     */
    long expire() default -1;

    /**
     * @return 获取锁超时时间 单位：毫秒
     * 
     *         <pre>
     *     结合业务,建议该时间不宜设置过长,特别在并发高的情况下. 未设置则为默认时间3秒 默认值：{@link LockProperties#acquireTimeout}
     *         </pre>
     */
    long acquireTimeout() default -1;

    /**
     * 指定头信息中的KEY值，校验时将获取对应的header值。默认不校验
     *
     * @return
     *
     * @author wangwei
     * @date 2021年2月22日 下午8:50:25
     */
    String[] header() default {};

    /**
     * support SPEL expresion 锁的key = name + keys
     *
     * @return KEY
     */
    String[] keys() default "";

    /**
     * @return lock 执行器
     */
    Class<? extends LockExecutor> executor() default LockExecutor.class;

    /**
     * 业务方法执行完后（方法内抛异常也算执行完）自动释放锁，如果为false，锁将不会自动释放直至到达过期时间才释放 {@link LockProperties#expire()}
     *
     * @return 是否自动释放锁
     */
    boolean autoRelease() default true;
}

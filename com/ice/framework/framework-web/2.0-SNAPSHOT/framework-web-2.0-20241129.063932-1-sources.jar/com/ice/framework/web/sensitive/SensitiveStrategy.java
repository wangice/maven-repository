package com.ice.framework.web.sensitive;

import java.lang.reflect.Field;

import org.springframework.util.Assert;

import com.ice.framework.web.sensitive.annotation.SensitiveHandler;
import com.ice.framework.web.sensitive.annotation.SensitiveKeepLength;

import cn.hutool.core.text.CharSequenceUtil;
import cn.hutool.core.util.DesensitizedUtil;
import cn.hutool.core.util.ReflectUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * @author wangwei
 * @Date 2024/6/24 11:22
 */
@Slf4j
public enum SensitiveStrategy {

    /**
     * Chinese name
     */
    CHINESE_NAME() {
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.chineseName(wrapper.getFieldValue());
        }
    },

    /**
     * ID card
     */
    ID_CARD() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.idCardNum(wrapper.getFieldValue(), 1, 2);
        }
    },

    /**
     * Fixed phone
     */
    FIXED_PHONE() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.fixedPhone(wrapper.getFieldValue());
        }
    },

    /**
     * Mobile phone
     */
    MOBILE_PHONE() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.mobilePhone(wrapper.getFieldValue());
        }
    },

    /**
     * Address
     */
    ADDRESS() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.address(wrapper.getFieldValue(), 8);
        }
    },

    /**
     * Email
     */
    EMAIL() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.email(wrapper.getFieldValue());
        }
    },

    /**
     * Password
     */
    PASSWORD() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.password(wrapper.getFieldValue());
        }
    },

    /**
     * Chinese mainland license plates, including ordinary vehicles, new energy vehicles
     */
    CAR_LICENSE() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.carLicense(wrapper.getFieldValue());
        }
    },

    /**
     * Bank card
     */
    BANK_CARD() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.bankCard(wrapper.getFieldValue());
        }
    },

    /**
     * IPV4
     */
    IPV4() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.ipv4(wrapper.getFieldValue());
        }
    },

    /**
     * IPV6
     */
    IPV6() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.ipv6(wrapper.getFieldValue());
        }
    },

    /**
     * Only show the first one
     */
    FIRST_MASK() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return DesensitizedUtil.firstMask(wrapper.getFieldValue());
        }
    },

    /**
     * Clear to null
     */
    CLEAR_TO_NULL() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return null;
        }
    },

    /**
     * Clear to empty
     */
    CLEAR_TO_EMPTY() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            return CharSequenceUtil.EMPTY;
        }
    },
    /**
     * Customize sensitive keep length
     */
    CUSTOMIZE_KEEP_LENGTH() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            String fieldValue = wrapper.getFieldValue();
            String fieldName = wrapper.getFieldName();
            Object object = wrapper.getObject();
            Field field = ReflectUtil.getField(object.getClass(), fieldName);
            SensitiveKeepLength sensitiveKeepLength = field.getAnnotation(SensitiveKeepLength.class);
            int preKeep = sensitiveKeepLength.preKeep();
            int postKeep = sensitiveKeepLength.postKeep();
            Assert.isTrue(preKeep >= -1, "preKeep must greater than -1");
            Assert.isTrue(postKeep >= -1, "postKeep must greater than -1");

            boolean ignorePreKeep = preKeep <= 0;
            boolean ignoreSuffixKeep = postKeep <= 0;
            if (ignorePreKeep && ignoreSuffixKeep) {
                return fieldValue;
            }
            char replacer = (char)'*';
            return CharSequenceUtil.replace(fieldValue, preKeep, fieldValue.length() - postKeep, replacer);
        }
    },

    /**
     * Customize sensitive handler
     */
    CUSTOMIZE_HANDLER() {
        @Override
        public String apply(SensitiveWrapper wrapper) {
            String fieldName = wrapper.getFieldName();
            Object object = wrapper.getObject();
            Field field = ReflectUtil.getField(object.getClass(), fieldName);
            SensitiveHandler customizeHandler = field.getAnnotation(SensitiveHandler.class);
            Class<? extends CustomizeSensitiveHandler> handlerClass = customizeHandler.value();
            CustomizeSensitiveHandler handler = ReflectUtil.newInstance(handlerClass);
            return handler.customize(wrapper);
        }
    };

    /**
     * Field sensitive strategy method
     *
     * @param wrapper
     *            {@link SensitiveWrapper}
     * @return after sensitive value
     */
    public abstract String apply(SensitiveWrapper wrapper);
}

package com.ice.framework.web.lock.info;

import com.ice.framework.common.lock.LockExecutor;

import lombok.Data;

@Data
public class LockInfo {

    /**
     * 锁名称
     */
    private String lockKey;

    /**
     * 锁值
     */
    private String lockValue;

    /**
     * 过期时间
     */
    private Long expire;

    /**
     * 获取锁超时时间
     */
    private Long acquireTimeout;

    /**
     * 获取锁次数
     */
    private int acquireCount;

    /**
     * 锁实例
     */
    private Object lockInstance;

    /**
     * 锁执行器
     */
    private LockExecutor lockExecutor;

    public LockInfo(String lockKey, String lockValue, Long expire, Long acquireTimeout, int acquireCount,
        Object lockInstance, LockExecutor lockExecutor) {
        this.lockKey = lockKey;
        this.lockValue = lockValue;
        this.expire = expire;
        this.acquireTimeout = acquireTimeout;
        this.acquireCount = acquireCount;
        this.lockInstance = lockInstance;
        this.lockExecutor = lockExecutor;
    }

    public LockInfo(String lockKey, String lockValue, Long expire, Object lockInstance, LockExecutor lockExecutor) {
        this.lockKey = lockKey;
        this.lockValue = lockValue;
        this.expire = expire;
        this.lockInstance = lockInstance;
        this.lockExecutor = lockExecutor;
    }
}

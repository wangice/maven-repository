package com.ice.framework.web.lock;

import java.lang.reflect.Method;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.aop.framework.AopProxyUtils;
import org.springframework.aop.support.AopUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ice.framework.common.constant.ErrorCode;
import com.ice.framework.common.exception.IdempotentException;
import com.ice.framework.web.lock.info.LockInfo;
import com.ice.framework.web.lock.info.LockProperties;
import com.ice.framework.web.lock.key.DefaultLockKeyBuilder;

import lombok.extern.slf4j.Slf4j;

/**
 * @author wangwei
 * @Date 2024/6/14 15:59
 */
@Slf4j
@Aspect
@Component
public class DistributeLockAspect {

    // key 生成器
    private DefaultLockKeyBuilder defaultLockKeyBuilder;
    // lock参数
    private final LockProperties lockProperties;
    // 获取锁信息
    private final LockTemplate lockTemplate;

    public DistributeLockAspect(LockTemplate lockTemplate, LockProperties lockProperties,
        DefaultLockKeyBuilder defaultLockKeyBuilder) {
        this.lockTemplate = lockTemplate;
        this.lockProperties = lockProperties;
        this.defaultLockKeyBuilder = defaultLockKeyBuilder;
    }

    @Pointcut("@annotation(com.ice.framework.web.lock.DistributedLock)")
    public void executeIdempotent() {

    }

    @Around("executeIdempotent()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        // 获取目标类
        Object target = joinPoint.getThis();
        Class<?> targetClass = AopProxyUtils.ultimateTargetClass(target);
        // 获取方法
        MethodSignature ms = (MethodSignature)joinPoint.getSignature();
        Method method = ms.getMethod();
        DistributedLock distributedLockAnnotation = (DistributedLock)method.getAnnotation(DistributedLock.class);
        // 可解决代理对象问题
        Method targetMethod = AopUtils.getMostSpecificMethod(method, targetClass);
        LockInfo lockInfo = null;
        try {
            Object[] arguments = joinPoint.getArgs();

            String prefix = lockProperties.getLockKeyPrefix() + ":";
            prefix += StringUtils.hasText(distributedLockAnnotation.name()) ? distributedLockAnnotation.name()
                : method.getDeclaringClass().getName() + method.getName();
            String key =
                prefix + "#" + defaultLockKeyBuilder.buildKey(targetMethod, arguments, distributedLockAnnotation);

            lockInfo = lockTemplate.lock(key, distributedLockAnnotation.expire(),
                distributedLockAnnotation.acquireTimeout(), distributedLockAnnotation.executor());
            if (null != lockInfo) {
                return joinPoint.proceed();
            }
            return null;
        } catch (Exception e) {
            logger.error("DistributedLock failed:{}", ExceptionUtils.getStackTrace(e));
            throw new IdempotentException(ErrorCode.LOCK_FAILED.getCode(), ExceptionUtils.getStackTrace(e));
        } finally {
            if (null != lockInfo && distributedLockAnnotation.autoRelease()) {
                final boolean releaseLock;
                try {
                    releaseLock = lockTemplate.releaseLock(lockInfo);
                    if (!releaseLock) {
                        logger.error("releaseLock fail,lockKey={},lockValue={}", lockInfo.getLockKey(),
                            lockInfo.getLockValue());
                    }
                } catch (Exception e) {
                    logger.error("releaseLock fail,{}", ExceptionUtils.getStackTrace(e));
                }

            }
        }
    }
}

package com.ice.framework.web.lock;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import com.ice.framework.common.lock.LockExecutor;
import com.ice.framework.web.lock.info.LockInfo;
import com.ice.framework.web.lock.info.LockProperties;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * 锁模板方法
 * </p>
 *
 * @author zengzhihong TaoYu
 */
@SuppressWarnings("rawtypes")
@Slf4j
public class LockTemplate implements InitializingBean {

    private final Map<Class<? extends LockExecutor>, LockExecutor> executorMap = new LinkedHashMap<>();
    @Setter
    private LockProperties properties;
    @Setter
    private List<LockExecutor> executors;

    private LockExecutor primaryExecutor;

    public LockTemplate() {}

    public LockInfo lock(String key) throws Exception {
        return lock(key, 0, -1);
    }

    public LockInfo lock(String key, long expire, long acquireTimeout) throws Exception {
        return lock(key, expire, acquireTimeout, null);
    }

    /**
     * 加锁方法
     *
     * @param key
     *            锁key 同一个key只能被一个客户端持有
     * @param expire
     *            过期时间(ms) 防止死锁
     * @param acquireTimeout
     *            尝试获取锁超时时间(ms)
     * @param executor
     *            执行器
     * @return 加锁成功返回锁信息 失败返回null
     */
    public LockInfo lock(String key, long expire, long acquireTimeout, Class<? extends LockExecutor> executor)
        throws Exception {
        acquireTimeout = acquireTimeout < 0 ? properties.getAcquireTimeout() : acquireTimeout;
        long retryInterval = properties.getRetryInterval();
        LockExecutor lockExecutor = obtainExecutor(executor);
        logger.debug(String.format("use lock class: %s", lockExecutor.getClass()));
        expire = !lockExecutor.renewal() && expire <= 0 ? properties.getExpire() : expire;
        int acquireCount = 0;
        String value = UUID.randomUUID().toString().replace("-", "");
        long start = System.currentTimeMillis();

        do {
            acquireCount++;
            Object lockInstance = lockExecutor.tryLock(key, value, expire, acquireTimeout);
            if (null != lockInstance) {
                return new LockInfo(key, value, expire, acquireTimeout, acquireCount, lockInstance, lockExecutor);
            }
            TimeUnit.MILLISECONDS.sleep(retryInterval);
        } while (System.currentTimeMillis() - start < acquireTimeout);
        return null;
    }

    /**
     * 加锁方法
     * 
     * @param key
     *            锁key 同一个key只能被一个客户端持有
     * @param expire
     *            过期时间(ms) 防止死锁
     * @param executor
     *            执行器
     * @return 加锁成功返回锁信息 失败返回null
     */
    public LockInfo lock(String key, long expire, Class<? extends LockExecutor> executor) throws Exception {
        LockExecutor lockExecutor = obtainExecutor(executor);
        logger.debug(String.format("use lock class: %s", lockExecutor.getClass()));
        expire = !lockExecutor.renewal() && expire <= 0 ? properties.getExpire() : expire;
        String value = UUID.randomUUID().toString().replace("-", "");
        Object lockInstance = lockExecutor.tryLock(key, value, expire);
        if (null != lockInstance) {
            return new LockInfo(key, value, expire, lockInstance, lockExecutor);
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public boolean releaseLock(LockInfo lockInfo) throws Exception {
        if (null == lockInfo) {
            return false;
        }
        return lockInfo.getLockExecutor().releaseLock(lockInfo.getLockKey(), lockInfo.getLockValue(),
            lockInfo.getLockInstance());
    }

    protected LockExecutor obtainExecutor(Class<? extends LockExecutor> clazz) {
        if (null == clazz || clazz == LockExecutor.class) {
            return primaryExecutor;
        }
        final LockExecutor lockExecutor = executorMap.get(clazz);
        Assert.notNull(lockExecutor, String.format("can not get bean type of %s", clazz));
        return lockExecutor;
    }

    @Override
    public void afterPropertiesSet() throws Exception {

        Assert.isTrue(properties.getAcquireTimeout() >= 0, "tryTimeout must least 0");
        Assert.isTrue(properties.getExpire() >= -1, "expireTime must lease -1");
        Assert.isTrue(properties.getRetryInterval() >= 0, "retryInterval must more than 0");
        Assert.hasText(properties.getLockKeyPrefix(), "lock key prefix must be not blank");
        Assert.notEmpty(executors, "executors must have at least one");

        for (LockExecutor executor : executors) {
            executorMap.put(executor.getClass(), executor);
        }

        final Class<? extends LockExecutor> primaryExecutor = properties.getPrimaryExecutor();
        if (null == primaryExecutor) {
            this.primaryExecutor = executors.get(0);
        } else {
            this.primaryExecutor = executorMap.get(primaryExecutor);
            Assert.notNull(this.primaryExecutor, "primaryExecutor must be not null");
        }
    }
}

package com.ice.framework.web.lock.key;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.util.StringUtils;

import com.ice.framework.web.helper.RequestHelper;
import com.ice.framework.web.lock.Idempotent;
import com.ice.framework.web.lock.spel.SpelMethodBasedExpressionEvaluator;

import cn.hutool.core.util.ObjectUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

/**
 * 分布式锁Key生成器
 *
 * @author zengzhihong TaoYu
 */
@RequiredArgsConstructor
public class DefaultIdempotentKeyBuilder {
    // SPEL
    private final SpelMethodBasedExpressionEvaluator methodBasedExpressionEvaluator;
    private static final String EMPTY_KEY = "";

    public String buildKey(Method method, Object[] arguments, Idempotent idempotent) {
        String header = parseRequestHeader(idempotent);
        String identiys = getSpelDefinitionKey(method, arguments, idempotent.keys());
        String result = EMPTY_KEY;
        if (StringUtils.hasText(header)) {
            result += header + ".";
        }
        if (StringUtils.hasText(identiys)) {
            result += identiys;
        }
        return result;
    }

    protected String getSpelDefinitionKey(Method method, Object[] arguments, String[] definitionKeys) {
        return Stream.of(definitionKeys).filter(StringUtils::hasText)
            .map(k -> methodBasedExpressionEvaluator.getValue(method, arguments, k, String.class))
            .collect(Collectors.joining("."));
    }

    /**
     * 获取Header的信息
     * 
     * @Author wangwei
     * @Date 2024/6/18
     */
    private String parseRequestHeader(Idempotent annotation) {
        List<String> headers = new ArrayList<String>();
        String[] header = annotation.header();
        if (header != null && header.length != 0) {
            HttpServletRequest request = RequestHelper.getRequest();
            if (request != null) {
                String[] var8 = header;
                int var7 = header.length;

                for (int var6 = 0; var6 < var7; ++var6) {
                    String name = var8[var6];
                    String value = request.getHeader(name);
                    if (StringUtils.hasText(value)) {
                        headers.add(value);
                    }
                }
            }
        }
        if (ObjectUtil.isNotEmpty(headers)) {
            return headers.stream().collect(Collectors.joining("."));
        }
        return null;
    }
}

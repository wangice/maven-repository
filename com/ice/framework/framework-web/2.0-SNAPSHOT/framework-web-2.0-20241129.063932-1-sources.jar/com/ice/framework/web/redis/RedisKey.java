package com.ice.framework.web.redis;

/**
 * @author wangwei
 * @Date 2021/12/20 19:38
 */
public class RedisKey {

    // redis前端
    private String prex;

    private String code;

    private String[] params;

    private RedisKey(String code, String... params) {
        this.code = code;
        this.params = params;
    }

    public RedisKey(String prex, String code, String[] params) {
        super();
        this.prex = prex;
        this.code = code;
        this.params = params;
    }

    /**
     * 本地缓存KEY
     *
     * @param code
     * @param params
     * @return
     * @author wangwei
     * @Date 2021/12/20 19:38
     */
    public static RedisKey valueOf(String code, String... params) {
        return new RedisKey(code, params);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String[] getParams() {
        return params;
    }

    public void setParams(String[] params) {
        this.params = params;
    }

    public String getPrex() {
        return prex;
    }

    public void setPrex(String prex) {
        this.prex = prex;
    }

}

package com.ice.framework.web.excel.annotation;

/**
 * 单元格的动态下拉框
 * 
 * @author wangwei
 * @Date 2024/8/19 14:40
 */
public interface ExcelDynamicSelect {
    /**
     * 获取动态生成的下拉框可选数据
     * 
     * @return 动态生成的下拉框可选数据
     */
    String[] getSource();
}

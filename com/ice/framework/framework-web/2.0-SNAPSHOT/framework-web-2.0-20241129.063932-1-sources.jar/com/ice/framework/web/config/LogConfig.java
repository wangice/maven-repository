package com.ice.framework.web.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.ice.framework.web.tlog.filter.TLogFilter;

/**
 * 问题：Springboot3.0版本使用Tlog（1.5.1版本）开源框架时无法打印指定参数
 *
 * 原因：在Java EE 8及更高版本中，javax.servlet.*包已经替换成了jakarta.servlet.*，但是tlog官方只更新到了1.5.1版本所以还没支持到
 *
 * 解决方法：重写tlog中TLogServletFilter，TLogWebCommon两个关键类将javax.servlet包的东西替换成jakarta.servlet包的就可以了
 *
 * @author wangwei
 * @Date 2024/6/6 17:45
 */
@Configuration
@ComponentScan(value = "com.yomahub.tlog")
public class LogConfig {

    @Bean
    public FilterRegistrationBean<TLogFilter> loggingFilter() {
        FilterRegistrationBean<TLogFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new TLogFilter());
        registrationBean.addUrlPatterns("/*"); // 拦截所有请求路径
        return registrationBean;
    }

}

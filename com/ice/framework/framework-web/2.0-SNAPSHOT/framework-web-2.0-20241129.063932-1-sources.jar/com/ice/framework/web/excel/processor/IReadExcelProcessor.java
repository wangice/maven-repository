package com.ice.framework.web.excel.processor;

import java.util.List;
import java.util.Map;

/**
 * 读取Excel数据处理接口
 * 
 * @author wangwei
 * @Date 2024/8/20 17:55
 */
public interface IReadExcelProcessor<T> {

    /**
     * Excel数据处理
     * 
     * @param list
     */
    void processorDataList(List<T> list);

    /**
     * 处理表头
     * 
     * @param headMap
     */
    default void processorHandMap(Map<Integer, String> headMap) {}
}

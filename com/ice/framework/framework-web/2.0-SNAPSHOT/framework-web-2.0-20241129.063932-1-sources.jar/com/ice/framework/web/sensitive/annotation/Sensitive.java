package com.ice.framework.web.sensitive.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.fasterxml.jackson.annotation.JacksonAnnotationsInside;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import com.ice.framework.web.sensitive.SensitiveStrategy;
import com.ice.framework.web.sensitive.serializer.JacksonSensitiveSerializer;

/**
 * @author wangwei
 * @Date 2024/6/24 11:17
 */
@Inherited
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.ANNOTATION_TYPE})
@JacksonAnnotationsInside
@JsonSerialize(using = JacksonSensitiveSerializer.class)
public @interface Sensitive {

    /**
     * Sensitive strategy
     *
     * @return strategy
     */
    SensitiveStrategy strategy();
}

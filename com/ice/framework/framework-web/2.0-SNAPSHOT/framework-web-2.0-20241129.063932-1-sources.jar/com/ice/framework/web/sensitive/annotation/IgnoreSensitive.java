package com.ice.framework.web.sensitive.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author wangwei
 * @Date 2024/6/24 14:31
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD})
public @interface IgnoreSensitive {
    /**
     * Ignore {@link Sensitive} field names.
     *
     * @return field names
     */
    String[] value() default {};
}

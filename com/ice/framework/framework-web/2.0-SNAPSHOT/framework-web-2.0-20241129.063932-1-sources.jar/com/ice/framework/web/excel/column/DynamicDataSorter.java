package com.ice.framework.web.excel.column;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.alibaba.excel.annotation.ExcelProperty;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ReflectUtil;
import lombok.Getter;

/**
 * @author wangwei
 * @Date 2024/8/20 19:34
 */
@Getter
public class DynamicDataSorter<T> {
    // 反射后的头部集合
    List<List<String>> heads = new LinkedList<>();
    // 反射后的数据集合
    List<List> datas = new LinkedList<>();

    /**
     * 动态顺序 通过指定顺序的字段名集合，使用反射获取对应的字段值 放到 二维集合中
     * 
     * @param fieldsInSpecifiedOrder
     *            导出字段的顺序集合，字段需要与导出的字段名一致
     * @param dataList
     *            导出数据集合
     * @param dtoClass
     *            导出类型
     */
    public DynamicDataSorter(List<String> fieldsInSpecifiedOrder, List<T> dataList, Class<T> dtoClass) {
        // 先获取两个集合
        Field[] declaredFields = dtoClass.getDeclaredFields();
        Set<String> declaredFieldSet = new HashSet<>(declaredFields.length); // 集合 1
        Map<String, String[]> fieldMapAnnotation = new HashMap<>(declaredFields.length); // 集合 2
        ExcelProperty annotation = null;
        for (Field declaredField : declaredFields) {
            declaredFieldSet.add(declaredField.getName());
            annotation = declaredField.getAnnotation(ExcelProperty.class);
            if (annotation != null) {
                fieldMapAnnotation.put(declaredField.getName(), annotation.value());
            } else {
                String[] arr = {declaredField.getName()};
                fieldMapAnnotation.put(declaredField.getName(), arr);
            }
        }
        // 处理表头字段
        fieldsInSpecifiedOrder.forEach(fieldName -> {
            if (null != fieldMapAnnotation.get(fieldName)) {
                heads.add(Arrays.asList(fieldMapAnnotation.get(fieldName)));
            }
        });
        // 处理内容数据
        if (CollUtil.isNotEmpty(dataList)) {
            dataList.forEach(data -> {
                List list = new LinkedList();
                fieldsInSpecifiedOrder.forEach(fieldName -> {
                    if (declaredFieldSet.contains(fieldName)) {
                        list.add(ReflectUtil.getFieldValue(data, fieldName)); // https://blog.csdn.net/weixin_70221917/article/details/129132630
                    }
                });
                datas.add(list);
            });
        }
    }
}

package com.ice.framework.web.sensitive.serializer;

import com.alibaba.fastjson2.filter.BeanContext;
import com.alibaba.fastjson2.filter.ContextValueFilter;

/**
 * @author wangwei
 * @Date 2024/6/24 17:25
 */
public class FastJson2SensitiveValueFilter extends AbstractFastJsonSensitiveValueFilter implements ContextValueFilter {
    @Override
    public Object process(BeanContext beanContext, Object object, String name, Object value) {
        return this.process(object, name, value);
    }
}

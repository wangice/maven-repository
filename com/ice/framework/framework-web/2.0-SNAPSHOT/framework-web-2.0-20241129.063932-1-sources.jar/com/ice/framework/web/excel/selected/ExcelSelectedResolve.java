package com.ice.framework.web.excel.selected;

import com.ice.framework.web.excel.annotation.ExcelDynamicSelect;
import com.ice.framework.web.excel.annotation.ExcelSelected;
import com.ice.framework.web.helper.SpringContextHelper;

import cn.hutool.core.util.ObjectUtil;
import lombok.Data;

/**
 * @author wangwei
 * @Date 2024/8/19 14:47
 */
@Data
public class ExcelSelectedResolve {
    /**
     * 下拉内容
     */
    private String[] source;

    /**
     * 设置下拉框的起始行，默认为第二行
     */
    private int firstRow;

    /**
     * 设置下拉框的结束行，默认为最后一行
     */
    private int lastRow;

    public String[] resolveSelectedSource(ExcelSelected excelSelected) {
        String[] source = excelSelected.source();
        if (source.length > 0) {
            return source;// 获取固定下拉框的内容
        } else {
            Class<? extends ExcelDynamicSelect>[] classes = excelSelected.sourceClass();// 获取动态下拉框的内容
            if (classes.length > 0) {
                // 动态下拉框都从环境中获取
                ExcelDynamicSelect excelDynamicSelect = (ExcelDynamicSelect)SpringContextHelper.getBean(classes[0]);
                if (ObjectUtil.isNotEmpty(excelDynamicSelect)) {
                    return excelDynamicSelect.getSource();
                }
            }
        }
        return null;
    }
}

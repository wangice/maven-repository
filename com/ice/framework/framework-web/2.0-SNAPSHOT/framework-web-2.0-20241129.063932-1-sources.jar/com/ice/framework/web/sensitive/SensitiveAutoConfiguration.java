package com.ice.framework.web.sensitive;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.alibaba.fastjson2.support.spring6.http.converter.FastJsonHttpMessageConverter;

import com.ice.framework.web.sensitive.resolver.RequestMappingResolver;

/**
 * 脱敏配置
 * 
 * @author wangwei
 * @Date 2024/6/24 15:24
 */
@Configuration
public class SensitiveAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public RequestMappingResolver handlerMethodServletParser(
        @Qualifier("requestMappingHandlerMapping") RequestMappingHandlerMapping requestMappingHandlerMapping) {
        return new RequestMappingResolver(requestMappingHandlerMapping);
    }

    @Bean
    @ConditionalOnBean({FastJsonHttpMessageConverter.class})
    public FastJson2BeanPostProcessor fastJson2BeanPostProcessor() {
        return new FastJson2BeanPostProcessor();
    }
}

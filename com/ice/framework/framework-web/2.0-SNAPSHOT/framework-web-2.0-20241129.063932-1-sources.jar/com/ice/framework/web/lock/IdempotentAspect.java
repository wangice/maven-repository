package com.ice.framework.web.lock;

import java.lang.reflect.Method;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.aop.framework.AopProxyUtils;
import org.springframework.aop.support.AopUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ice.framework.common.exception.IdempotentException;
import com.ice.framework.web.lock.info.LockInfo;
import com.ice.framework.web.lock.info.LockProperties;
import com.ice.framework.web.lock.key.DefaultIdempotentKeyBuilder;

import lombok.extern.slf4j.Slf4j;

/**
 * @author wangwei
 * @Date 2024/7/9 14:29
 */
@Slf4j
@Aspect
@Component
public class IdempotentAspect {
    // key 生成器
    private DefaultIdempotentKeyBuilder defaultLockKeyBuilder;
    // lock参数
    private final LockProperties lockProperties;
    // 获取锁信息
    private final LockTemplate lockTemplate;

    public IdempotentAspect(LockTemplate lockTemplate, LockProperties lockProperties,
        DefaultIdempotentKeyBuilder defaultLockKeyBuilder) {
        this.lockTemplate = lockTemplate;
        this.lockProperties = lockProperties;
        this.defaultLockKeyBuilder = defaultLockKeyBuilder;
    }

    @Pointcut("@annotation(com.ice.framework.web.lock.Idempotent)")
    public void executeIdempotent() {

    }

    @Around("executeIdempotent()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        // 获取目标类
        Object target = joinPoint.getThis();
        Class<?> targetClass = AopProxyUtils.ultimateTargetClass(target);
        // 获取方法
        MethodSignature ms = (MethodSignature)joinPoint.getSignature();
        Method method = ms.getMethod();
        Idempotent idempotent = (Idempotent)method.getAnnotation(Idempotent.class);
        // 可解决代理对象问题
        Method targetMethod = AopUtils.getMostSpecificMethod(method, targetClass);
        LockInfo lockInfo = null;
        Object[] arguments = joinPoint.getArgs();

        String prefix = lockProperties.getLockKeyPrefix() + ":";
        prefix += StringUtils.hasText(idempotent.name()) ? idempotent.name()
            : method.getDeclaringClass().getName() + method.getName();
        String key = prefix + "#" + defaultLockKeyBuilder.buildKey(targetMethod, arguments, idempotent);

        lockInfo = lockTemplate.lock(key, idempotent.expire(), idempotent.executor());
        // 锁已存在
        if (lockInfo == null) {
            throw new IdempotentException();
        }
        try {
            return joinPoint.proceed();
        } catch (Exception e) {
            lockTemplate.releaseLock(lockInfo);
            throw e;
        } finally {
            final boolean releaseLock;
            try {
                releaseLock = lockTemplate.releaseLock(lockInfo);
                if (!releaseLock) {
                    logger.error("releaseLock fail,lockKey={},lockValue={}", lockInfo.getLockKey(),
                        lockInfo.getLockValue());
                }
            } catch (Exception e) {
                logger.error("releaseLock fail,{}", ExceptionUtils.getStackTrace(e));
            }
        }
    }
}

package com.ice.framework.web.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.ice.framework.common.annotation.AutoResult;
import com.ice.framework.common.base.ResponseResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.method.support.ModelAndViewContainer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 处理RestController返回值问题
 * @author wangwei
 * @Date 2021/12/22 17:06
 */
public class AutoResultReturnValueHandler implements HandlerMethodReturnValueHandler {

    private static Logger logger = LoggerFactory.getLogger(AutoResultReturnValueHandler.class);

    public AutoResultReturnValueHandler() {
    }

    @Override
    public boolean supportsReturnType(MethodParameter returnType) {
        return (isRestController(returnType) || (isController(returnType) && isResponseBody(returnType))) && isAutoResult(returnType);
    }

    @Override
    public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
        HttpServletRequest request = (HttpServletRequest) webRequest.getNativeRequest(HttpServletRequest.class);
        mavContainer.setRequestHandled(true);
        HttpServletResponse response = (HttpServletResponse) webRequest.getNativeResponse(HttpServletResponse.class);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=utf-8");
        StringBuilder info = (StringBuilder) request.getAttribute("_REQUEST_LOG_INFO_");
        if (info == null) {
            info = new StringBuilder();
        }

        String requestId = (String) request.getAttribute("_REQUEST_ID_");
        ResponseResult<Object> result = new ResponseResult<>();
        result.setData(returnValue);
        result.setRequestId(requestId);
        String jsonString = JSON.toJSONString(result, new SerializerFeature[]{SerializerFeature.WriteDateUseDateFormat});
        Long startTime = (Long) request.getAttribute("_REQUEST_STARTTIME_");
        info.append("[==响应结果=======]>: ").append(jsonString);
        info.append("\n");
        if (startTime != null) {
            info.append("[==执行耗时=======]>: ").append(System.currentTimeMillis() - startTime).append("ms").append("\n");
        }
        logger.info(info.toString());
        response.getWriter().append(jsonString);
    }

    private boolean isRestController(MethodParameter returnType) {
        RestController annotation = (RestController) returnType.getDeclaringClass().getAnnotation(RestController.class);
        return annotation != null;
    }

    private boolean isController(MethodParameter returnType) {
        Controller annotation = returnType.getDeclaringClass().getAnnotation(Controller.class);
        return annotation != null;
    }

    private boolean isResponseBody(MethodParameter returnType) {
        ResponseBody methodAnnotation = (ResponseBody) returnType.getMethodAnnotation(ResponseBody.class);
        return methodAnnotation != null;
    }

    private boolean isAutoResult(MethodParameter returnType) {
        AutoResult methodAnnotation = (AutoResult) returnType.getMethodAnnotation(AutoResult.class);
        if (methodAnnotation != null) {
            return methodAnnotation.value();
        } else {
            AutoResult annotation = (AutoResult) returnType.getDeclaringClass().getAnnotation(AutoResult.class);
            return annotation != null && annotation.value();
        }
    }
}

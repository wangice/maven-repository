package com.ice.framework.web.repeat;

import java.lang.annotation.*;

/**
 * 幂等注解校验
 * @author wangwei
 * @Date 2021/12/20 14:24
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Idempotent {
    /**
     * 重复请求的时间限制，单位毫秒。默认在1000ms内不允许重复请求。
     *
     * <br>注：
     * 当请求完成时，会允许再次请求，不受时间限制。
     *
     * @return
     *
     * @author wangwei
     * @date 2021年2月18日 上午10:48:52
     */
    int time() default 1000;

    /**
     * 指定重复验证的Key。如果不指定时，则不做参数校验
     *
     * @return
     *
     * @author wangwei
     * @date 2021年2月18日 上午11:03:11
     */
    String[] key() default {};


    /**
     * 忽略指定的Key不参与重复校验。默认所有都参与
     *
     * @return
     *
     * @author wangwei
     * @date 2021年2月18日 上午11:05:17
     */
    String[] ignoreKey() default {};

    /**
     * 指定头信息中的KEY值，校验时将获取对应的header值。默认不校验
     *
     * @return
     *
     * @author wangwei
     * @date 2021年2月22日 下午8:50:25
     */
    String[] header() default {};


    /**
     * 是否强制限制在 {@link #time()} 时间内不允许重复提交。
     *
     * 默认情况为false，即在校验时间内如果请求完成后允许再次请求。
     *
     * @return
     *
     * @author wangwei
     * @date 2021年2月23日 下午5:49:49
     */
    boolean force() default false;

    /**
     * 是否忽略所有的KEY。如果设置为true，则{@link #ignoreKey()} 和 {@link #key()} 的设置将被忽略
     *
     * @return
     *
     * @author wangwei
     * @date 2021年6月11日 上午11:40:31
     */
    boolean ignoreAllKey() default false;

    /**
     * 幂等校验提示信息
     *
     * @return
     *
     * @author wangwei
     * @date 2021年6月19日 上午10:53:23
     */
    String message() default "系统正在处理，请稍候！";
}

package com.ice.framework.web.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import com.ice.framework.common.context.RequestContextThreadLocal;
import com.ice.framework.web.helper.RequestHelper;
import io.lettuce.core.tracing.TraceContext;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdvice;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.UUID;

/**
 * @author wangwei
 * @Date 2021/12/22 17:48
 */
@ControllerAdvice
public class RequestBodyAdviceHandler implements RequestBodyAdvice {

    public RequestBodyAdviceHandler() {
    }

    public boolean supports(MethodParameter methodParameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType) {
        Method method = methodParameter.getMethod();
        Class<?> declaringClass = method.getDeclaringClass();
        RestController RestController = (RestController) declaringClass.getAnnotation(RestController.class);
        return RestController != null;
    }

    public HttpInputMessage beforeBodyRead(HttpInputMessage inputMessage, MethodParameter parameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType) throws IOException {
        return inputMessage;
    }

    public Object afterBodyRead(Object body, HttpInputMessage inputMessage, MethodParameter parameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType) {
        this.writeRequestLog(body, inputMessage, parameter, targetType, converterType);
        return body;
    }

    public Object handleEmptyBody(Object body, HttpInputMessage inputMessage, MethodParameter parameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType) {
        this.writeRequestLog(body, inputMessage, parameter, targetType, converterType);
        return body;
    }


    private void writeRequestLog(Object body, HttpInputMessage inputMessage, MethodParameter parameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType) {
        HttpServletRequest request = RequestHelper.getRequest();
        request.setAttribute("_REQUEST_STARTTIME_", System.currentTimeMillis());
        String requestId = request.getHeader("_REQUEST_ID_");
        // 需要引入skywalking
//        if (StringUtils.isEmptyStr(requestId)) {
//            requestId = TraceContext.traceId();
//        }

        if (StringUtils.isEmpty(requestId) || "Ignored_Trace".equals(requestId)) {
            requestId = UUID.randomUUID().toString().replaceAll("-", "");
        }

        request.setAttribute("_REQUEST_ID_", requestId);
        StringBuilder info = new StringBuilder("==>\n");
        info.append("[*=请求requestID=]>: ").append(requestId).append("\n");
        info.append("[==请求地址=======]>: ").append(request.getRequestURL().toString()).append("\n");
        info.append("[==请求方法=======]>: ").append(request.getMethod()).append("\n");
//        info.append("[==操作用户=======]>: ").append(UserInfoContext.getCurrentUserCode()).append("\n");
        info.append("[==客户IP========]>: ").append(RequestHelper.getClientIP()).append("\n");
        info.append("[==映射方法=======]>: ").append(parameter.getMethod()).append(".").append("\n");
        if (body == null) {
            info.append("[==请求参数=======]>: ").append("该接口未定义参数或参数为空");
        } else if (converterType == FastJsonHttpMessageConverter.class) {
            info.append("[==请求参数=======]>: ").append(JSON.toJSONString(body));
        } else {
            info.append("[==请求参数=======]>: ").append(converterType);
        }

        info.append("\n");
        request.setAttribute("_REQUEST_LOG_INFO_", info);
        RequestContextThreadLocal.setRequestId(requestId);
    }
}

package com.ice.framework.web.repeat;

import cn.hutool.core.util.ClassUtil;
import cn.hutool.core.util.ReflectUtil;
import com.ice.framework.common.exception.IdempotentException;
import com.ice.framework.common.util.DataUtil;
import com.ice.framework.web.helper.ConfigHelper;
import com.ice.framework.web.helper.RequestHelper;
import com.ice.framework.web.redis.LocalRedisHelper;
import com.ice.framework.web.redis.RedisKey;
import lombok.CustomLog;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.time.Duration;

/**
 * @author wangwei
 * @Date 2021/12/20 14:27
 */
@Aspect
@Component
@ConditionalOnBean(StringRedisTemplate.class)
public class IdempotentAspect {

    private static Logger logger = LoggerFactory.getLogger(IdempotentAspect.class);


    private static final String KEY_TEMPLATE = "Idempotent";

    private static final String NULL_VALUE = "null";

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Pointcut("@annotation(com.ice.framework.web.repeat.Idempotent)")
    public void executeIdempotent() {

    }

    @Around("executeIdempotent()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        // 获取方法
        MethodSignature ms = (MethodSignature) joinPoint.getSignature();
        Method method = ms.getMethod();
        // 获取幂等注解
        Idempotent idempotent = method.getAnnotation(Idempotent.class);

        String application = ConfigHelper.getApplicationName();
        String methodName = this.getMethodSignature(method);
        String methodArg = this.getMethodArgString(joinPoint.getArgs(), idempotent);
        String header = this.getHeaderString(idempotent);

        RedisKey key = RedisKey.valueOf("Idempotent", new String[]{application, methodName, methodArg, header});
        logger.info("幂等校验：{}", LocalRedisHelper.getRedisResultKey(key));
        boolean result = LocalRedisHelper.setIfAbsent(key, "1", Duration.ofMillis(idempotent.time()));
        if (!result) {
            throw new IdempotentException(idempotent.message());
        }
        Object t = null;
        try {
            t = joinPoint.proceed();
        } catch (Exception var16) {
            LocalRedisHelper.delete(key);
            throw var16;
        } finally {
            if (!idempotent.force()) {
                LocalRedisHelper.delete(key);
            }
        }
        return t;
    }

    /**
     * 获取方法名
     * @Author wangwei
     * @Date 2021/12/20
     */
    private String getMethodSignature(Method method) {
        //return method.toString();
        String name = method.getDeclaringClass().getName();
        return name + "." + method.getName();
    }


    /**
     * 获取参数组成的字符串
     *
     * @param args 方法参数
     * @return 参数组成的字符串，如果参数为空，则返回"null"
     *
     * @Author wangwei
     * @Date 2021/12/20
     */
    private String getMethodArgString(Object[] args, Idempotent annotation) {
        if (args == null || args.length == 0) {
            return NULL_VALUE;
        }

        if (annotation.ignoreAllKey()) {
            return NULL_VALUE;
        }

        String[] keys = annotation.key();

        if (keys == null) {
            return NULL_VALUE;
        }

        StringBuilder sb = new StringBuilder();
        for (Object a : args) {
            sb.append(this.argToString(a, annotation));
        }
        return sb.toString();
    }

    /*
     * 方法参数处理。 如果参数为基本类型，则返回{@code arg.toString() }, 如果参数为框架基础对象，则调用{@code
     * JSON.toJSONString() }， 否则不处理返回NULL
     *
     * @param bean 方法参数
     *
     * @param annotation 幂等注解
     *
     * @return 字符串
     *
     * @Author wangwei
     * @Date 2021/12/20
     */
    private String argToString(Object bean, Idempotent annotation) {
        if (DataUtil.isBaseType(bean.getClass())) {
            return bean.toString();
        }
        return getBeanValue(bean, annotation);
    }

    /*
     * 获取bean的值，组成字符串
     *
     * @param bean
     * @param annotation
     * @return
     *
     * @Author wangwei
     * @Date 2021/12/20
     */
    private String getBeanValue(Object bean, Idempotent annotation) {
        String[] keys = annotation.key();

        //如果只有单个Key，直接返回key对应的值
        Object value = null;
        if (keys.length == 1) {
            value = ReflectUtil.getFieldValue(bean, keys[0]);
        }

        if (value != null) {
            return value.toString();
        }

        StringBuilder sb = new StringBuilder();
        for (String name : keys) {
            sb.append("_").append(name).append("_").append(ReflectUtil.getFieldValue(bean, name));
        }

        return sb.toString();
    }

    /*
     * 获取组成KEY的头信息
     *
     * @param annotation 幂等注解
     *
     * @return 头信息字组成的字符串，如果为空返回"null"
     *
     * @Author wangwei
     * @Date 2021/12/20
     */
    private String getHeaderString(Idempotent annotation) {
        String[] header = annotation.header();
        if (header == null || header.length == 0) {
            return NULL_VALUE;
        }
        HttpServletRequest request = RequestHelper.getRequest();
        if (request == null) {
            return NULL_VALUE;
        }

        if (annotation.ignoreAllKey()) {
            return NULL_VALUE;
        }

        StringBuilder sb = new StringBuilder();
        for (String h : header) {
            sb.append("_").append(h).append("_").append(trimNullToString(request.getHeader(h)));
        }

        return sb.toString();
    }

    /*
     * 字符串处理
     *
     * @param value 字符串值
     *
     * @return 如果字符串为null，返回"null"
     *
     * @Author wangwei
     * @Date 2021/12/20
     */
    private String trimNullToString(String value) {
        return value == null ? NULL_VALUE : value;
    }
}

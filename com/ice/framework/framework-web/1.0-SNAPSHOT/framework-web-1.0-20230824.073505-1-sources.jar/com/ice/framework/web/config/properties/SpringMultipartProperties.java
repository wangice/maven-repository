package com.ice.framework.web.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author wangwei
 * @Date 2022/1/4 10:12
 */
@ConfigurationProperties(prefix = "spring.http.multipart")
public class SpringMultipartProperties {
    // 默认最大上传文件大小（单个 10MB）
    private static int DEFAULT_MAX_FILE_SIZE = 15 * 1024 * 1024;

    // 默认最大上传文件大小（多个文件总大小 100MB）
    private static int DEFAULT_TOTAL_MAX_FILE_SIZE = 100 * 1024 * 1024;

    private int maxFileSize = DEFAULT_MAX_FILE_SIZE;

    private int maxRequestSize = DEFAULT_TOTAL_MAX_FILE_SIZE;

    public int getMaxFileSize() {
        return maxFileSize;
    }

    public void setMaxFileSize(int maxFileSize) {
        this.maxFileSize = maxFileSize;
    }

    public int getMaxRequestSize() {
        return maxRequestSize;
    }

    public void setMaxRequestSize(int maxRequestSize) {
        this.maxRequestSize = maxRequestSize;
    }
}

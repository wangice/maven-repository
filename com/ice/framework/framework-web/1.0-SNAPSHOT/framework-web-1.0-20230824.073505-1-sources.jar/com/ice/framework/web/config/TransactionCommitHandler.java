package com.ice.framework.web.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * 事务提交后执行，一般用于事务执行过程不影响核心业务逻辑时，排除在整个事务外
 * 或者事务中存在远程调用，该远程调用可以通过补偿的方式处理异常时调用
 *
 * 调用方式
 *     @Autowired
 *     private TransactionCommitHandler transactionCommitHandler;
 *
 *
 *     在事务方法中
 *     transactionCommitHandler.handle(()->{
 *         操作数据库或者远程调用
 *     })
 * @author wangwei
 * @Date 2023/1/7 11:09
 */
@Component
public class TransactionCommitHandler {


    public void handle(final Runnable action){
        if (TransactionSynchronizationManager.isActualTransactionActive()){
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    action.run();
                }
            });
        }else{
            action.run();
        }
    }
}

package com.ice.framework.web.repeat;

import org.aspectj.lang.JoinPoint;

/**
 * @author wangwei
 * @Date 2022/1/21 10:47
 */
public interface KeyResolver {

    /**
     * 解析处理 key
     * @param idempotent 接口注解标识
     * @param point 接口切点信息
     * @return 处理结果
     */
    String resolver(Idempotent idempotent, JoinPoint point);
}

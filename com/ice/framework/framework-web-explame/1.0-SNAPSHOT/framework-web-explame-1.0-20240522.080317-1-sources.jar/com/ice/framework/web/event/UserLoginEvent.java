package com.ice.framework.web.event;

import lombok.Getter;
import lombok.Setter;
import org.springframework.context.ApplicationEvent;

/**
 * @author wangwei
 * @Date 2024/2/23 14:40
 */
@Setter
@Getter
public class UserLoginEvent extends ApplicationEvent {

    private String userName;

    public UserLoginEvent(Object source, String userName) {
        super(source);
        this.userName = userName;
    }
}

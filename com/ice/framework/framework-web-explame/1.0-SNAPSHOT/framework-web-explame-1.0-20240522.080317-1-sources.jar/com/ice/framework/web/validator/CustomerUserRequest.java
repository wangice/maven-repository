package com.ice.framework.web.validator;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wangwei
 * @Date 2023/11/8 16:55
 */
@Data
public class CustomerUserRequest implements Serializable {

    private static final long serialVersionUID = 7988955678779492411L;
    @Schema(description = "性别")
    @EnumValid(enumClass = SexEnum.class, message = "性别不正确")
    private String sex;
}

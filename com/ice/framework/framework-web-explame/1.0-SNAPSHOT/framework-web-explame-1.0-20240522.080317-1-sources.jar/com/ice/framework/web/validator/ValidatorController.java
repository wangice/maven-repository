package com.ice.framework.web.validator;

import com.ice.framework.common.annotation.AutoResult;
import com.ice.framework.common.util.ValidateHelperUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author wangwei
 * @Date 2023/11/8 16:44
 */
@Tag(name = "校验")
@AutoResult
@RestController
public class ValidatorController {

    @Operation(summary = "创建书籍")
    @PostMapping(value = "/validators")
    public void validators(@RequestBody CustomerUserRequest customerUserRequest) {
        ValidateHelperUtil.validateNull(customerUserRequest, new String[]{"sex"});
    }
}

package com.ice.framework.web.event;

import com.ice.framework.common.annotation.AutoResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author wangwei
 * @Date 2024/2/23 14:43
 */
@AutoResult
@RestController
public class ApplicationEventController {

    @Autowired
    private ApplicationContext applicationContext;

    @GetMapping("/userLogin")
    public void userLogin() {
        applicationContext.publishEvent(new UserLoginEvent(new Object(), "ice"));
    }
}

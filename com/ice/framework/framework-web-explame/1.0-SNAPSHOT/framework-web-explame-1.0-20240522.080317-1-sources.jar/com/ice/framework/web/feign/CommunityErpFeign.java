package com.ice.framework.web.feign;

import com.alibaba.fastjson.JSONObject;
import com.ice.framework.openfeign.config.FeignClientDefaultConfiguration;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 * @author wangwei
 * @Date 2022/2/16 15:18
 */
@FeignClient(value = "api-community-task", url = "${feign.communityErp}", configuration = FeignClientDefaultConfiguration.class)
public interface CommunityErpFeign {

    @PostMapping(value = "/api/stock/storecheckstockorder/findStoreCheckStockOrderDetail")
    public Object getComminutyInfo(@RequestBody StoreCheckStockOrderEntity storeCheckStockOrderEntity);

    @PostMapping(value = "/api/store/storecheckstockorder/checkStockOrderAggregate")
    public Object checkStockOrderAggregate(@RequestBody JSONObject jsonObject, @RequestHeader("Authorization") String authorization);
}

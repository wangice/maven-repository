package com.ice.framework.web.feign;

import com.alibaba.fastjson.JSONObject;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author wangwei
 * @Date 2022/2/16 15:28
 */
@Tag(name = "获取用户")
@RestController
public class StoreCheckStockController {

    @Autowired
    private CommunityErpFeign communityErpFeign;

    @Operation(summary = "获取门店订单")
    @GetMapping(value = "/getStoreCheckStockOrder")
    public Object getStoreCheckStockOrder() {
        StoreCheckStockOrderEntity entity = new StoreCheckStockOrderEntity();
        entity.setCheckStockOrderNo("MDPDDD2022063100002");
        Object comminutyInfo = communityErpFeign.getComminutyInfo(entity);
        System.out.println(comminutyInfo);
        return comminutyInfo;
    }

    @GetMapping(value = "/checkStockOrderAggregate")
    public Object checkStockOrderAggregate(){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("checkMode","1");
        jsonObject.put("checkType","2");
        Object comminutyInfo = communityErpFeign.checkStockOrderAggregate(jsonObject, "5af70e6a-93ed-4f6e-813f-f72834e4c27d");
        System.out.println(comminutyInfo);
        return comminutyInfo;
    }
}

package com.ice.framework.web.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author wangwei
 * @Date 2022/12/6 14:35
 */
@FeignClient(value = "api-community-login", url = "${feign.login}")
public interface LoginFeign {

    @GetMapping(value = "/authentication")
    public void login(@RequestParam("redirectUrl") String redirectUrl);
}

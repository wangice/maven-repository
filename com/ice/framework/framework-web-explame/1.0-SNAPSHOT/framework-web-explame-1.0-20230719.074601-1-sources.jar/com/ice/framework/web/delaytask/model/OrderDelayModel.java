package com.ice.framework.web.delaytask.model;

import com.ice.framework.redission.delaytask.DelayTaskBase;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wangwei
 * @Date 2022/6/20 09:42
 */
@Data
public class OrderDelayModel extends DelayTaskBase implements Serializable {
    private static final long serialVersionUID = -7284901370281243242L;

    private String orderNo;
}

package com.ice.framework.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @author wangwei
 * @Date 2021/12/21 09:41
 */
@EnableFeignClients
@SpringBootApplication(scanBasePackages = {"com.ice.framework"})
public class WebSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebSpringBootApplication.class);
    }
}

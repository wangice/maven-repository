package com.ice.framework.web.bitmap;

import lombok.Data;

import java.io.Serializable;

/**
 * 访客访问记录表 实体对象
 *
 * @author system
 * @since 2022-03-15
 * @version 1.0
 */
@Data
public class VisitorAccessRecordRequest implements Serializable {


    private static final long serialVersionUID = 5216710659053765095L;
    // 唯一标识
	private String uniqueIdentity;
	
    // 活动id
	private Integer presentActivitiesId;
	
}

package com.ice.framework.web.repeat;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * @author wangwei
 * @Date 2021/12/31 16:02
 */
@Data
public class UserInfo {

    @NotEmpty(message = "名称不能为空")
    private String name;
}

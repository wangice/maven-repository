package com.ice.framework.web.delaytask.model;

import com.ice.framework.redission.delaytask.DelayTaskBase;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wangwei
 * @Date 2022/6/20 09:43
 */
@Data
public class PayDelayModel extends DelayTaskBase implements Serializable {
    private static final long serialVersionUID = -2394845050186184251L;

    private String payOrderNo;
}

package com.ice.framework.web.repeat;

import com.ice.framework.common.annotation.AutoResult;
import com.ice.framework.web.redis.SimpleRedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author wangwei
 * @Date 2021/12/21 09:44
 */
@AutoResult
@RestController
@RequestMapping("/idempotent")
public class IdempotentController {

    @Autowired
    private SimpleRedisUtil simpleRedisUtil;

    /**
     * 在1s内多次调用会抛异常
     * @Author wangwei
     * @Date 2021/12/21
     */
    @Idempotent
    @PostMapping("getUser")
    public String getUser(@Validated @RequestBody UserInfo userInfo) {
//        try {
//            Thread.sleep(2000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }

        return "hello" + " " + "ice";
    }

    @GetMapping("getAge")
    public String getAge() {
        UserInfo userInfo = new UserInfo();
        userInfo.setName("wangice");
        simpleRedisUtil.set("wang", userInfo);
        return "18";
    }


    @GetMapping("getU")
    public String getU(String name, String age) {

        return name + age;
    }
}

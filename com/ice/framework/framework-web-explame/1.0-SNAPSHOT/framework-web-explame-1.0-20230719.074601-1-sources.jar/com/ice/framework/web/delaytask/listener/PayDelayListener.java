package com.ice.framework.web.delaytask.listener;

import com.ice.framework.redission.delaytask.RedisDelayedQueueListener;
import com.ice.framework.web.config.DelayConfig;
import com.ice.framework.web.delaytask.model.PayDelayModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author wangwei
 * @Date 2022/6/20 09:39
 */
@Slf4j
@Component
public class PayDelayListener implements RedisDelayedQueueListener<PayDelayModel> {

    @Autowired
    private DelayConfig delayConfig;

    @Override
    public String getQueueName() {
        return delayConfig.getPayDelay();
    }

    @Override
    public boolean invoke(PayDelayModel payDelayModel) {
        log.info("支付延迟任务，消息：{}", payDelayModel);
        return true;
    }

    @Override
    public void retryFail(PayDelayModel payDelayModel) {
        log.info("支付保存失败记录");
    }
}

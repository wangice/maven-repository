package com.ice.framework.web.feign;

import com.ice.framework.openfeign.config.FeignClientDecodeConfiguration;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author wangwei
 * @Date 2022/2/16 15:18
 */
@FeignClient(value = "api-community-task", url = "${feign.communityErp}", configuration = FeignClientDecodeConfiguration.class)
public interface CommunityErpFeign {

    @PostMapping(value = "/api/stock/storecheckstockorder/findStoreCheckStockOrderDetail")
    public Object getComminutyInfo(@RequestBody StoreCheckStockOrderEntity storeCheckStockOrderEntity);
}

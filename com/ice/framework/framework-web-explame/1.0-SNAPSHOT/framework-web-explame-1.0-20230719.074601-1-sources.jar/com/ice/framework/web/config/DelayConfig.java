package com.ice.framework.web.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author wangwei
 * @Date 2022/6/20 09:52
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "delay.config")
public class DelayConfig {

    private String orderDelay;

    private String payDelay;
}

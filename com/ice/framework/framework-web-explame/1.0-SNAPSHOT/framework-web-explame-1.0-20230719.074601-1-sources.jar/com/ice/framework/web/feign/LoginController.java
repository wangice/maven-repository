package com.ice.framework.web.feign;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author wangwei
 * @Date 2022/12/6 16:21
 */
@RestController
public class LoginController {
    @Autowired
    private LoginFeign loginFeign;

    @GetMapping("/login")
    public void login(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String redirectUrl = "http://localhost:8081/login/callback";
        response.sendRedirect("http://localhost:8092/authentication?redirectUrl=" + redirectUrl);
    }


    @RequestMapping(value = "/login/callback", method = {RequestMethod.POST, RequestMethod.GET})
    public void loginCallback(HttpServletRequest request) {
        String token = request.getParameter("TOKEN");
        System.out.println("token:" + token);
    }

}

package com.ice.framework.web.feign;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author wangwei
 * @Date 2022/2/16 15:28
 */
@RestController
public class StoreCheckStockController {

    @Autowired
    private CommunityErpFeign communityErpFeign;

    @GetMapping(value = "/getStoreCheckStockOrder")
    public Object getStoreCheckStockOrder() {
        StoreCheckStockOrderEntity entity = new StoreCheckStockOrderEntity();
        entity.setCheckStockOrderNo("MDPDDD2022063100002");
        Object comminutyInfo = communityErpFeign.getComminutyInfo(entity);
        System.out.println(comminutyInfo);
        return comminutyInfo;
    }
}

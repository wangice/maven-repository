package com.ice.framework.web.validator;

import com.ice.framework.common.annotation.AutoResult;
import com.ice.framework.common.util.ValidateHelperUtil;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author wangwei
 * @Date 2023/11/8 16:44
 */
@AutoResult
@RestController
public class ValidatorController {

    @PostMapping(value = "/validators")
    public void validators(@RequestBody CustomerUserRequest customerUserRequest) {
        ValidateHelperUtil.validateNull(customerUserRequest, new String[]{"sex"});
    }
}

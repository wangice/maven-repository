package com.ice.framework.web.validator;

import com.ice.framework.common.base.BaseEnum;

/**
 * @author wangwei
 * @Date 2023/11/8 16:55
 */
public enum SexEnum implements BaseEnum {
    MAN("man", "男"), WOMAN("woman", "女");

    private String code;

    private String desc;

    SexEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @Override
    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}

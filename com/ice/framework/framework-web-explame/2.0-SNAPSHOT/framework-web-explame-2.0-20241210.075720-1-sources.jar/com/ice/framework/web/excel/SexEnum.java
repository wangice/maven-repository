package com.ice.framework.web.excel;

/**
 * @author wangwei
 * @Date 2024/8/20 17:34
 */

public enum SexEnum {

    WOMAN(1, "女"),

    MAN(0, "男"),;

    private int value;
    private String desc;

    public Integer value() {
        return value;
    }

    public String desc() {
        return desc;
    }

    SexEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static SexEnum instance(Integer value) {
        SexEnum[] enums = values();
        for (SexEnum stateEnum : enums) {
            if (stateEnum.value().equals(value)) {
                return stateEnum;
            }
        }
        return null;
    }
}

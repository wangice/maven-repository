package com.ice.framework.web.event;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;

import lombok.extern.slf4j.Slf4j;

/**
 * @author wangwei
 * @Date 2024/2/23 14:40
 */
@EnableAsync
@Slf4j
@Configuration
public class ApplicationEventListenerHandler {

    @Async
    @EventListener
    public void handleLoginUserEvent(UserLoginEvent loginEvent) {
        log.info("用户登录事件处理：{}", loginEvent.getUserName());
    }
}

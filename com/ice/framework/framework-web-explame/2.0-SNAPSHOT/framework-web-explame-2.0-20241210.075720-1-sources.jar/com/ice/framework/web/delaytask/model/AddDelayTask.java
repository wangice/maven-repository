package com.ice.framework.web.delaytask.model;

import java.io.Serializable;

import lombok.Data;

/**
 * @author wangwei
 * @Date 2022/6/20 09:49
 */
@Data
public class AddDelayTask implements Serializable {
    private static final long serialVersionUID = 6983687858789945430L;

    private Integer type;
}

package com.ice.framework.web.delaytask.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ice.framework.redission.delaytask.RedisDelayedQueueListener;
import com.ice.framework.web.config.DelayConfig;
import com.ice.framework.web.delaytask.model.OrderDelayModel;

import lombok.extern.slf4j.Slf4j;

/**
 * @author wangwei
 * @Date 2022/6/20 09:38
 */
@Slf4j
@Component
public class OrderDelayListener implements RedisDelayedQueueListener<OrderDelayModel> {

    @Autowired
    private DelayConfig delayConfig;

    @Override
    public String getQueueName() {
        return delayConfig.getOrderDelay();
    }

    @Override
    public boolean invoke(OrderDelayModel orderDelayModel) {
        log.info("订单延迟消息，消息：{}", orderDelayModel);
        return true;
    }

    @Override
    public void retryFail(OrderDelayModel orderDelayModel) {

    }

}

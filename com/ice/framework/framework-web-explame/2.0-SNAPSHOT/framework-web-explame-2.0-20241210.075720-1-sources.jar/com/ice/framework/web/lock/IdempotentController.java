package com.ice.framework.web.lock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ice.framework.common.annotation.AutoResult;
import com.ice.framework.web.redis.SimpleRedisUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author wangwei
 * @Date 2021/12/21 09:44
 */
@Tag(name = "重复校验")
@AutoResult
@RestController
@RequestMapping("/idempotent")
public class IdempotentController {

    @Autowired
    private SimpleRedisUtil simpleRedisUtil;

    /**
     * 在1s内多次调用会抛异常
     * 
     * @Author wangwei
     * @Date 2021/12/21
     */
    @Operation(summary = "测试幂等")
    @DistributedLock(header = {"Authorization"}, keys = {"#userInfo.name"})
    @PostMapping("getDisUser")
    public String getDisUser(@Validated @RequestBody UserInfo userInfo) {
        // try {
        // Thread.sleep(2000);
        // } catch (InterruptedException e) {
        // e.printStackTrace();
        // }

        return "hello" + " " + "ice";
    }

    @GetMapping("getAge")
    public String getAge() {
        UserInfo userInfo = new UserInfo();
        userInfo.setName("wangice");
        simpleRedisUtil.set("wang", userInfo);
        return "18";
    }

    @GetMapping("getU")
    public String getU(String name, String age) {

        return name + age;
    }
}

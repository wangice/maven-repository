package com.ice.framework.web.feign;

import java.io.IOException;

import com.alibaba.fastjson2.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * @author wangwei
 * @Date 2022/12/6 16:21
 */
@RestController
public class LoginController {
    @Autowired
    private LoginFeign loginFeign;
    @Autowired
    private RedisTemplate redisTemplate;

    @GetMapping("/login")
    public void login(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //String redirectUrl = "http://localhost:8081/login/callback";
        //response.sendRedirect("http://localhost:8092/authentication?redirectUrl=" + redirectUrl);
        String token = "ice123456";
        JSONObject json = new JSONObject();
        JSONObject userdetail = new JSONObject();
        userdetail.put("userName", "ice");
        userdetail.put("userCode", "123456");
        json.put("userDetail", userdetail);
        redisTemplate.opsForValue().set(token, json);
    }

    @RequestMapping(value = "/login/callback", method = {RequestMethod.POST, RequestMethod.GET})
    public void loginCallback(HttpServletRequest request) {
        String token = request.getParameter("TOKEN");
        System.out.println("token:" + token);
    }

}

package com.ice.framework.web.delaytask;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ice.framework.redission.delaytask.RedisDelayedQueue;
import com.ice.framework.web.config.DelayConfig;
import com.ice.framework.web.delaytask.model.AddDelayTask;
import com.ice.framework.web.delaytask.model.OrderDelayModel;
import com.ice.framework.web.delaytask.model.PayDelayModel;

/**
 * @author wangwei
 * @Date 2022/6/20 09:38
 */
@RestController
public class DelayTaskController {

    @Autowired
    private DelayConfig delayConfig;

    @Autowired
    private RedisDelayedQueue redisDelayedQueue;

    @PostMapping(value = "addDelayTask")
    public void addDelayTask(@RequestBody AddDelayTask addDelayTask) {
        if (addDelayTask.getType() == 1) {
            OrderDelayModel orderDelayModel = new OrderDelayModel();
            orderDelayModel.setOrderNo("1258418");
            redisDelayedQueue.addQueue(orderDelayModel, 10, TimeUnit.SECONDS, delayConfig.getOrderDelay());
        } else if (addDelayTask.getType() == 2) {
            PayDelayModel payDelayModel = new PayDelayModel();
            payDelayModel.setPayOrderNo("Pay125885");
            redisDelayedQueue.addQueue(payDelayModel, 20, TimeUnit.SECONDS, delayConfig.getPayDelay());
        }
    }
}

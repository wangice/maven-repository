package com.ice.framework.web.feign;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * @author wangwei
 * @Date 2022/2/16 15:26
 */
@Data
public class StoreCheckStockOrderEntity implements Serializable {
    private static final long serialVersionUID = -5434735991660107972L;

    // 主键
    private Long id;

    // 盘点单单号
    private String checkStockOrderNo;

    // 门店代码
    private String storeCode;

    // 门店名称
    private String storeName;

    // 盘点属性 (1：日盘、2：月盘)
    private String checkType;

    // 盘点范围 （1:全盘、2:局盘）
    private String checkMode;

    // 状态（0:已作废,1:未提交,2:未调账,3:调账成功）
    private String checkState;

    // 调帐时间
    private Date adjustTime;

    // 提交时间
    private Date commitTime;

    // 录入人代码
    private String inputerCode;

    // 录入人名称
    private String inputerName;

    // 软删除标识
    private String deleteInd;
}

package com.ice.framework.web.excel;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson2.JSON;

import com.ice.framework.common.annotation.AutoResult;
import com.ice.framework.web.excel.column.DynamicDataSorter;
import com.ice.framework.web.excel.selected.ContentSelectedRowWriteHandler;
import com.ice.framework.web.util.ExcelUtil;

/**
 * @author wangwei
 * @Date 2024/8/20 17:16
 */
@AutoResult
@RestController
public class ExcelController {

    /**
     * 导出
     */
    @AutoResult(value = false)
    @GetMapping("/excelExport")
    public void excelExport() {
        List<UserExcelVO> list = new ArrayList<>();
        UserExcelVO userExcelVO = new UserExcelVO();
        userExcelVO.setUserCode("ceshi1234");
        userExcelVO.setUserName("阿伟");
        userExcelVO.setPhone("13476257867");
        userExcelVO.setSex(SexEnum.MAN.value());
        list.add(userExcelVO);
        ExcelUtil.writeWeb("用户.xlsx", "用户", UserExcelVO.class, list,
            new ContentSelectedRowWriteHandler(UserExcelVO.class));
    }

    /**
     * 导出
     */
    @AutoResult(value = false)
    @GetMapping("/excelExport1")
    public void excelExport(@RequestParam(value = "isTemplete", required = false) boolean isTemplete) {
        List<String> fieldsInSpecifiedOrder = MockDatas.fieldsInSpecifiedOrder;
        List<ExportDataDTO> dataList = isTemplete ? null : MockDatas.getDdataList();
        // 处理导出顺序，包括动态表头及其对应的列数据
        DynamicDataSorter dataSorter = new DynamicDataSorter<>(fieldsInSpecifiedOrder, dataList, ExportDataDTO.class);
        ExcelUtil.writeWeb("用户.xlsx", "用户", dataSorter.getHeads(), dataSorter.getDatas(),
            new ContentSelectedRowWriteHandler(ExportDataDTO.class));
    }

    @PostMapping("/import")
    public void importExcel(@RequestParam("file") MultipartFile file) {
        ExcelUtil.read(file, UserExcelVO.class, list -> {
            //
            System.out.println(JSON.toJSONString(list));
        });
    }
}

package com.ice.framework.web.excel;

import com.alibaba.excel.annotation.ExcelProperty;

import com.ice.framework.web.excel.annotation.ExcelSelected;

import lombok.Data;

/**
 * @author wangwei
 * @Date 2024/8/20 17:17
 */
@Data
public class UserExcelVO {

    @ExcelProperty(value = "用户编码")
    private String userCode;

    @ExcelProperty(value = "用户名称")
    private String userName;

    @ExcelProperty(value = "用户手机号")
    private String phone;

    @ExcelSelected(source = {"男", "女"})
    @ExcelProperty(value = "用户性别", converter = SexConvert.class)
    private Integer sex;
}

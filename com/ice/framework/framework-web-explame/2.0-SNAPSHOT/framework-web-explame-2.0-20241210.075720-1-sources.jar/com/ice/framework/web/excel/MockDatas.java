package com.ice.framework.web.excel;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * @author wangwei
 * @Date 2024/8/20 19:39
 */
public class MockDatas {

    // 自定义的导出列及其顺序
    public static List<String> fieldsInSpecifiedOrder = Arrays.asList("dropdownBox_enum", "file"
    // ,"inputStreamer" // 流类型的，在自定义顺序中，需要指定转换，注解类型中不需要指定转换
        , "link", "dropdownBox_db", "dropdownBox_fixed", "imagePath", "commentField", "字段_2", "字段_1", "enumer",
        "str_ignore", "boo", "int2str", "dateTime", "str", "num2", "unExistField", "num");

    // 可用于导出模板
    public static List<ExportDataDTO> emptyList = Collections.emptyList();

    //
    public static List<ExportDataDTO> getDdataList() {
        return new ArrayList<ExportDataDTO>() {
            {

                String file = "C:\\Users\\Administrator\\Desktop\\" + "手信分销数据结构.png";
                FileInputStream fileInputStream = null;
                try {
                    fileInputStream = new FileInputStream(new File(file));
                } catch (Exception e) {
                    e.printStackTrace();
                }

                add(new ExportDataDTO().setNum(999999999999999L).setNum2(999999999999999L).setStr("str-1")
                    .setDateTime(new Date()).setStr_ignore("ignore12345").setInt2str(0).setBoo(true)
                    .setCommentField("朱朱1").setDropdownBox_fixed("耗材")
                    .setDropdownBox_db("下拉数据_1aaaaaaaaaaaaaaaaaaaaaaaaaaaa").setImagePath("...1..."));
                add(new ExportDataDTO().setNum(222L).setStr("str-3").setDateTime(new Date())
                    .setStr_ignore("ignore67890").setInt2str(1).setBoo(false).setCommentField("朱朱2")
                    .setDropdownBox_fixed("医疗设备").setDropdownBox_db("下拉数据_2").setImagePath("...2...")
                    .setFile(new File(file)).setInputStreamer(fileInputStream));
            }
        };
    }
}

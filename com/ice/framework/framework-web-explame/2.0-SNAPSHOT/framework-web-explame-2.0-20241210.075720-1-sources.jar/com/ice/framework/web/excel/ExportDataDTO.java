package com.ice.framework.web.excel;

/**
 * @author wangwei
 * @Date 2024/8/21 17:28
 */

import java.io.File;
import java.io.InputStream;
import java.util.Date;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ContentStyle;
import com.alibaba.excel.enums.BooleanEnum;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 要导出、导入的对象
 */
@Data
@Accessors(chain = true) // easyExcel 导出支持Accessors ，导入不支持
@ContentStyle(
    /*locked = BooleanEnum.TRUE, fillForegroundColor=25 , fillBackgroundColor=15  ,*/ wrapped = BooleanEnum.FALSE)
public class ExportDataDTO {
    /////////////////////////////////////// 基础操作
    @ExcelProperty(value = "数字" /*,index=0 ,order = 0*/) // 索引>顺序>默认排序
    // @ColumnWidth(20)
    private long num;
    @ExcelProperty(value = "数字2")
    private Long num2;
    @ExcelProperty("字符串")
    private String str;
    @ExcelProperty("日期时间")
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    private Date dateTime;
    @ExcelProperty(value = "INT2STR") // 关联‘GenderConverter’
    private int int2str;
    @ExcelProperty("布尔")
    private boolean boo;

    @ExcelIgnore
    private String str_ignore;

    private String 字段_1;

    private String 字段_2;

    /////////////////////////////////////// 扩展操作
    // 固定下拉框 （关联customized.selected ）
    @ExcelProperty(value = "下拉框-固定")
    private String dropdownBox_fixed;

    // 动态下拉框：可以查询数据库数据显示在下拉框中 （关联customized.selected ; 要定义‘dynamicSelect’）
    @ExcelProperty(value = "下拉框-数据库")
    private String dropdownBox_db;

    // 待批注的字段 （关联customized.comment ）
    @ExcelProperty(value = "批注字段")
    private String commentField;

    // TODO
    @ExcelProperty(value = "图片")
    private String imagePath;

    @ExcelProperty(value = "图片-1")
    private File file;

    @ExcelProperty(value = "图片-2")
    private InputStream inputStreamer;// 流类型的，在自定义顺序中，需要指定转换，注解类型中不需要指定转换

}

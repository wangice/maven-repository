package com.ice.framework.web.excel;

import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.metadata.GlobalConfiguration;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.metadata.property.ExcelContentProperty;

/**
 * @author wangwei
 * @Date 2024/8/20 17:33
 */
public class SexConvert implements Converter<Integer> {
    @Override
    public Class supportJavaTypeKey() {
        return Integer.class;
    }

    @Override
    public Integer convertToJavaData(ReadCellData<?> cellData, ExcelContentProperty excelContentProperty,
        GlobalConfiguration globalConfiguration) throws Exception {
        if (SexEnum.MAN.desc().equals(cellData.getStringValue())) {
            return SexEnum.MAN.value();
        } else if (SexEnum.WOMAN.desc().equals(cellData.getStringValue())) {
            return SexEnum.WOMAN.value();
        } else {
            return null;
        }
    }

    @Override
    public WriteCellData<?> convertToExcelData(Integer integer, ExcelContentProperty excelContentProperty,
        GlobalConfiguration globalConfiguration) throws Exception {
        if (SexEnum.MAN.value().equals(integer)) {
            return new WriteCellData<>(SexEnum.MAN.desc());
        } else if (SexEnum.WOMAN.value().equals(integer)) {
            return new WriteCellData<>(SexEnum.WOMAN.desc());
        } else {
            return null;
        }
    }
}

package com.ice.framework.web.repeat;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * @author wangwei
 * @Date 2021/12/31 16:02
 */
@Data
public class UserInfo {

    @NotEmpty(message = "名称不能为空")
    private String name;

    private String userCode;
}

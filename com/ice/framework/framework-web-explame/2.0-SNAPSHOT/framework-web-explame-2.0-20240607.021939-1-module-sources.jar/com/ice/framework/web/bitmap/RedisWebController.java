package com.ice.framework.web.bitmap;

import com.ice.framework.common.annotation.AutoResult;
import com.ice.framework.common.util.MiscUtil;
import com.ice.framework.web.redis.LocalRedisHelper;
import com.ice.framework.web.redis.RedisKey;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

/**
 * @author wangwei
 * @Date 2022/3/30 19:35
 */
@AutoResult
@RestController
@RequestMapping("/visitor")
public class RedisWebController {

    @Autowired
    private RedisTemplate redisTemplate;


    @PostMapping(value = "visitorAccess")
    public void visitorAccess(@RequestBody VisitorAccessRecordRequest request) {
        RedisKey redisKey = RedisKey.valueOf("PRESENTACTIVITIESID", String.valueOf(request.getPresentActivitiesId()));
        String key = LocalRedisHelper.getResultKey(redisKey);
        redisTemplate.opsForValue().setBit(key, 1, Boolean.TRUE);
    }

    @GetMapping(value = "test")
    public void test(@RequestParam @Valid @NotBlank(message = "用户编码不能为空") String userCode) {
        System.out.println("userCode:" + userCode);
    }
}

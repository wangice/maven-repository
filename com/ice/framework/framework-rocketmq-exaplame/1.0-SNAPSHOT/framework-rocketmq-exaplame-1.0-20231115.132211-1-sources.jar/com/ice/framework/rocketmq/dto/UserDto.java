package com.ice.framework.rocketmq.dto;


import java.io.Serializable;

/**
 * @author wangwei
 * @Date 2023/8/15 15:24
 */
public class UserDto implements Serializable {

    private static final long serialVersionUID = 1172944035435312463L;

    private String userName;

    private String userCode;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }
}

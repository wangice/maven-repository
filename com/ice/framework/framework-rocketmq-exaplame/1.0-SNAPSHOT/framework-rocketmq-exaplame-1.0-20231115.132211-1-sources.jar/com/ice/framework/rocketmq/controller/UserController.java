package com.ice.framework.rocketmq.controller;


import com.ice.framework.common.annotation.AutoResult;
import com.ice.framework.rocketmq.dto.UserDto;
import com.yomahub.tlog.context.TLogContext;
import org.apache.rocketmq.common.message.MessageExtBrokerInner;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author wangwei
 * @Date 2023/8/15 15:26
 */
@AutoResult
@RequestMapping("/user")
@RestController
public class UserController {

    public static Logger logger = LoggerFactory.getLogger(UserController.class);

    @Value(value = "${rocketmq.producer.topic}:${rocketmq.producer.user.tag}")
    private String destination;

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    @GetMapping(value = "/msg")
    public void sendUserMsg() {
        UserDto userDto = new UserDto();
        userDto.setUserCode("123");
        userDto.setUserName("ice");
        logger.info("输出日志");
        MessageExtBrokerInner extBrokerInner = new MessageExtBrokerInner();
        extBrokerInner.setDelayTimeSec(10);

        Message<UserDto> message = MessageBuilder.withPayload(userDto)
                .setHeader("serviceClassName", this.getClass().getName())
                .setHeader("tlogTraceId", TLogContext.getTraceId())
                .setHeader("tlogSpanId", TLogContext.getSpanId())
                .build();


        rocketMQTemplate.send(destination, message);
    }
}

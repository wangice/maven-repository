package com.ice.framework.rocketmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author wangwei
 * @Date 2023/8/15 15:07
 */
@SpringBootApplication(scanBasePackages = {"com.ice.framework"})
public class RocketmqExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(RocketmqExampleApplication.class);
    }
}
